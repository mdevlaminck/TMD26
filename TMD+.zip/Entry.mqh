#ifndef __TMD_LITE_ENTRY_MQH__
#define __TMD_LITE_ENTRY_MQH__

#include "Structs.mqh"
#include "Config.mqh"
#include "Utils.mqh"
#include "Trend.mqh"
#include "Strength.mqh"
#include "Exposure.mqh"

//+------------------------------------------------------------------+
//| Pullback snapshot                                                |
//+------------------------------------------------------------------+
struct PullbackSnapshot
{
   bool   valid;
   int    direction;
   double emaValue;
   double closeValue;
   double atrValue;
   double depthAtr;
};

//+------------------------------------------------------------------+
//| Trigger snapshot                                                 |
//+------------------------------------------------------------------+
struct TriggerSnapshot
{
   bool valid;
   bool buyTrigger;
   bool sellTrigger;
   int  direction;
};

//+------------------------------------------------------------------+
//| Build pullback snapshot                                          |
//| Buy pullback  = price below setup EMA in a bullish trend         |
//| Sell pullback = price above setup EMA in a bearish trend         |
//| Uses closed candles only                                         |
//+------------------------------------------------------------------+
bool BuildPullbackSnapshot(const string symbol,
                           const ENUM_TIMEFRAMES setupTF,
                           const int pullbackEmaPeriod,
                           const int atrPeriod,
                           const double minPullbackAtr,
                           const double maxPullbackAtr,
                           const int trendDir,
                           PullbackSnapshot &pb)
{
   pb.valid      = false;
   pb.direction  = TREND_NONE;
   pb.emaValue   = 0.0;
   pb.closeValue = 0.0;
   pb.atrValue   = 0.0;
   pb.depthAtr   = 0.0;

   pb.emaValue   = GetEMA(symbol, setupTF, pullbackEmaPeriod, 1);
   pb.closeValue = GetClosePrice(symbol, setupTF, 1);
   pb.atrValue   = GetATR(symbol, setupTF, atrPeriod, 1);

   if(pb.emaValue <= 0.0 || pb.closeValue <= 0.0 || pb.atrValue <= 0.0)
      return false;

   if(trendDir == TREND_BUY)
   {
      pb.depthAtr  = (pb.emaValue - pb.closeValue) / pb.atrValue;
      pb.direction = TREND_BUY;

      if(pb.depthAtr >= minPullbackAtr && pb.depthAtr <= maxPullbackAtr)
      {
         pb.valid = true;
         return true;
      }

      return false;
   }

   if(trendDir == TREND_SELL)
   {
      pb.depthAtr  = (pb.closeValue - pb.emaValue) / pb.atrValue;
      pb.direction = TREND_SELL;

      if(pb.depthAtr >= minPullbackAtr && pb.depthAtr <= maxPullbackAtr)
      {
         pb.valid = true;
         return true;
      }

      return false;
   }

   return false;
}

//+------------------------------------------------------------------+
//| Build trigger snapshot                                           |
//| Buy trigger:                                                     |
//|   close[1] > high[2] and close[1] > EMA(trigger)                 |
//| Sell trigger:                                                    |
//|   close[1] < low[2]  and close[1] < EMA(trigger)                 |
//| Uses closed candles only                                         |
//+------------------------------------------------------------------+
bool BuildTriggerSnapshot(const string symbol,
                          const ENUM_TIMEFRAMES triggerTF,
                          const int triggerEmaPeriod,
                          TriggerSnapshot &trg)
{
   trg.valid       = false;
   trg.buyTrigger  = false;
   trg.sellTrigger = false;
   trg.direction   = TREND_NONE;

   double close1 = GetClosePrice(symbol, triggerTF, 1);
   double high2  = GetHighPrice(symbol, triggerTF, 2);
   double low2   = GetLowPrice(symbol, triggerTF, 2);
   double ema1   = GetEMA(symbol, triggerTF, triggerEmaPeriod, 1);

   if(close1 <= 0.0 || high2 <= 0.0 || low2 <= 0.0 || ema1 <= 0.0)
      return false;

   //trg.buyTrigger  = (close1 > high2 && close1 > ema1);
   //trg.sellTrigger = (close1 < low2  && close1 < ema1);
   
   double open1 = GetOpenPrice(symbol, triggerTF, 1);

   trg.buyTrigger  = (close1 > ema1 && close1 > open1);
   trg.sellTrigger = (close1 < ema1 && close1 < open1);

   if(trg.buyTrigger && !trg.sellTrigger)
      trg.direction = TREND_BUY;
   else if(trg.sellTrigger && !trg.buyTrigger)
      trg.direction = TREND_SELL;
   else
      trg.direction = TREND_NONE;

   trg.valid = true;
   return true;
}

//+------------------------------------------------------------------+
//| Update pullback state into pair                                  |
//+------------------------------------------------------------------+
void UpdatePairPullback(PairData &pair,
                        const ENUM_TIMEFRAMES setupTF,
                        const int pullbackEmaPeriod,
                        const int atrPeriod,
                        const double minPullbackAtr,
                        const double maxPullbackAtr)
{
   PullbackSnapshot pb;
   bool ok = BuildPullbackSnapshot(pair.symbol,
                                   setupTF,
                                   pullbackEmaPeriod,
                                   atrPeriod,
                                   minPullbackAtr,
                                   maxPullbackAtr,
                                   pair.trendDir,
                                   pb);

   pair.atrM15           = GetATR(pair.symbol, setupTF, atrPeriod, 1);
   pair.pullbackDepthAtr = pb.depthAtr;
   pair.inPullbackZone   = ok;

   if(pair.trendDir == TREND_BUY)
      pair.setupState = ok ? SETUP_PULLBACK_BUY : SETUP_NONE;
   else if(pair.trendDir == TREND_SELL)
      pair.setupState = ok ? SETUP_PULLBACK_SELL : SETUP_NONE;
   else
      pair.setupState = SETUP_NONE;

   if(!ok)
   {
      pair.basketState = BASKET_BLOCKED_PULLBACK;
      pair.stateText   = STATE_BLOCK_PULLBACK;
      pair.blockReason = REASON_PULLBACK;
   }
}

//+------------------------------------------------------------------+
//| Update trigger state into pair                                   |
//+------------------------------------------------------------------+
void UpdatePairTrigger(PairData &pair,
                       const ENUM_TIMEFRAMES triggerTF,
                       const int triggerEmaPeriod,
                       const int atrPeriod)
{
   TriggerSnapshot trg;
   bool ok = BuildTriggerSnapshot(pair.symbol, triggerTF, triggerEmaPeriod, trg);

   pair.atrM5       = GetATR(pair.symbol, triggerTF, atrPeriod, 1);
   pair.triggerBuy  = false;
   pair.triggerSell = false;
   pair.triggerState = TRIGGER_NONE;

   if(!ok)
   {
      pair.basketState = BASKET_BLOCKED_TRIGGER;
      pair.stateText   = STATE_BLOCK_TRIGGER;
      pair.blockReason = REASON_TRIGGER;
      return;
   }

   pair.triggerBuy  = trg.buyTrigger;
   pair.triggerSell = trg.sellTrigger;

   if(trg.buyTrigger)
      pair.triggerState = TRIGGER_BUY;
   else if(trg.sellTrigger)
      pair.triggerState = TRIGGER_SELL;
   else
      pair.triggerState = TRIGGER_NONE;

   if(pair.trendDir == TREND_BUY && !pair.triggerBuy)
   {
      pair.basketState = BASKET_BLOCKED_TRIGGER;
      pair.stateText   = STATE_BLOCK_TRIGGER;
      pair.blockReason = REASON_TRIGGER;
   }
   else if(pair.trendDir == TREND_SELL && !pair.triggerSell)
   {
      pair.basketState = BASKET_BLOCKED_TRIGGER;
      pair.stateText   = STATE_BLOCK_TRIGGER;
      pair.blockReason = REASON_TRIGGER;
   }
}

//+------------------------------------------------------------------+
//| Direction-specific pullback helpers                              |
//+------------------------------------------------------------------+
bool PairPullbackBuyOk(const PairData &pair)
{
   return (pair.setupState == SETUP_PULLBACK_BUY && pair.inPullbackZone);
}

bool PairPullbackSellOk(const PairData &pair)
{
   return (pair.setupState == SETUP_PULLBACK_SELL && pair.inPullbackZone);
}

//+------------------------------------------------------------------+
//| Direction-specific trigger helpers                               |
//+------------------------------------------------------------------+
bool PairTriggerBuyOk(const PairData &pair)
{
   return (pair.triggerState == TRIGGER_BUY && pair.triggerBuy);
}

bool PairTriggerSellOk(const PairData &pair)
{
   return (pair.triggerState == TRIGGER_SELL && pair.triggerSell);
}

//+------------------------------------------------------------------+
//| Return whether pair is entry-ready for its current trend         |
//+------------------------------------------------------------------+
bool IsPairEntryReady(const PairData &pair)
{
   if(!pair.trendValid)
      return false;

   if(pair.trendDir == TREND_BUY)
   {
      return pair.strengthBuyOk &&
             pair.exposureBuyOk &&
             pair.riskOk &&
             pair.sessionOk &&
             pair.spreadOk &&
             PairPullbackBuyOk(pair) &&
             PairTriggerBuyOk(pair);
   }

   if(pair.trendDir == TREND_SELL)
   {
      return pair.strengthSellOk &&
             pair.exposureSellOk &&
             pair.riskOk &&
             pair.sessionOk &&
             pair.spreadOk &&
             PairPullbackSellOk(pair) &&
             PairTriggerSellOk(pair);
   }

   return false;
}

//+------------------------------------------------------------------+
//| Build entry candidate from pair                                  |
//+------------------------------------------------------------------+
void BuildEntryCandidate(const PairData &pair, EntryCandidate &candidate)
{
   candidate.symbol         = pair.symbol;
   candidate.direction      = pair.trendDir;
   candidate.buyCurrency    = "";
   candidate.sellCurrency   = "";

   if(pair.trendDir == TREND_BUY)
   {
      candidate.buyCurrency  = pair.base;
      candidate.sellCurrency = pair.quote;
   }
   else if(pair.trendDir == TREND_SELL)
   {
      candidate.buyCurrency  = pair.quote;
      candidate.sellCurrency = pair.base;
   }

   candidate.trendOk      = pair.trendValid;
   candidate.strengthOk   = (pair.trendDir == TREND_BUY) ? pair.strengthBuyOk : pair.strengthSellOk;
   candidate.pullbackOk   = (pair.trendDir == TREND_BUY) ? PairPullbackBuyOk(pair) : PairPullbackSellOk(pair);
   candidate.triggerOk    = (pair.trendDir == TREND_BUY) ? PairTriggerBuyOk(pair)  : PairTriggerSellOk(pair);
   candidate.spreadOk     = pair.spreadOk;
   candidate.exposureOk   = (pair.trendDir == TREND_BUY) ? pair.exposureBuyOk : pair.exposureSellOk;
   candidate.riskOk       = pair.riskOk;
   candidate.sessionOk    = pair.sessionOk;

   candidate.strengthGap     = pair.strengthGap;
   candidate.pullbackDepthAtr= pair.pullbackDepthAtr;
   candidate.spreadPoints    = pair.spreadPoints;
   candidate.atrM15          = pair.atrM15;

   candidate.valid        = false;
   candidate.rejectReason = REASON_OK;
   
   candidate.strengthBase      = pair.strengthBase;
   candidate.strengthQuote     = pair.strengthQuote;
   candidate.strengthGapDelta  = pair.strengthGapDelta;

   candidate.baseCurrentStrength  = GetCurrencyCurrentStrength(pair.base);
   candidate.quoteCurrentStrength = GetCurrencyCurrentStrength(pair.quote);

   candidate.baseMomentum      = GetCurrencyStrengthMomentum(pair.base);
   candidate.quoteMomentum     = GetCurrencyStrengthMomentum(pair.quote);

   CurrencyStrengthData baseData, quoteData;
   candidate.baseAcceleration  = GetCurrencyStrengthData(pair.base,  baseData) ? baseData.acceleration  : 0.0;
   candidate.quoteAcceleration = GetCurrencyStrengthData(pair.quote, quoteData) ? quoteData.acceleration : 0.0;

   candidate.inPullbackZone    = pair.inPullbackZone;
   candidate.setupState        = pair.setupState;
   candidate.triggerState      = pair.triggerState;
   candidate.triggerBuy        = pair.triggerBuy;
   candidate.triggerSell       = pair.triggerSell;

   candidate.atrM5             = pair.atrM5;
   

   if(!candidate.trendOk)
   {
      candidate.rejectReason = REASON_TREND;
      return;
   }

   if(!candidate.strengthOk)
   {
      candidate.rejectReason = REASON_STRENGTH;
      return;
   }

   if(!candidate.pullbackOk)
   {
      candidate.rejectReason = REASON_PULLBACK;
      return;
   }

   if(!candidate.triggerOk)
   {
      candidate.rejectReason = REASON_TRIGGER;
      return;
   }

   if(!candidate.spreadOk)
   {
      candidate.rejectReason = REASON_SPREAD;
      return;
   }

   if(!candidate.exposureOk)
   {
      candidate.rejectReason = REASON_EXPOSURE;
      return;
   }

   if(!candidate.riskOk)
   {
      candidate.rejectReason = REASON_RISK;
      return;
   }

   if(!candidate.sessionOk)
   {
      candidate.rejectReason = REASON_SESSION;
      return;
   }

   candidate.valid = true;
}

//+------------------------------------------------------------------+
//| Update final visible pair state after entry checks               |
//+------------------------------------------------------------------+
void FinalizePairEntryState(PairData &pair)
{
   if(pair.trendDir == TREND_BUY)
   {
      if(pair.hasBuyBasket)
      {
         pair.basketState = BASKET_ACTIVE;
         pair.stateText   = STATE_GRID_BUY;
         pair.blockReason = REASON_OK;
         return;
      }

      if(IsPairEntryReady(pair))
      {
         pair.basketState = BASKET_IDLE;
         pair.stateText   = STATE_TRG_BUY;
         pair.blockReason = REASON_OK;
         return;
      }

      if(PairPullbackBuyOk(pair) && !PairTriggerBuyOk(pair))
      {
         pair.basketState = BASKET_IDLE;
         pair.stateText   = STATE_PB_BUY;
         pair.blockReason = REASON_OK;
         return;
      }

      return;
   }

   if(pair.trendDir == TREND_SELL)
   {
      if(pair.hasSellBasket)
      {
         pair.basketState = BASKET_ACTIVE;
         pair.stateText   = STATE_GRID_SELL;
         pair.blockReason = REASON_OK;
         return;
      }

      if(IsPairEntryReady(pair))
      {
         pair.basketState = BASKET_IDLE;
         pair.stateText   = STATE_TRG_SELL;
         pair.blockReason = REASON_OK;
         return;
      }

      if(PairPullbackSellOk(pair) && !PairTriggerSellOk(pair))
      {
         pair.basketState = BASKET_IDLE;
         pair.stateText   = STATE_PB_SELL;
         pair.blockReason = REASON_OK;
         return;
      }

      return;
   }
}

//+------------------------------------------------------------------+
//| Full pair entry update pipeline                                  |
//| Assumes trend/strength/exposure/risk/session/spread already set  |
//+------------------------------------------------------------------+
void UpdatePairEntryState(PairData &pair,
                          const ENUM_TIMEFRAMES setupTF,
                          const ENUM_TIMEFRAMES triggerTF,
                          const int pullbackEmaPeriod,
                          const int triggerEmaPeriod,
                          const int atrPeriod,
                          const double minPullbackAtr,
                          const double maxPullbackAtr)
{
   UpdatePairPullback(pair,
                      setupTF,
                      pullbackEmaPeriod,
                      atrPeriod,
                      minPullbackAtr,
                      maxPullbackAtr);

    UpdatePairTrigger(pair,
                     triggerTF,
                     triggerEmaPeriod,
                     atrPeriod);

   FinalizePairEntryState(pair);
}

//+------------------------------------------------------------------+
//| Logging helper                                                   |
//+------------------------------------------------------------------+
string EntryCandidateToText(const EntryCandidate &c)
{
   string dirTxt = "NONE";
   if(c.direction == TREND_BUY)
      dirTxt = "BUY";
   else if(c.direction == TREND_SELL)
      dirTxt = "SELL";

   string txt = c.symbol;
   txt += " | dir=" + dirTxt;
   txt += " | valid=" + string(c.valid ? "Y" : "N");

   txt += " | trend=" + string(c.trendOk ? "Y" : "N");
   txt += " | str="   + string(c.strengthOk ? "Y" : "N");
   txt += " | pb="    + string(c.pullbackOk ? "Y" : "N");
   txt += " | trg="   + string(c.triggerOk ? "Y" : "N");
   txt += " | spr="   + string(c.spreadOk ? "Y" : "N");
   txt += " | exp="   + string(c.exposureOk ? "Y" : "N");
   txt += " | risk="  + string(c.riskOk ? "Y" : "N");
   txt += " | sess="  + string(c.sessionOk ? "Y" : "N");

   txt += " | sb="    + DoubleToString(c.strengthBase, 2);
   txt += " | sq="    + DoubleToString(c.strengthQuote, 2);
   txt += " | gap="   + DoubleToString(c.strengthGap, 2);
   txt += " | dGap="  + DoubleToString(c.strengthGapDelta, 2);

   txt += " | cb="    + DoubleToString(c.baseCurrentStrength, 2);
   txt += " | cq="    + DoubleToString(c.quoteCurrentStrength, 2);

   txt += " | momB="  + DoubleToString(c.baseMomentum, 2);
   txt += " | momQ="  + DoubleToString(c.quoteMomentum, 2);
   txt += " | accB="  + DoubleToString(c.baseAcceleration, 2);
   txt += " | accQ="  + DoubleToString(c.quoteAcceleration, 2);

   txt += " | pbATR=" + DoubleToString(c.pullbackDepthAtr, 2);
   txt += " | pbZ="   + string(c.inPullbackZone ? "Y" : "N");
   txt += " | set="   + IntegerToString(c.setupState);

   txt += " | trgSt=" + IntegerToString(c.triggerState);
   txt += " | trgB="  + string(c.triggerBuy ? "Y" : "N");
   txt += " | trgS="  + string(c.triggerSell ? "Y" : "N");

   txt += " | atrM5="  + DoubleToString(c.atrM5, 5);
   txt += " | atrM15=" + DoubleToString(c.atrM15, 5);
   txt += " | sprPts=" + DoubleToString(c.spreadPoints, 1);

   txt += " | reason=" + c.rejectReason;
   return txt;
}

#endif // __TMD_LITE_ENTRY_MQH__