#ifndef __TMD_LITE_SYMBOLS_MQH__
#define __TMD_LITE_SYMBOLS_MQH__

#include "Config.mqh"

//+------------------------------------------------------------------+
//| Return true if string starts with prefix                         |
//+------------------------------------------------------------------+
bool StartsWith(const string text, const string prefix)
{
   int lenText   = (int)StringLen(text);
   int lenPrefix = (int)StringLen(prefix);

   if(lenPrefix <= 0 || lenText < lenPrefix)
      return false;

   return (StringSubstr(text, 0, lenPrefix) == prefix);
}

//+------------------------------------------------------------------+
//| Return true if string ends with suffix                           |
//+------------------------------------------------------------------+
bool EndsWith(const string text, const string suffix)
{
   int lenText   = (int)StringLen(text);
   int lenSuffix = (int)StringLen(suffix);

   if(lenSuffix <= 0 || lenText < lenSuffix)
      return false;

   return (StringSubstr(text, lenText - lenSuffix, lenSuffix) == suffix);
}

//+------------------------------------------------------------------+
//| Remove common broker suffix/prefix from a symbol if possible     |
//| Example: "EURUSD.a" -> "EURUSD"                                  |
//|          "mEURUSD"  -> "EURUSD"                                  |
//+------------------------------------------------------------------+
string NormalizeCoreSymbol(const string brokerSymbol)
{
   string s = brokerSymbol;

   //--- exact known symbols first
   for(int i = 0; i < TMD_LITE_SYMBOL_COUNT; i++)
   {
      if(s == TMD_SYMBOLS[i])
         return s;
   }

   //--- contains known core symbol
   for(int i = 0; i < TMD_LITE_SYMBOL_COUNT; i++)
   {
      string core = TMD_SYMBOLS[i];
      if(StringFind(s, core) >= 0)
         return core;
   }

   return s;
}

//+------------------------------------------------------------------+
//| Check if symbol belongs to configured universe                   |
//+------------------------------------------------------------------+
bool IsUniverseSymbol(const string symbol)
{
   string core = NormalizeCoreSymbol(symbol);

   for(int i = 0; i < TMD_LITE_SYMBOL_COUNT; i++)
   {
      if(core == TMD_SYMBOLS[i])
         return true;
   }

   return false;
}

//+------------------------------------------------------------------+
//| Find broker symbol from configured core symbol                   |
//| If exact symbol exists, use it                                   |
//| Else scan Market Watch for symbol containing core                |
//+------------------------------------------------------------------+
string ResolveBrokerSymbol(const string coreSymbol,
                           const string suffix = "",
                           const string prefix = "",
                           const bool preferSuffix = true)
{
   string candidate;

   //--- 1. Preferred: prefix + core + suffix
   if(prefix != "" || suffix != "")
   {
      candidate = prefix + coreSymbol + suffix;
      if(SymbolSelect(candidate, true))
         return candidate;
   }

   //--- 2. If preferSuffix = true, try suffix version before raw
   if(preferSuffix && suffix != "")
   {
      candidate = coreSymbol + suffix;
      if(SymbolSelect(candidate, true))
         return candidate;
   }

   //--- 3. Raw symbol (EURUSD)
   if(SymbolSelect(coreSymbol, true))
      return coreSymbol;

   //--- 4. If preferSuffix = false, try suffix after raw
   if(!preferSuffix && suffix != "")
   {
      candidate = coreSymbol + suffix;
      if(SymbolSelect(candidate, true))
         return candidate;
   }

   //--- 5. Fallback: scan Market Watch
   int total = SymbolsTotal(true);
   for(int i = 0; i < total; i++)
   {
      string name = SymbolName(i, true);
      if(StringFind(name, coreSymbol) >= 0)
      {
         if(SymbolSelect(name, true))
            return name;
      }
   }

   return "";
}

//+------------------------------------------------------------------+
//| Split symbol into base and quote                                 |
//| Supports standard 6-char FX and metals in configured universe    |
//+------------------------------------------------------------------+
bool GetBaseQuoteCurrencies(const string symbol, string &base, string &quote)
{
   string core = NormalizeCoreSymbol(symbol);
   base  = "";
   quote = "";

   if(!IsUniverseSymbol(core))
      return false;

   if((int)StringLen(core) < 6)
      return false;

   base  = StringSubstr(core, 0, 3);
   quote = StringSubstr(core, 3, 3);

   return ((int)StringLen(base) == 3 && (int)StringLen(quote) == 3);
}

//+------------------------------------------------------------------+
//| Get symbol class                                                 |
//+------------------------------------------------------------------+
ENUM_SYMBOL_CLASS GetSymbolClass(const string symbol)
{
   string core = NormalizeCoreSymbol(symbol);

   if(core == "XAUUSD" || core == "XAGUSD")
      return SYMBOL_CLASS_METAL;

   if(IsUniverseSymbol(core))
      return SYMBOL_CLASS_FX;

   return SYMBOL_CLASS_UNKNOWN;
}

//+------------------------------------------------------------------+
//| Check if symbol is metal                                         |
//+------------------------------------------------------------------+
bool IsMetalSymbol(const string symbol)
{
   return (GetSymbolClass(symbol) == SYMBOL_CLASS_METAL);
}

//+------------------------------------------------------------------+
//| Check if symbol is FX                                            |
//+------------------------------------------------------------------+
bool IsFXSymbol(const string symbol)
{
   return (GetSymbolClass(symbol) == SYMBOL_CLASS_FX);
}

//+------------------------------------------------------------------+
//| Return symbol digits safely                                      |
//+------------------------------------------------------------------+
int GetSymbolDigitsSafe(const string symbol)
{
   long digits = 0;
   if(!SymbolInfoInteger(symbol, SYMBOL_DIGITS, digits))
      return 0;

   return (int)digits;
}

//+------------------------------------------------------------------+
//| Return symbol point safely                                       |
//+------------------------------------------------------------------+
double GetSymbolPointSafe(const string symbol)
{
   double point = 0.0;
   if(!SymbolInfoDouble(symbol, SYMBOL_POINT, point))
      return 0.0;

   return point;
}

//+------------------------------------------------------------------+
//| Return one pip size in price units                               |
//| 5-digit / 3-digit symbols => 10 points                           |
//| 4-digit / 2-digit symbols => 1 point                             |
//+------------------------------------------------------------------+
double GetPipSize(const string symbol)
{
   int digits   = GetSymbolDigitsSafe(symbol);
   double point = GetSymbolPointSafe(symbol);

   if(point <= 0.0)
      return 0.0;

   if(digits == 3 || digits == 5)
      return point * 10.0;

   return point;
}

//+------------------------------------------------------------------+
//| Return spread in raw points                                      |
//+------------------------------------------------------------------+
double GetSpreadPoints(const string symbol)
{
   double ask   = 0.0;
   double bid   = 0.0;
   double point = GetSymbolPointSafe(symbol);

   if(point <= 0.0)
      return 0.0;

   if(!SymbolInfoDouble(symbol, SYMBOL_ASK, ask))
      return 0.0;
   if(!SymbolInfoDouble(symbol, SYMBOL_BID, bid))
      return 0.0;

   return (ask - bid) / point;
}

//+------------------------------------------------------------------+
//| Return spread in pips                                            |
//+------------------------------------------------------------------+
double GetSpreadPips(const string symbol)
{
   double pip = GetPipSize(symbol);
   if(pip <= 0.0)
      return 0.0;

   double ask = 0.0;
   double bid = 0.0;
   if(!SymbolInfoDouble(symbol, SYMBOL_ASK, ask))
      return 0.0;
   if(!SymbolInfoDouble(symbol, SYMBOL_BID, bid))
      return 0.0;

   return (ask - bid) / pip;
}

//+------------------------------------------------------------------+
//| Return default spread threshold in points for the symbol         |
//+------------------------------------------------------------------+
double GetDefaultMaxSpreadPoints(const string symbol)
{
   ENUM_SYMBOL_CLASS cls = GetSymbolClass(symbol);

   if(cls == SYMBOL_CLASS_METAL)
      return InpMaxSpreadPointsMetal;

   if(cls == SYMBOL_CLASS_FX)
      return InpMaxSpreadPointsFX;

   return InpMaxSpreadPointsFX;
}

//+------------------------------------------------------------------+
//| Check whether symbol is tradable / selected                      |
//+------------------------------------------------------------------+
bool EnsureSymbolReady(const string symbol)
{
   if(symbol == "")
      return false;

   if(!SymbolSelect(symbol, true))
      return false;

   bool   tradeModeOk = false;
   long   tradeMode   = 0;
   double point       = 0.0;
   double ask         = 0.0;
   double bid         = 0.0;

   if(SymbolInfoInteger(symbol, SYMBOL_TRADE_MODE, tradeMode))
      tradeModeOk = (tradeMode != SYMBOL_TRADE_MODE_DISABLED);

   if(!tradeModeOk)
      return false;

   if(!SymbolInfoDouble(symbol, SYMBOL_POINT, point) || point <= 0.0)
      return false;

   if(!SymbolInfoDouble(symbol, SYMBOL_ASK, ask) || ask <= 0.0)
      return false;

   if(!SymbolInfoDouble(symbol, SYMBOL_BID, bid) || bid <= 0.0)
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| Fill arrays with configured broker symbols                       |
//| brokerSymbols[i] corresponds to TMD_SYMBOLS[i]                   |
//+------------------------------------------------------------------+
void BuildBrokerSymbolMap(string &brokerSymbols[])
{
   ArrayResize(brokerSymbols, TMD_LITE_SYMBOL_COUNT);

   for(int i = 0; i < TMD_LITE_SYMBOL_COUNT; i++)
   {
      brokerSymbols[i] = ResolveBrokerSymbol(
                           TMD_SYMBOLS[i],
                           InpBrokerSymbolSuffix,
                           InpBrokerSymbolPrefix,
                           InpPreferSuffix
                         );
   }
}

//+------------------------------------------------------------------+
//| Get index in configured universe                                 |
//+------------------------------------------------------------------+
int GetUniverseSymbolIndex(const string symbol)
{
   string core = NormalizeCoreSymbol(symbol);

   for(int i = 0; i < TMD_LITE_SYMBOL_COUNT; i++)
   {
      if(core == TMD_SYMBOLS[i])
         return i;
   }

   return -1;
}

//+------------------------------------------------------------------+
//| Check whether two symbols share at least one currency            |
//+------------------------------------------------------------------+
bool SymbolsShareCurrency(const string symbolA, const string symbolB)
{
   string aBase, aQuote, bBase, bQuote;

   if(!GetBaseQuoteCurrencies(symbolA, aBase, aQuote))
      return false;
   if(!GetBaseQuoteCurrencies(symbolB, bBase, bQuote))
      return false;

   if(aBase  == bBase)  return true;
   if(aBase  == bQuote) return true;
   if(aQuote == bBase)  return true;
   if(aQuote == bQuote) return true;

   return false;
}

//+------------------------------------------------------------------+
//| Check whether a currency belongs to a symbol                     |
//+------------------------------------------------------------------+
bool SymbolContainsCurrency(const string symbol, const string currency)
{
   string base, quote;
   if(!GetBaseQuoteCurrencies(symbol, base, quote))
      return false;

   return (base == currency || quote == currency);
}

#endif // __TMD_LITE_SYMBOLS_MQH__