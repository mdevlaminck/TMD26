﻿#ifndef __TMD_LITE_STRUCTS_MQH__
#define __TMD_LITE_STRUCTS_MQH__

//+------------------------------------------------------------------+
//| Trend direction                                                  |
//+------------------------------------------------------------------+
enum ENUM_TREND_DIR
{
   TREND_NONE = 0,
   TREND_BUY  = 1,
   TREND_SELL = -1
};

//+------------------------------------------------------------------+
//| Pullback / setup state                                           |
//+------------------------------------------------------------------+
enum ENUM_SETUP_STATE
{
   SETUP_NONE = 0,
   SETUP_PULLBACK_BUY,
   SETUP_PULLBACK_SELL
};

//+------------------------------------------------------------------+
//| Trigger state                                                    |
//+------------------------------------------------------------------+
enum ENUM_TRIGGER_STATE
{
   TRIGGER_NONE = 0,
   TRIGGER_BUY,
   TRIGGER_SELL
};

//+------------------------------------------------------------------+
//| Basket state                                                     |
//+------------------------------------------------------------------+
enum ENUM_BASKET_STATE
{
   BASKET_IDLE = 0,
   BASKET_ACTIVE,
   BASKET_BLOCKED_SPREAD,
   BASKET_BLOCKED_RISK,
   BASKET_BLOCKED_EXPOSURE,
   BASKET_BLOCKED_SESSION,
   BASKET_BLOCKED_STRENGTH,
   BASKET_BLOCKED_TREND,
   BASKET_BLOCKED_PULLBACK,
   BASKET_BLOCKED_TRIGGER,
   BASKET_STALE
};

//+------------------------------------------------------------------+
//| Risk state                                                       |
//+------------------------------------------------------------------+
enum ENUM_RISK_STATE
{
   RISK_OK = 0,
   RISK_FREEZE,
   RISK_EMERGENCY
};

//+------------------------------------------------------------------+
//| Currency directional exposure                                    |
//+------------------------------------------------------------------+
enum ENUM_CCY_EXPOSURE_DIR
{
   CCY_EXPOSURE_NONE = 0,
   CCY_EXPOSURE_BUY  = 1,
   CCY_EXPOSURE_SELL = -1
};

//+------------------------------------------------------------------+
//| Per-currency strength state                                      |
//+------------------------------------------------------------------+
struct CurrencyStrengthData
{
   string currency;

   double currentStrength;     // latest computed strength snapshot
   double smoothedStrength;    // history-aware strength value
   double previousStrength;    // previous smoothed value
   double momentum;            // strength change over lookback
   double acceleration;        // second derivative / change of momentum

   int    rank;
   bool   valid;
};

//+------------------------------------------------------------------+
//| Pair runtime state                                               |
//+------------------------------------------------------------------+
struct PairData
{
   string symbol;
   string base;
   string quote;

   //--- trend
   int    trendDir;
   bool   trendValid;
   double trendFastEMA_H1;
   double trendSlowEMA_H1;
   double trendFastEMA_H4;
   double trendSlowEMA_H4;

   //--- strength
   double strengthBase;
   double strengthQuote;
   double strengthGap;
   double strengthGapPrev;
   double strengthGapDelta;
   bool   strengthBuyOk;
   bool   strengthSellOk;

   //--- volatility / spread
   double atrM5;
   double atrM15;
   double spreadPoints;
   double spreadToAtrM5;
   bool   spreadOk;

   //--- setup / trigger
   double pullbackDepthAtr;
   bool   inPullbackZone;
   int    setupState;
   int    triggerState;
   bool   triggerBuy;
   bool   triggerSell;

   //--- live basket overview
   bool   hasBuyBasket;
   bool   hasSellBasket;
   int    buyOrders;
   int    sellOrders;
   double buyLots;
   double sellLots;
   double buyProfit;
   double sellProfit;
   double buyAgeDays;
   double sellAgeDays;

   //--- validation flags
   bool   exposureBuyOk;
   bool   exposureSellOk;
   bool   riskOk;
   bool   sessionOk;

   //--- display / diagnostics
   int    basketState;
   string stateText;
   string blockReason;
};

//+------------------------------------------------------------------+
//| Basket aggregate info                                            |
//+------------------------------------------------------------------+
struct BasketInfo
{
   string symbol;
   int    direction;          // ORDER_TYPE_BUY / ORDER_TYPE_SELL semantic use
   ulong  magic;

   int    orders;
   double lots;

   double grossProfit;
   double swap;
   double commission;
   double netProfit;

   double avgPrice;
   double lastEntryPrice;

   datetime oldestOpenTime;
   datetime newestOpenTime;
   double   ageDays;

   bool     valid;
};

//+------------------------------------------------------------------+
//| Directional exposure per currency                                |
//+------------------------------------------------------------------+
struct CurrencyExposure
{
   string currency;

   bool   hasBuyExposure;
   bool   hasSellExposure;

   string buySourceSymbol;
   string sellSourceSymbol;

   ulong  buySourceMagic;
   ulong  sellSourceMagic;
};

//+------------------------------------------------------------------+
//| Account / portfolio snapshot                                     |
//+------------------------------------------------------------------+
struct PortfolioStats
{
   double balance;
   double equity;
   double margin;
   double freeMargin;
   double marginLevel;

   double floatingPnl;
   double floatingPnlPct;
   double drawdownPct;

   int    totalPositions;
   int    totalBaskets;
   double totalLots;

   int    riskState;
};

struct DebugStats
{
   int scannedPairs;

   int blockedTrend;
   int blockedStrength;
   int blockedPullback;
   int blockedTrigger;
   int blockedSpread;
   int blockedExposure;
   int blockedSession;
   int blockedRisk;

   int readyBuy;
   int readySell;

   int openedBaskets;
   int expandedBaskets;

   int exitTP;
   int exitHardStop;
   int exitStaleBE;
   int exitControlledLoss;
   int exitPortfolioRescue;
   int exitEmergency;
};

//+------------------------------------------------------------------+
//| Basket close audit                                              |
//+------------------------------------------------------------------+
struct BasketCloseAudit
{
   string   symbol;
   int      direction;
   bool     pending;
   string   reason;
   int      orders;
   double   lots;
   double   pnl;
   double   ageDays;
   datetime requestedAt;
};

//+------------------------------------------------------------------+
//| Entry candidate                                                  |
//+------------------------------------------------------------------+
struct EntryCandidate
{
   string symbol;
   int    direction;          // TREND_BUY / TREND_SELL semantic use

   string buyCurrency;
   string sellCurrency;

   bool   trendOk;
   bool   strengthOk;
   bool   pullbackOk;
   bool   triggerOk;
   bool   spreadOk;
   bool   exposureOk;
   bool   riskOk;
   bool   sessionOk;

   double strengthGap;
   double pullbackDepthAtr;
   double spreadPoints;
   double atrM15;

   bool   valid;
   string rejectReason;
   
   double strengthBase;
   double strengthQuote;
   double strengthGapDelta;

   double baseCurrentStrength;
   double quoteCurrentStrength;

   double baseMomentum;
   double quoteMomentum;

   double baseAcceleration;
   double quoteAcceleration;

   bool   inPullbackZone;
   int    setupState;
   int    triggerState;
   bool   triggerBuy;
   bool   triggerSell;

   double atrM5;
   
};

#endif // __TMD_LITE_STRUCTS_MQH__