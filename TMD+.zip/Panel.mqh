﻿#ifndef __TMD_LITE_PANEL_MQH__
#define __TMD_LITE_PANEL_MQH__

#include "Structs.mqh"
#include "Config.mqh"
#include "Trend.mqh"
#include "Strength.mqh"
#include "ChartStyle.mqh"

// close to old EA footprint
#define TMD_PANEL_X          20
#define TMD_PANEL_Y          30
#define TMD_PANEL_W          900
#define TMD_PANEL_H          790

#define TMD_PANEL_CUR_ROWS   10
#define TMD_PANEL_SYM_ROWS   30

// internal layout
#define TOPBAR_Y             33
#define TOPBAR_H             28

#define SEP1_Y               65
#define SEP2_Y               130
#define SEP3_Y               316

#define CUR_BLOCK_TOP        150
#define CUR_BLOCK_BOTTOM     306
#define CUR_BLOCK_H          (CUR_BLOCK_BOTTOM - CUR_BLOCK_TOP)

//+------------------------------------------------------------------+
string Fmt2(const double v) { return DoubleToString(v, 2); }
string Fmt1(const double v) { return DoubleToString(v, 1); }
string Fmt0(const double v) { return DoubleToString(v, 0); }

//+------------------------------------------------------------------+
string FormatMoneyPanel(const double v)
{
   return DoubleToString(v, 2);
}

//+------------------------------------------------------------------+
string FormatLotsPanel(const double v)
{
   return DoubleToString(v, 2);
}

//+------------------------------------------------------------------+
string FormatPctPanel(const double v, const int digits = 2)
{
   return DoubleToString(v, digits) + "%";
}

//+------------------------------------------------------------------+
string TFToShortText(ENUM_TIMEFRAMES tf)
{
   switch(tf)
   {
      case PERIOD_M1:  return "M1";
      case PERIOD_M5:  return "M5";
      case PERIOD_M15: return "M15";
      case PERIOD_M30: return "M30";
      case PERIOD_H1:  return "H1";
      case PERIOD_H4:  return "H4";
      case PERIOD_D1:  return "D1";
      case PERIOD_W1:  return "W1";
      case PERIOD_MN1: return "MN1";
   }
   return "?";
}

//+------------------------------------------------------------------+
string GetServerTimeText()
{
   MqlDateTime tm;
   TimeToStruct(TimeCurrent(), tm);
   return StringFormat("%02d:%02d:%02d", tm.hour, tm.min, tm.sec);
}

//+------------------------------------------------------------------+
bool IsEAOnline()
{
   bool terminalTrade = (bool)TerminalInfoInteger(TERMINAL_TRADE_ALLOWED);
   bool programTrade  = (bool)MQLInfoInteger(MQL_TRADE_ALLOWED);
   return (terminalTrade && programTrade);
}

//+------------------------------------------------------------------+
double GetPairGridPnL(const PairData &p)
{
   return p.buyProfit + p.sellProfit;
}

//+------------------------------------------------------------------+
int GetPairOpenOrders(const PairData &p)
{
   return p.buyOrders + p.sellOrders;
}

//+------------------------------------------------------------------+
double GetPairOpenLots(const PairData &p)
{
   return p.buyLots + p.sellLots;
}

//+------------------------------------------------------------------+
string PairTrendComboText(const PairData &p)
{
   if(p.trendDir == TREND_BUY)  return "BUY";
   if(p.trendDir == TREND_SELL) return "SELL";
   return "-";
}

//+------------------------------------------------------------------+
string PairFilterText(const PairData &p)
{
   if(p.stateText == STATE_READY)          return "TRIG";
   if(p.stateText == STATE_BLOCK_TRIGGER)  return "TRIG";
   if(p.stateText == STATE_BLOCK_PULLBACK) return "PBACK";
   if(p.stateText == STATE_BLOCK_STRENGTH) return "STR";
   if(p.stateText == STATE_BLOCK_TREND)    return "TREND";
   if(p.stateText == STATE_BLOCK_SPREAD)   return "SPREAD";
   if(p.stateText == STATE_BLOCK_EXPOSURE) return "EXPOS";
   if(p.stateText == STATE_BLOCK_SESSION)  return "TIME";
   if(p.stateText == STATE_BLOCK_RISK)     return "RISK";
   if(p.hasBuyBasket || p.hasSellBasket)   return "LIVE";
   return "WAIT";
}

//+------------------------------------------------------------------+
color PairFilterColor(const PairData &p)
{
   string txt = PairFilterText(p);

   if(txt == "TRIG")   return tmdGreen;
   if(txt == "LIVE")   return (p.hasSellBasket ? tmdPurple : tmdCyan);
   if(txt == "TREND")  return tmdRed;
   if(txt == "RISK")   return tmdRed;
   if(txt == "WAIT")   return tmdOrange;
   return tmdOrange;
}

//+------------------------------------------------------------------+
void SortStrengthIndices(int &idx[])
{
   ArrayResize(idx, TMD_LITE_CURRENCY_COUNT);
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
      idx[i] = i;

   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT - 1; i++)
   {
      for(int j = i + 1; j < TMD_LITE_CURRENCY_COUNT; j++)
      {
         CurrencyStrengthData a, b;
         GetCurrencyStrengthData(TMD_CURRENCIES[idx[i]], a);
         GetCurrencyStrengthData(TMD_CURRENCIES[idx[j]], b);

         if(b.smoothedStrength > a.smoothedStrength)
         {
            int t = idx[i];
            idx[i] = idx[j];
            idx[j] = t;
         }
      }
   }
}

//+------------------------------------------------------------------+
int GetPanelSortRank(const PairData &p)
{
   if(p.hasBuyBasket || p.hasSellBasket)
      return 0;
   if(p.stateText == STATE_READY || p.stateText == STATE_TRG_BUY || p.stateText == STATE_TRG_SELL)
      return 1;
   return 2;
}

//+------------------------------------------------------------------+
void GetSortedPairIndicesForPanel(PairData &pairs[], int &indices[])
{
   int total = ArraySize(pairs);
   ArrayResize(indices, total);

   for(int i = 0; i < total; i++)
      indices[i] = i;

   for(int i = 0; i < total - 1; i++)
   {
      for(int j = i + 1; j < total; j++)
      {
         int ia = indices[i];
         int ib = indices[j];

         int ra = GetPanelSortRank(pairs[ia]);
         int rb = GetPanelSortRank(pairs[ib]);
         bool swap = false;

         if(rb < ra)
            swap = true;
         else if(ra == rb)
         {
            if(ra == 0)
            {
               double pa = GetPairGridPnL(pairs[ia]);
               double pb = GetPairGridPnL(pairs[ib]);
               if(pb > pa)
                  swap = true;
               else if(pb == pa && StringCompare(pairs[ia].symbol, pairs[ib].symbol) > 0)
                  swap = true;
            }
            else
            {
               if(StringCompare(pairs[ia].symbol, pairs[ib].symbol) > 0)
                  swap = true;
            }
         }

         if(swap)
         {
            int t = indices[i];
            indices[i] = indices[j];
            indices[j] = t;
         }
      }
   }
}

//+------------------------------------------------------------------+
void CreateTMDInfoPanel()
{
   DeleteAllPanelObjects(0);

   // main background: no bright border
   CreatePanelRect("BG", TMD_PANEL_X, TMD_PANEL_Y, TMD_PANEL_W, TMD_PANEL_H, C'10,16,28', C'10,16,28');
   CreatePanelRect("TB", 23, TOPBAR_Y, TMD_PANEL_W - 6, TOPBAR_H, C'10,16,28', C'10,16,28');

   // horizontal separators
   CreatePanelRect("S1", 30, SEP1_Y, 880, 1, tmdLineDim, tmdLineDim);
   CreatePanelRect("S2", 30, SEP2_Y, 880, 1, tmdLineDim, tmdLineDim);
   CreatePanelRect("S3", 30, SEP3_Y, 880, 1, tmdLineDim, tmdLineDim);

   // vertical separators: exactly matching height
   CreatePanelRect("SV1", 280, CUR_BLOCK_TOP, 1, CUR_BLOCK_H, tmdLineDim, tmdLineDim);
   CreatePanelRect("SV2", 470, CUR_BLOCK_TOP, 1, CUR_BLOCK_H, tmdLineDim, tmdLineDim);
   CreatePanelRect("SV3", 640, CUR_BLOCK_TOP, 1, CUR_BLOCK_H, tmdLineDim, tmdLineDim);

   // top bar
   CreatePanelLabel("ONLINE_DOT", 30, 40, 9, tmdOnline, "●");
   CreatePanelLabel("ONLINE_TXT", 42, 41, 9, tmdTeal, "ONLINE");
   CreatePanelLabel("SERVER_TXT", 100, 41, 9, tmdSilver, "--:--:--");
   CreatePanelLabel("TITLE", 470, 38, 11, tmdCyan, "◆ T M D  L I T E ◆", ANCHOR_UPPER);

   // account block
   CreatePanelLabel("L1", 30, 72, 9, tmdLabelDim, "BALANCE");
   CreatePanelLabel("V1", 185, 72, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L2", 30, 90, 9, tmdLabelDim, "EQUITY");
   CreatePanelLabel("V2", 185, 90, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L3", 30, 108, 9, tmdLabelDim, "P / L");
   CreatePanelLabel("V3", 185, 108, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("L4", 230, 72, 9, tmdLabelDim, "ACCOUNT");
   CreatePanelLabel("V4", 515, 72, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L5", 230, 90, 9, tmdLabelDim, "BROKER");
   CreatePanelLabel("V5", 515, 90, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L6", 230, 108, 9, tmdLabelDim, "LEVERAGE");
   CreatePanelLabel("V6", 515, 108, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("L7", 560, 72, 9, tmdLabelDim, "DD");
   CreatePanelLabel("V7", 760, 72, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L8", 560, 90, 9, tmdLabelDim, "FREE MARGIN");
   CreatePanelLabel("V8", 760, 90, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L9", 560, 108, 9, tmdLabelDim, "MARGIN %");
   CreatePanelLabel("V9", 760, 108, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   // currency section
   CreatePanelLabel("CUR_HDR", 30, 138, 9, tmdPurple, "CURRENCIES");
   CreatePanelLabel("CUR_HDR2", 210, 138, 8, tmdLabelDim, "STRENGTH", ANCHOR_RIGHT_UPPER);

   for(int i = 0; i < TMD_PANEL_CUR_ROWS; i++)
   {
      int y = 158 + i * 15;
      CreatePanelLabel("CUR_L_" + IntegerToString(i), 30, y, 9, tmdSilver, "-");
      CreatePanelLabel("CUR_V_" + IntegerToString(i), 210, y, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   }

   // config / runtime section (middle-left)
   CreatePanelLabel("CURM_L1", 300, 138, 8, tmdLabelDim, "POSITIONS");
   CreatePanelLabel("CURM_V1", 455, 138, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L2", 300, 153, 8, tmdLabelDim, "BASKETS");
   CreatePanelLabel("CURM_V2", 455, 153, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L3", 300, 168, 8, tmdLabelDim, "FLOATING");
   CreatePanelLabel("CURM_V3", 455, 168, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L4", 300, 183, 8, tmdLabelDim, "LOTS");
   CreatePanelLabel("CURM_V4", 455, 183, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L5", 300, 198, 8, tmdLabelDim, "TIMER");
   CreatePanelLabel("CURM_V5", 455, 198, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L6", 300, 213, 8, tmdLabelDim, "SETUP/TRIG");
   CreatePanelLabel("CURM_V6", 455, 213, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L7", 300, 228, 8, tmdLabelDim, "TREND TF");
   CreatePanelLabel("CURM_V7", 455, 228, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L8", 300, 243, 8, tmdLabelDim, "LOCK");
   CreatePanelLabel("CURM_V8", 455, 243, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L9", 300, 258, 8, tmdLabelDim, "STRENGTH TF");
   CreatePanelLabel("CURM_V9", 455, 258, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   // config section (middle)
   CreatePanelLabel("CFG_L1", 490, 138, 8, tmdLabelDim, "MIN GAP");
   CreatePanelLabel("CFG_V1", 620, 138, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L2", 490, 153, 8, tmdLabelDim, "PB ATR");
   CreatePanelLabel("CFG_V2", 620, 153, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L3", 490, 168, 8, tmdLabelDim, "GRID ATR");
   CreatePanelLabel("CFG_V3", 620, 168, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L4", 490, 183, 8, tmdLabelDim, "TP %");
   CreatePanelLabel("CFG_V4", 620, 183, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L5", 490, 198, 8, tmdLabelDim, "HARD STOP");
   CreatePanelLabel("CFG_V5", 620, 198, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L6", 490, 213, 8, tmdLabelDim, "MAX ORD");
   CreatePanelLabel("CFG_V6", 620, 213, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L7", 490, 228, 8, tmdLabelDim, "LOT MODE");
   CreatePanelLabel("CFG_V7", 620, 228, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L8", 490, 243, 8, tmdLabelDim, "LOT BAL");
   CreatePanelLabel("CFG_V8", 620, 243, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   // risk section (top-right)
   CreatePanelLabel("RISK_L1", 660, 138, 8, tmdLabelDim, "RISK STATE");
   CreatePanelLabel("RISK_V1", 840, 138, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("RISK_L2", 660, 153, 8, tmdLabelDim, "NEW ENTRIES");
   CreatePanelLabel("RISK_V2", 840, 153, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("RISK_L3", 660, 168, 8, tmdLabelDim, "GRID EXPAND");
   CreatePanelLabel("RISK_V3", 840, 168, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("RISK_L4", 660, 183, 8, tmdLabelDim, "RISK REASON");
   CreatePanelLabel("RISK_V4", 840, 183, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   // debug section (right side, BELOW risk/config, fits cleanly)
   CreatePanelLabel("DBG_L0", 660, 213, 8, tmdPurple,   "DEBUG");
   CreatePanelLabel("DBG_L1", 660, 228, 8, tmdLabelDim, "SCAN");
   CreatePanelLabel("DBG_V1", 840, 228, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("DBG_L2", 660, 243, 8, tmdLabelDim, "BLK T/S/P/T");
   CreatePanelLabel("DBG_V2", 840, 243, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("DBG_L3", 660, 258, 8, tmdLabelDim, "BLK X/R/M");
   CreatePanelLabel("DBG_V3", 840, 258, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("DBG_L4", 660, 273, 8, tmdLabelDim, "READY B/S");
   CreatePanelLabel("DBG_V4", 840, 273, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("DBG_L5", 660, 288, 8, tmdLabelDim, "OPEN/ADD");
   CreatePanelLabel("DBG_V5", 840, 288, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("DBG_L6", 660, 303, 8, tmdLabelDim, "TP/HS/BE/CL");
   CreatePanelLabel("DBG_V6", 840, 303, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   // symbol table header
   CreatePanelLabel("SYM_HDR",   30, 324, 9, tmdCyan, "Symbols");
   CreatePanelLabel("SYM_COL1", 255, 324, 8, tmdLabelDim, "GAP",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL2", 315, 324, 8, tmdLabelDim, "PB",    ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL3", 375, 324, 8, tmdLabelDim, "MOM",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL8", 435, 324, 8, tmdLabelDim, "TRG",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL10",490, 324, 8, tmdLabelDim, "SPR",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL6", 530, 324, 8, tmdLabelDim, "FLT");
   CreatePanelLabel("SYM_COL11",585, 324, 8, tmdLabelDim, "H1/H4");
   CreatePanelLabel("SYM_COL9", 650, 324, 8, tmdLabelDim, "STATE");
   CreatePanelLabel("SYM_COL4", 725, 324, 8, tmdLabelDim, "ORD",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL7", 790, 324, 8, tmdLabelDim, "LOTS",  ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL5", 865, 324, 8, tmdLabelDim, "P/L",   ANCHOR_RIGHT_UPPER);

   for(int i = 0; i < TMD_PANEL_SYM_ROWS; i++)
   {
      int y = 344 + i * 14;
      CreatePanelLabel("SYM_DOT_" + IntegerToString(i), 30,  y, 8, tmdSilver, "●");
      CreatePanelLabel("SYM_A_"   + IntegerToString(i), 42,  y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_B_"   + IntegerToString(i), 255, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_C_"   + IntegerToString(i), 315, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_D_"   + IntegerToString(i), 375, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_I_"   + IntegerToString(i), 435, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_K_"   + IntegerToString(i), 490, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_G_"   + IntegerToString(i), 530, y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_L_"   + IntegerToString(i), 585, y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_J_"   + IntegerToString(i), 650, y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_E_"   + IntegerToString(i), 725, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_H_"   + IntegerToString(i), 790, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_F_"   + IntegerToString(i), 865, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   }

   ChartRedraw();
}

//+------------------------------------------------------------------+
void UpdateTMDInfoPanel(PairData &pairs[],
                        const PortfolioStats &stats,
                        const DebugStats &dbg)
{
   bool eaOnline = IsEAOnline();

   SetPanelText("ONLINE_DOT", "●", eaOnline ? tmdOnline : tmdRed);
   SetPanelText("ONLINE_TXT", eaOnline ? "ONLINE" : "OFFLINE", eaOnline ? tmdTeal : tmdRed);
   SetPanelText("SERVER_TXT", GetServerTimeText(), tmdSilver);

   SetPanelText("V1", FormatMoneyPanel(stats.balance), tmdSilver);
   SetPanelText("V2", FormatMoneyPanel(stats.equity), tmdSilver);
   SetPanelText("V3", FormatMoneyPanel(stats.floatingPnl), GetPnlColor(stats.floatingPnl));

   SetPanelText("V4", AccountInfoString(ACCOUNT_NAME), tmdSilver);
   SetPanelText("V5", AccountInfoString(ACCOUNT_SERVER), tmdSilver);
   SetPanelText("V6", IntegerToString((int)AccountInfoInteger(ACCOUNT_LEVERAGE)), tmdTeal);

   color ddClr = tmdGreen;
   if(stats.drawdownPct >= 10.0) ddClr = tmdOrange;
   if(stats.drawdownPct >= 20.0) ddClr = tmdRed;

   SetPanelText("V7", FormatPctPanel(stats.drawdownPct, 2), ddClr);
   SetPanelText("V8", FormatMoneyPanel(stats.freeMargin), tmdSilver);
   SetPanelText("V9", FormatPctPanel(stats.marginLevel, 2), (stats.marginLevel < InpMinMarginLevelPct ? tmdOrange : tmdSilver));

   SetPanelText("CURM_V1", IntegerToString(stats.totalPositions), tmdSilver);
   SetPanelText("CURM_V2", IntegerToString(stats.totalBaskets), tmdSilver);
   SetPanelText("CURM_V3", FormatMoneyPanel(stats.floatingPnl), GetPnlColor(stats.floatingPnl));
   SetPanelText("CURM_V4", FormatLotsPanel(stats.totalLots), tmdSilver);
   SetPanelText("CURM_V5", IntegerToString(InpTimerSeconds) + "s", tmdTeal);
   SetPanelText("CURM_V6", TFToShortText(InpSetupTF) + "/" + TFToShortText(InpTriggerTF), tmdSilver);
   SetPanelText("CURM_V7", TFToShortText(InpTrendTF2) + "/" + TFToShortText(InpTrendTF1), tmdSilver);
   SetPanelText("CURM_V8", InpUseDirectionalCurrencyLock ? "ON" : "OFF", InpUseDirectionalCurrencyLock ? tmdGreen : tmdSilver);
   SetPanelText("CURM_V9", TFToShortText(InpStrengthTF), tmdSilver);

   SetPanelText("CFG_V1", Fmt2(InpMinStrengthGap), tmdSilver);
   SetPanelText("CFG_V2", Fmt2(InpMinPullbackATR) + "-" + Fmt2(InpMaxPullbackATR), tmdSilver);
   SetPanelText("CFG_V3", Fmt2(InpGridStepATR), tmdSilver);
   SetPanelText("CFG_V4", FormatPctPanel(InpBasketTargetPctBal, 2), tmdSilver);
   SetPanelText("CFG_V5", FormatPctPanel(InpBasketHardStopPctBal, 2), tmdSilver);
   SetPanelText("CFG_V6", IntegerToString(InpMaxOrdersPerBasket), tmdSilver);
   SetPanelText("CFG_V7", InpUseAutoLot ? (InpUseLotMultiplier ? "AUTO+MULT" : "AUTO") : (InpUseLotMultiplier ? "FIX+MULT" : "FIXED"), tmdSilver);
   SetPanelText("CFG_V8", Fmt0(InpBalancePer001Lot), tmdSilver);

   SetPanelText("RISK_V1", RiskStateToText(stats.riskState), GetRiskColor(stats.riskState));
   SetPanelText("RISK_V2", (stats.riskState == RISK_OK ? "ON" : "OFF"), (stats.riskState == RISK_OK ? tmdGreen : tmdOrange));
   SetPanelText("RISK_V3", (stats.riskState == RISK_OK ? "ON" : "OFF"), (stats.riskState == RISK_OK ? tmdGreen : tmdOrange));
   SetPanelText("RISK_V4", (stats.riskState == RISK_EMERGENCY ? "EMERG" : (stats.riskState == RISK_FREEZE ? "FROZEN" : "OK")), GetRiskColor(stats.riskState));

   // debug block
   SetPanelText("DBG_V1", IntegerToString(dbg.scannedPairs), tmdSilver);

   SetPanelText("DBG_V2",
                IntegerToString(dbg.blockedTrend) + "/" +
                IntegerToString(dbg.blockedStrength) + "/" +
                IntegerToString(dbg.blockedPullback) + "/" +
                IntegerToString(dbg.blockedTrigger),
                tmdSilver);

   SetPanelText("DBG_V3",
                IntegerToString(dbg.blockedExposure) + "/" +
                IntegerToString(dbg.blockedRisk) + "/" +
                IntegerToString(dbg.blockedSpread + dbg.blockedSession),
                tmdSilver);

   SetPanelText("DBG_V4",
                IntegerToString(dbg.readyBuy) + "/" +
                IntegerToString(dbg.readySell),
                tmdTeal);

   SetPanelText("DBG_V5",
                IntegerToString(dbg.openedBaskets) + "/" +
                IntegerToString(dbg.expandedBaskets),
                tmdCyan);

   SetPanelText("DBG_V6",
                IntegerToString(dbg.exitTP) + "/" +
                IntegerToString(dbg.exitHardStop) + "/" +
                IntegerToString(dbg.exitStaleBE) + "/" +
                IntegerToString(dbg.exitControlledLoss),
                (dbg.exitHardStop > 0 ? tmdRed : tmdOrange));

   int curIdx[];
   SortStrengthIndices(curIdx);

   for(int i = 0; i < TMD_PANEL_CUR_ROWS; i++)
   {
      if(i < ArraySize(curIdx))
      {
         CurrencyStrengthData s;
         GetCurrencyStrengthData(TMD_CURRENCIES[curIdx[i]], s);

         color c = tmdSilver;
         if(s.smoothedStrength > 0.5)       c = tmdGreen;
         else if(s.smoothedStrength < -0.5) c = tmdRed;
         else                               c = tmdOrange;

         SetPanelText("CUR_L_" + IntegerToString(i), IntegerToString(i + 1) + ". " + s.currency, c);
         SetPanelText("CUR_V_" + IntegerToString(i), Fmt2(s.smoothedStrength), c);
      }
      else
      {
         SetPanelText("CUR_L_" + IntegerToString(i), "-", tmdSilver);
         SetPanelText("CUR_V_" + IntegerToString(i), "-", tmdSilver);
      }
   }

   int sortedIdx[];
   GetSortedPairIndicesForPanel(pairs, sortedIdx);

   for(int i = 0; i < TMD_PANEL_SYM_ROWS; i++)
   {
      if(i < ArraySize(sortedIdx))
      {
         int p = sortedIdx[i];

         double gridPnl    = GetPairGridPnL(pairs[p]);
         int    openOrders = GetPairOpenOrders(pairs[p]);
         double openLots   = GetPairOpenLots(pairs[p]);
         double spreadPts  = pairs[p].spreadPoints;

         color pnlClr = GetPnlColor(gridPnl);

         color spreadClr = tmdSilver;
         if(spreadPts > 0.0)
         {
            double maxSpr = IsMetalSymbol(pairs[p].symbol) ? InpMaxSpreadPointsMetal : InpMaxSpreadPointsFX;

            if(spreadPts <= maxSpr * 0.75)
               spreadClr = tmdGreen;
            else if(spreadPts <= maxSpr)
               spreadClr = tmdOrange;
            else
               spreadClr = tmdRed;
         }

         string pairText  = pairs[p].symbol + " " + PairTrendComboText(pairs[p]);
         color  pairClr   = GetTrendColor(pairs[p].trendDir);
         color  dotClr    = GetDotColor(pairs[p]);
         string filterTxt = PairFilterText(pairs[p]);
         color  filterClr = PairFilterColor(pairs[p]);
         string trendTxt  = PairTrendComboText(pairs[p]);
         color  trendClr  = GetTrendColor(pairs[p].trendDir);
         string stateTxt  = pairs[p].stateText;
         color  stateClr  = GetStateColor(stateTxt);

         SetPanelText("SYM_DOT_" + IntegerToString(i), "●", dotClr);
         SetPanelText("SYM_A_"   + IntegerToString(i), pairText, pairClr);
         SetPanelText("SYM_B_"   + IntegerToString(i), Fmt2(pairs[p].strengthGap),
                      (MathAbs(pairs[p].strengthGap) >= InpMinStrengthGap ? tmdGreen : tmdOrange));
         SetPanelText("SYM_C_"   + IntegerToString(i), Fmt2(pairs[p].pullbackDepthAtr),
                      (pairs[p].inPullbackZone ? tmdTeal : tmdSilver));
         SetPanelText("SYM_D_"   + IntegerToString(i), Fmt2(pairs[p].strengthGapDelta),
                      (pairs[p].strengthGapDelta >= 0.0 ? tmdGreen : tmdOrange));
         SetPanelText("SYM_I_"   + IntegerToString(i),
                      (pairs[p].triggerBuy || pairs[p].triggerSell ? "YES" : "-"),
                      (pairs[p].triggerBuy || pairs[p].triggerSell ? tmdGreen : tmdSilver));
         SetPanelText("SYM_K_"   + IntegerToString(i),
                      (spreadPts >= 0.0 ? Fmt1(spreadPts) : "-"),
                      spreadClr);
         SetPanelText("SYM_G_"   + IntegerToString(i), filterTxt, filterClr);
         SetPanelText("SYM_L_"   + IntegerToString(i), trendTxt, trendClr);
         SetPanelText("SYM_J_"   + IntegerToString(i), stateTxt, stateClr);
         SetPanelText("SYM_E_"   + IntegerToString(i), IntegerToString(openOrders),
                      (openOrders > 0 ? tmdCyan : tmdSilver));
         SetPanelText("SYM_H_"   + IntegerToString(i), FormatLotsPanel(openLots),
                      (openLots > 0.0 ? tmdCyan : tmdSilver));
         SetPanelText("SYM_F_"   + IntegerToString(i), FormatMoneyPanel(gridPnl), pnlClr);
      }
      else
      {
         SetPanelText("SYM_DOT_" + IntegerToString(i), "●", tmdSilver);
         SetPanelText("SYM_A_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_B_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_C_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_D_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_I_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_K_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_G_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_L_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_J_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_E_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_H_"   + IntegerToString(i), "-", tmdSilver);
         SetPanelText("SYM_F_"   + IntegerToString(i), "-", tmdSilver);
      }
   }

   ChartRedraw();
}

//+------------------------------------------------------------------+
void RenderPanel(PairData &pairs[],
                 const PortfolioStats &stats,
                 const DebugStats &dbg,
                 const long chartId = 0)
{
   if(ArraySize(gPanelObjects) == 0)
      CreateTMDInfoPanel();

   UpdateTMDInfoPanel(pairs, stats, dbg);
}

//+------------------------------------------------------------------+
void RefreshPanel(PairData &pairs[],
                  const PortfolioStats &stats,
                  const DebugStats &dbg,
                  const long chartId = 0)
{
   RenderPanel(pairs, stats, dbg, chartId);
}

#endif // __TMD_LITE_PANEL_MQH__