#ifndef __TMD_LITE_EXPOSURE_MQH__
#define __TMD_LITE_EXPOSURE_MQH__

#include "Structs.mqh"
#include "Symbols.mqh"
#include "Utils.mqh"

//+------------------------------------------------------------------+
//| Runtime exposure table                                           |
//+------------------------------------------------------------------+
static CurrencyExposure g_currencyExposure[TMD_LITE_CURRENCY_COUNT];
static bool g_exposureInitialized = false;

//+------------------------------------------------------------------+
//| Reset exposure table                                             |
//+------------------------------------------------------------------+
void InitializeExposureState()
{
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
   {
      g_currencyExposure[i].currency        = TMD_CURRENCIES[i];
      g_currencyExposure[i].hasBuyExposure  = false;
      g_currencyExposure[i].hasSellExposure = false;
      g_currencyExposure[i].buySourceSymbol = "";
      g_currencyExposure[i].sellSourceSymbol= "";
      g_currencyExposure[i].buySourceMagic  = 0;
      g_currencyExposure[i].sellSourceMagic = 0;
   }

   g_exposureInitialized = true;
}

//+------------------------------------------------------------------+
//| Currency index lookup                                            |
//+------------------------------------------------------------------+
int GetExposureCurrencyIndex(const string currency)
{
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
   {
      if(TMD_CURRENCIES[i] == currency)
         return i;
   }

   return -1;
}

//+------------------------------------------------------------------+
//| Map order direction to currency exposure                         |
//| BUY EURUSD  => buy EUR, sell USD                                 |
//| SELL EURUSD => buy USD, sell EUR                                 |
//+------------------------------------------------------------------+
bool GetDirectionalExposure(const string symbol,
                            const int orderType,
                            string &buyCurrency,
                            string &sellCurrency)
{
   string base, quote;
   buyCurrency  = "";
   sellCurrency = "";

   if(!GetBaseQuoteCurrencies(symbol, base, quote))
      return false;

   if(orderType == ORDER_TYPE_BUY)
   {
      buyCurrency  = base;
      sellCurrency = quote;
      return true;
   }

   if(orderType == ORDER_TYPE_SELL)
   {
      buyCurrency  = quote;
      sellCurrency = base;
      return true;
   }

   return false;
}

//+------------------------------------------------------------------+
//| Mark one directional exposure                                    |
//+------------------------------------------------------------------+
void MarkCurrencyExposure(const string currency,
                          const int exposureDir,
                          const string sourceSymbol,
                          const ulong sourceMagic)
{
   int idx = GetExposureCurrencyIndex(currency);
   if(idx < 0)
      return;

   if(exposureDir == CCY_EXPOSURE_BUY)
   {
      g_currencyExposure[idx].hasBuyExposure = true;
      g_currencyExposure[idx].buySourceSymbol = sourceSymbol;
      g_currencyExposure[idx].buySourceMagic  = sourceMagic;
      return;
   }

   if(exposureDir == CCY_EXPOSURE_SELL)
   {
      g_currencyExposure[idx].hasSellExposure = true;
      g_currencyExposure[idx].sellSourceSymbol = sourceSymbol;
      g_currencyExposure[idx].sellSourceMagic  = sourceMagic;
      return;
   }
}

//+------------------------------------------------------------------+
//| Rebuild exposure table from current open positions               |
//| filterMagic=true -> only include this EA's positions             |
//+------------------------------------------------------------------+
void RebuildCurrencyExposureTable(const ulong magicBase = 0, const bool filterMagic = false)
{
   if(!g_exposureInitialized)
      InitializeExposureState();
   else
      InitializeExposureState();

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string symbol = PositionGetString(POSITION_SYMBOL);
      int    type   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  magic  = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(filterMagic && !IsOurMagic(magic, magicBase))
         continue;

      string buyCurrency, sellCurrency;
      if(!GetDirectionalExposure(symbol, type, buyCurrency, sellCurrency))
         continue;

      MarkCurrencyExposure(buyCurrency,  CCY_EXPOSURE_BUY,  symbol, magic);
      MarkCurrencyExposure(sellCurrency, CCY_EXPOSURE_SELL, symbol, magic);
   }
}

//+------------------------------------------------------------------+
//| Get one currency exposure record                                 |
//+------------------------------------------------------------------+
bool GetCurrencyExposureRecord(const string currency, CurrencyExposure &record)
{
   int idx = GetExposureCurrencyIndex(currency);
   if(idx < 0)
      return false;

   record = g_currencyExposure[idx];
   return true;
}

//+------------------------------------------------------------------+
//| Check candidate against currency exposure lock                   |
//| This checks NEW basket creation only                             |
//| Existing same-symbol same-direction basket can still add orders  |
//+------------------------------------------------------------------+
bool IsDirectionalExposureAllowed(const string candidateSymbol,
                                  const int candidateOrderType,
                                  string &rejectReason,
                                  string &conflictCurrency,
                                  string &conflictSymbol,
                                  const ulong magicBase = 0,
                                  const bool filterMagic = false)
{
   rejectReason     = "";
   conflictCurrency = "";
   conflictSymbol   = "";

   RebuildCurrencyExposureTable(magicBase, filterMagic);

   string buyCurrency, sellCurrency;
   if(!GetDirectionalExposure(candidateSymbol, candidateOrderType, buyCurrency, sellCurrency))
   {
      rejectReason = "Could not resolve directional exposure";
      return false;
   }

   int buyIdx  = GetExposureCurrencyIndex(buyCurrency);
   int sellIdx = GetExposureCurrencyIndex(sellCurrency);

   if(buyIdx < 0 || sellIdx < 0)
   {
      rejectReason = "Unknown currency in directional exposure";
      return false;
   }

   //--- same-direction buy exposure already exists elsewhere
   if(g_currencyExposure[buyIdx].hasBuyExposure)
   {
      string existingSymbol = g_currencyExposure[buyIdx].buySourceSymbol;

      if(existingSymbol != "" && existingSymbol != candidateSymbol)
      {
         rejectReason     = REASON_EXPOSURE;
         conflictCurrency = buyCurrency;
         conflictSymbol   = existingSymbol;
         return false;
      }
   }

   //--- same-direction sell exposure already exists elsewhere
   if(g_currencyExposure[sellIdx].hasSellExposure)
   {
      string existingSymbol = g_currencyExposure[sellIdx].sellSourceSymbol;

      if(existingSymbol != "" && existingSymbol != candidateSymbol)
      {
         rejectReason     = REASON_EXPOSURE;
         conflictCurrency = sellCurrency;
         conflictSymbol   = existingSymbol;
         return false;
      }
   }

   return true;
}

//+------------------------------------------------------------------+
//| Pair directional exposure flags                                  |
//| Evaluates both buy and sell possibility for this pair            |
//+------------------------------------------------------------------+
void UpdatePairExposureState(PairData &pair,
                             const bool useDirectionalCurrencyLock,
                             const ulong magicBase = 0,
                             const bool filterMagic = false)
{
   pair.exposureBuyOk  = true;
   pair.exposureSellOk = true;

   if(!useDirectionalCurrencyLock)
      return;

   string rejectReason, conflictCurrency, conflictSymbol;

   pair.exposureBuyOk = IsDirectionalExposureAllowed(pair.symbol,
                                                     ORDER_TYPE_BUY,
                                                     rejectReason,
                                                     conflictCurrency,
                                                     conflictSymbol,
                                                     magicBase,
                                                     filterMagic);

   if(!pair.exposureBuyOk && pair.trendDir == TREND_BUY)
   {
      pair.basketState = BASKET_BLOCKED_EXPOSURE;
      pair.stateText   = STATE_BLOCK_EXPOSURE;
      pair.blockReason = rejectReason + " [" + conflictCurrency + " via " + conflictSymbol + "]";
   }

   rejectReason     = "";
   conflictCurrency = "";
   conflictSymbol   = "";

   pair.exposureSellOk = IsDirectionalExposureAllowed(pair.symbol,
                                                      ORDER_TYPE_SELL,
                                                      rejectReason,
                                                      conflictCurrency,
                                                      conflictSymbol,
                                                      magicBase,
                                                      filterMagic);

   if(!pair.exposureSellOk && pair.trendDir == TREND_SELL)
   {
      pair.basketState = BASKET_BLOCKED_EXPOSURE;
      pair.stateText   = STATE_BLOCK_EXPOSURE;
      pair.blockReason = rejectReason + " [" + conflictCurrency + " via " + conflictSymbol + "]";
   }
}

//+------------------------------------------------------------------+
//| Helper for one direction                                         |
//+------------------------------------------------------------------+
bool PairExposureBuyOk(const PairData &pair)
{
   return pair.exposureBuyOk;
}

bool PairExposureSellOk(const PairData &pair)
{
   return pair.exposureSellOk;
}

//+------------------------------------------------------------------+
//| Optional text dump for logs / debugging                          |
//+------------------------------------------------------------------+
string ExposureRecordToText(const CurrencyExposure &e)
{
   string txt = e.currency + " | ";
   txt += "BUY=";
   txt += (e.hasBuyExposure ? "Y" : "N");
   txt += " (" + e.buySourceSymbol + ") | ";
   txt += "SELL=";
   txt += (e.hasSellExposure ? "Y" : "N");
   txt += " (" + e.sellSourceSymbol + ")";
   return txt;
}

//+------------------------------------------------------------------+
//| Print full exposure table                                        |
//+------------------------------------------------------------------+
void LogExposureTable()
{
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
      Print("TMD_Lite Exposure: ", ExposureRecordToText(g_currencyExposure[i]));
}

#endif // __TMD_LITE_EXPOSURE_MQH__