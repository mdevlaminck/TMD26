#ifndef __TMD_LITE_STRENGTH_MQH__
#define __TMD_LITE_STRENGTH_MQH__

#include "Structs.mqh"
#include "Config.mqh"
#include "Symbols.mqh"
#include "Utils.mqh"

//+------------------------------------------------------------------+
//| Strength settings / constants                                    |
//+------------------------------------------------------------------+
#define STRENGTH_DEFAULT_FAST_EMA         9
#define STRENGTH_DEFAULT_SLOW_EMA         28
#define STRENGTH_DEFAULT_ATR_PERIOD       14
#define STRENGTH_DEFAULT_LOOKBACK_BARS    6


//+------------------------------------------------------------------+
//| Strength runtime state                                           |
//+------------------------------------------------------------------+
static CurrencyStrengthData g_currencyStrengths[TMD_LITE_CURRENCY_COUNT];
static double g_strengthHistory[TMD_LITE_CURRENCY_COUNT][STRENGTH_HISTORY_SIZE];
static int    g_strengthHistoryCount[TMD_LITE_CURRENCY_COUNT];
static bool   g_strengthInitialized = false;

//+------------------------------------------------------------------+
//| Reset strength state                                             |
//+------------------------------------------------------------------+
void InitializeStrengthState()
{
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
   {
      g_currencyStrengths[i].currency         = TMD_CURRENCIES[i];
      g_currencyStrengths[i].currentStrength  = 0.0;
      g_currencyStrengths[i].smoothedStrength = 0.0;
      g_currencyStrengths[i].previousStrength = 0.0;
      g_currencyStrengths[i].momentum         = 0.0;
      g_currencyStrengths[i].acceleration     = 0.0;
      g_currencyStrengths[i].rank             = 0;
      g_currencyStrengths[i].valid            = true;

      g_strengthHistoryCount[i] = 0;

      for(int j = 0; j < STRENGTH_HISTORY_SIZE; j++)
         g_strengthHistory[i][j] = 0.0;
   }

   g_strengthInitialized = true;
}

//+------------------------------------------------------------------+
//| Currency index lookup                                            |
//+------------------------------------------------------------------+
int GetCurrencyIndex(const string currency)
{
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
   {
      if(TMD_CURRENCIES[i] == currency)
         return i;
   }

   return -1;
}

//+------------------------------------------------------------------+
//| Push value into fixed-size history                               |
//+------------------------------------------------------------------+
void PushStrengthHistory(const int idx, const double value)
{
   if(idx < 0 || idx >= TMD_LITE_CURRENCY_COUNT)
      return;

   int count = g_strengthHistoryCount[idx];

   if(count < STRENGTH_HISTORY_SIZE)
   {
      g_strengthHistory[idx][count] = value;
      g_strengthHistoryCount[idx]++;
      return;
   }

   for(int i = 0; i < STRENGTH_HISTORY_SIZE - 1; i++)
      g_strengthHistory[idx][i] = g_strengthHistory[idx][i + 1];

   g_strengthHistory[idx][STRENGTH_HISTORY_SIZE - 1] = value;
}

//+------------------------------------------------------------------+
//| Get weighted average of history                                  |
//+------------------------------------------------------------------+
double GetWeightedStrengthHistory(const int idx)
{
   if(idx < 0 || idx >= TMD_LITE_CURRENCY_COUNT)
      return 0.0;

   int count = g_strengthHistoryCount[idx];
   if(count <= 0)
      return 0.0;

   double weightedSum = 0.0;
   double weightTotal = 0.0;

   // Newer observations receive larger weights
   for(int i = 0; i < count; i++)
   {
      double weight = (double)(i + 1);
      weightedSum += g_strengthHistory[idx][i] * weight;
      weightTotal += weight;
   }

   return SafeDiv(weightedSum, weightTotal, 0.0);
}

//+------------------------------------------------------------------+
//| Return average momentum over recent history                      |
//+------------------------------------------------------------------+
double GetStrengthMomentumFromHistory(const int idx)
{
   if(idx < 0 || idx >= TMD_LITE_CURRENCY_COUNT)
      return 0.0;

   int count = g_strengthHistoryCount[idx];
   if(count < 2)
      return 0.0;

   double sumDelta = 0.0;
   int    deltaCnt = 0;

   for(int i = 1; i < count; i++)
   {
      sumDelta += (g_strengthHistory[idx][i] - g_strengthHistory[idx][i - 1]);
      deltaCnt++;
   }

   return SafeDiv(sumDelta, (double)deltaCnt, 0.0);
}

//+------------------------------------------------------------------+
//| Return simple acceleration from history                          |
//+------------------------------------------------------------------+
double GetStrengthAccelerationFromHistory(const int idx)
{
   if(idx < 0 || idx >= TMD_LITE_CURRENCY_COUNT)
      return 0.0;

   int count = g_strengthHistoryCount[idx];
   if(count < 3)
      return 0.0;

   double lastDelta = g_strengthHistory[idx][count - 1] - g_strengthHistory[idx][count - 2];
   double prevDelta = g_strengthHistory[idx][count - 2] - g_strengthHistory[idx][count - 3];

   return (lastDelta - prevDelta);
}

//+------------------------------------------------------------------+
//| Pair edge at one closed bar                                      |
//| Positive => base stronger than quote                             |
//+------------------------------------------------------------------+
double GetPairStrengthEdgeAtShift(const string symbol,
                                  const ENUM_TIMEFRAMES timeframe,
                                  const int fastEmaPeriod,
                                  const int slowEmaPeriod,
                                  const int atrPeriod,
                                  const int shift)
{
   double emaFast = GetEMA(symbol, timeframe, fastEmaPeriod, shift);
   double emaSlow = GetEMA(symbol, timeframe, slowEmaPeriod, shift);
   double atr     = GetATR(symbol, timeframe, atrPeriod, shift);

   if(emaFast <= 0.0 || emaSlow <= 0.0 || atr <= 0.0)
      return 0.0;

   double edge = (emaFast - emaSlow) / atr;

   // Clamp extreme outliers so one pair cannot dominate
   return ClampDouble(edge, -3.0, 3.0);
}

//+------------------------------------------------------------------+
//| History-aware pair strength edge                                 |
//| Weighted recent lookback on closed bars                          |
//+------------------------------------------------------------------+
double GetPairStrengthEdge(const string symbol,
                           const ENUM_TIMEFRAMES timeframe,
                           const int fastEmaPeriod,
                           const int slowEmaPeriod,
                           const int atrPeriod,
                           const int lookbackBars)
{
   if(lookbackBars < 1)
      return 0.0;

   double weightedSum = 0.0;
   double weightTotal = 0.0;

   // shift=1 is most recent closed bar
   // Larger weight for more recent bars
   for(int i = 0; i < lookbackBars; i++)
   {
      int shift = 1 + i;
      double edge = GetPairStrengthEdgeAtShift(symbol,
                                               timeframe,
                                               fastEmaPeriod,
                                               slowEmaPeriod,
                                               atrPeriod,
                                               shift);

      double weight = (double)(lookbackBars - i);
      weightedSum += edge * weight;
      weightTotal += weight;
   }

   return SafeDiv(weightedSum, weightTotal, 0.0);
}

//+------------------------------------------------------------------+
//| Update all currency strength values                              |
//+------------------------------------------------------------------+
void UpdateCurrencyStrengths(const string &brokerSymbols[],
                             const ENUM_TIMEFRAMES timeframe = PERIOD_H1,
                             const int fastEmaPeriod = STRENGTH_DEFAULT_FAST_EMA,
                             const int slowEmaPeriod = STRENGTH_DEFAULT_SLOW_EMA,
                             const int atrPeriod = STRENGTH_DEFAULT_ATR_PERIOD,
                             const int lookbackBars = STRENGTH_DEFAULT_LOOKBACK_BARS)
{
   if(!g_strengthInitialized)
      InitializeStrengthState();

   double rawSums[TMD_LITE_CURRENCY_COUNT];
   int    rawCounts[TMD_LITE_CURRENCY_COUNT];

   ArrayInitialize(rawSums, 0.0);
   ArrayInitialize(rawCounts, 0);

   //--- aggregate pair contributions
   for(int i = 0; i < TMD_LITE_SYMBOL_COUNT; i++)
   {
      string symbol = brokerSymbols[i];
      if(symbol == "")
         continue;

      if(!EnsureSymbolReady(symbol))
         continue;

      string base, quote;
      if(!GetBaseQuoteCurrencies(symbol, base, quote))
         continue;

      int baseIdx  = GetCurrencyIndex(base);
      int quoteIdx = GetCurrencyIndex(quote);

      if(baseIdx < 0 || quoteIdx < 0)
         continue;

      double edge = GetPairStrengthEdge(symbol,
                                        timeframe,
                                        fastEmaPeriod,
                                        slowEmaPeriod,
                                        atrPeriod,
                                        lookbackBars);

      rawSums[baseIdx]  += edge;
      rawCounts[baseIdx]++;

      rawSums[quoteIdx] -= edge;
      rawCounts[quoteIdx]++;
   }

   //--- finalize per currency
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
   {
      g_currencyStrengths[i].previousStrength = g_currencyStrengths[i].smoothedStrength;

      if(rawCounts[i] > 0)
      {
         g_currencyStrengths[i].currentStrength = SafeDiv(rawSums[i], (double)rawCounts[i], 0.0);
         g_currencyStrengths[i].valid           = true;
      }
      else
      {
         g_currencyStrengths[i].currentStrength = 0.0;
         g_currencyStrengths[i].valid           = false;
      }

      // push latest snapshot into short internal history
      PushStrengthHistory(i, g_currencyStrengths[i].currentStrength);

      // use weighted short history as smoothed strength
      g_currencyStrengths[i].smoothedStrength = GetWeightedStrengthHistory(i);
      g_currencyStrengths[i].momentum         = GetStrengthMomentumFromHistory(i);
      g_currencyStrengths[i].acceleration     = GetStrengthAccelerationFromHistory(i);
   }

   //--- ranking (higher smoothed strength = stronger)
   for(int i = 0; i < TMD_LITE_CURRENCY_COUNT; i++)
   {
      int rank = 1;
      for(int j = 0; j < TMD_LITE_CURRENCY_COUNT; j++)
      {
         if(i == j)
            continue;

         if(g_currencyStrengths[j].smoothedStrength > g_currencyStrengths[i].smoothedStrength)
            rank++;
      }

      g_currencyStrengths[i].rank = rank;
   }
}

//+------------------------------------------------------------------+
//| Get smoothed strength for one currency                           |
//+------------------------------------------------------------------+
double GetCurrencyStrength(const string currency)
{
   int idx = GetCurrencyIndex(currency);
   if(idx < 0)
      return 0.0;

   return g_currencyStrengths[idx].smoothedStrength;
}

//+------------------------------------------------------------------+
//| Get current unsmoothed strength                                  |
//+------------------------------------------------------------------+
double GetCurrencyCurrentStrength(const string currency)
{
   int idx = GetCurrencyIndex(currency);
   if(idx < 0)
      return 0.0;

   return g_currencyStrengths[idx].currentStrength;
}

//+------------------------------------------------------------------+
//| Get strength momentum                                            |
//+------------------------------------------------------------------+
double GetCurrencyStrengthMomentum(const string currency)
{
   int idx = GetCurrencyIndex(currency);
   if(idx < 0)
      return 0.0;

   return g_currencyStrengths[idx].momentum;
}

//+------------------------------------------------------------------+
//| Access full currency strength struct                             |
//+------------------------------------------------------------------+
bool GetCurrencyStrengthData(const string currency, CurrencyStrengthData &data)
{
   int idx = GetCurrencyIndex(currency);
   if(idx < 0)
      return false;

   data = g_currencyStrengths[idx];
   return true;
}

//+------------------------------------------------------------------+
//| Update strength fields in pair                                   |
//+------------------------------------------------------------------+
void UpdatePairStrength(PairData &pair, const double minStrengthGap)
{
   pair.strengthBase  = GetCurrencyStrength(pair.base);
   pair.strengthQuote = GetCurrencyStrength(pair.quote);

   double oldGap      = pair.strengthGap;
   pair.strengthGapPrev  = oldGap;
   pair.strengthGap      = pair.strengthBase - pair.strengthQuote;
   pair.strengthGapDelta = pair.strengthGap - pair.strengthGapPrev;

   pair.strengthBuyOk  = (pair.strengthGap >= minStrengthGap);
   pair.strengthSellOk = (pair.strengthGap <= -minStrengthGap);

   if(pair.trendDir == TREND_BUY && !pair.strengthBuyOk)
   {
      pair.basketState = BASKET_BLOCKED_STRENGTH;
      pair.stateText   = STATE_BLOCK_STRENGTH;
      pair.blockReason = REASON_STRENGTH;
   }
   else if(pair.trendDir == TREND_SELL && !pair.strengthSellOk)
   {
      pair.basketState = BASKET_BLOCKED_STRENGTH;
      pair.stateText   = STATE_BLOCK_STRENGTH;
      pair.blockReason = REASON_STRENGTH;
   }
}

//+------------------------------------------------------------------+
//| Helpers                                                          |
//+------------------------------------------------------------------+
bool PairStrengthBuyOk(const PairData &pair)
{
   return pair.strengthBuyOk;
}

bool PairStrengthSellOk(const PairData &pair)
{
   return pair.strengthSellOk;
}

//+------------------------------------------------------------------+
//| Optional improvement filter: strength persistence                |
//| Returns true if the smoothed gap and its delta support direction |
//+------------------------------------------------------------------+
bool PairStrengthPersistent(const PairData &pair, const int direction)
{
   if(direction == TREND_BUY)
      return (pair.strengthGap > 0.0 || pair.strengthGapDelta >= 0.0);

   if(direction == TREND_SELL)
      return (pair.strengthGap < 0.0 || pair.strengthGapDelta <= 0.0);

   return false;
}

#endif // __TMD_LITE_STRENGTH_MQH__