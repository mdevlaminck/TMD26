#ifndef __TMD_LITE_RISK_MQH__
#define __TMD_LITE_RISK_MQH__

#include "Structs.mqh"
#include "Config.mqh"
#include "Symbols.mqh"
#include "Utils.mqh"



//+------------------------------------------------------------------+
//| Count active baskets using broker symbol map                     |
//+------------------------------------------------------------------+
int CountActiveBasketsMapped(const string &brokerSymbols[],
                             const ulong magicBase = 0,
                             const bool filterMagic = false)
{
   int count = 0;

   for(int i = 0; i < ArraySize(brokerSymbols); i++)
   {
      string symbol = brokerSymbols[i];
      if(symbol == "")
         continue;

      int buyCount  = CountPositionsBySymbolDirection(symbol, ORDER_TYPE_BUY,  magicBase, filterMagic);
      int sellCount = CountPositionsBySymbolDirection(symbol, ORDER_TYPE_SELL, magicBase, filterMagic);

      if(buyCount > 0)
         count++;
      if(sellCount > 0)
         count++;
   }

   return count;
}

//+------------------------------------------------------------------+
//| Spread relative to ATR                                           |
//| Returns a fraction, e.g. 0.10 = 10% of ATR                       |
//+------------------------------------------------------------------+
double GetSpreadToAtrFraction(const string symbol,
                              const ENUM_TIMEFRAMES timeframe,
                              const int atrPeriod)
{
   double atr   = GetATR(symbol, timeframe, atrPeriod, 1);
   double point = GetSymbolPointSafe(symbol);
   double spr   = GetSpreadPoints(symbol);

   if(atr <= 0.0 || point <= 0.0)
      return 999.0;

   double spreadPrice = spr * point;
   return SafeDiv(spreadPrice, atr, 999.0);
}

//+------------------------------------------------------------------+
//| Absolute + relative spread filter                                |
//+------------------------------------------------------------------+
bool IsSpreadOk(const string symbol,
                const ENUM_TIMEFRAMES atrTF,
                const int atrPeriod,
                const double maxSpreadPointsFX,
                const double maxSpreadPointsMetal,
                const double maxSpreadAtrFraction,
                double &spreadPoints,
                double &spreadToAtrFraction,
                string &rejectReason)
{
   spreadPoints        = GetSpreadPoints(symbol);
   spreadToAtrFraction = GetSpreadToAtrFraction(symbol, atrTF, atrPeriod);
   rejectReason        = REASON_OK;

   if(spreadPoints <= 0.0)
   {
      rejectReason = REASON_SPREAD;
      return false;
   }

   double maxSpreadPoints = IsMetalSymbol(symbol) ? maxSpreadPointsMetal : maxSpreadPointsFX;

   if(spreadPoints > maxSpreadPoints)
   {
      rejectReason = REASON_SPREAD;
      return false;
   }

   if(spreadToAtrFraction > maxSpreadAtrFraction)
   {
      rejectReason = REASON_SPREAD;
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Determine portfolio risk state                                   |
//+------------------------------------------------------------------+
int GetPortfolioRiskState(const double freezeDdPct,
                          const double emergencyDdPct,
                          const double minMarginLevelPct)
{
   double ddPct        = GetAccountDrawdownPct();
   double marginLevel  = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);

   if(ddPct >= emergencyDdPct)
      return RISK_EMERGENCY;

   if(ddPct >= freezeDdPct)
      return RISK_FREEZE;

   if(marginLevel > 0.0 && marginLevel < minMarginLevelPct)
      return RISK_FREEZE;

   return RISK_OK;
}

//+------------------------------------------------------------------+
//| Whether new entries are allowed under risk state                 |
//+------------------------------------------------------------------+
bool IsEntryAllowedByRiskState(const int riskState)
{
   return (riskState == RISK_OK);
}

//+------------------------------------------------------------------+
//| Whether basket expansions are allowed under risk state           |
//| For v1: same as new entries                                      |
//+------------------------------------------------------------------+
bool IsExpansionAllowedByRiskState(const int riskState)
{
   return (riskState == RISK_OK);
}

//+------------------------------------------------------------------+
//| Max positions check                                              |
//+------------------------------------------------------------------+
bool IsUnderMaxPositions(const int maxTotalPositions, string &rejectReason)
{
   rejectReason = REASON_OK;

   if(PositionsTotal() >= maxTotalPositions)
   {
      rejectReason = REASON_MAX_POSITIONS;
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Max lots check                                                   |
//+------------------------------------------------------------------+
bool IsUnderMaxLots(const double maxTotalLots,
                    const double plannedLotSize,
                    string &rejectReason)
{
   rejectReason = REASON_OK;

   double totalLots = GetTotalOpenLots();
   if((totalLots + plannedLotSize) > maxTotalLots)
   {
      rejectReason = REASON_MAX_LOTS;
      return false;
   }

   return true;
}
//+------------------------------------------------------------------+
//| Max baskets check                                                |
//+------------------------------------------------------------------+
bool IsUnderMaxBaskets(const string &brokerSymbols[],
                       const int maxBaskets,
                       string &rejectReason,
                       const ulong magicBase = 0,
                       const bool filterMagic = false)
{
   rejectReason = REASON_OK;

   int activeBaskets = CountActiveBasketsMapped(brokerSymbols, magicBase, filterMagic);
   if(activeBaskets >= maxBaskets)
   {
      rejectReason = REASON_MAX_BASKETS;
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Margin guard for opening one new order                           |
//+------------------------------------------------------------------+
bool HasSufficientMarginForOrder(const string symbol,
                                 const int orderType,
                                 const double lotSize,
                                 string &rejectReason)
{
   rejectReason = REASON_OK;

   double price = 0.0;
   if(orderType == ORDER_TYPE_BUY)
      price = SymbolInfoDouble(symbol, SYMBOL_ASK);
   else if(orderType == ORDER_TYPE_SELL)
      price = SymbolInfoDouble(symbol, SYMBOL_BID);

   if(price <= 0.0)
   {
      rejectReason = REASON_MARGIN;
      return false;
   }

   double marginRequired = 0.0;
   if(!OrderCalcMargin((ENUM_ORDER_TYPE)orderType, symbol, lotSize, price, marginRequired))
   {
      rejectReason = REASON_MARGIN;
      return false;
   }

   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(freeMargin <= marginRequired)
   {
      rejectReason = REASON_MARGIN;
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Session/calendar gate                                            |
//+------------------------------------------------------------------+
bool IsSessionOk(const bool blockLateFriday,
                 const bool blockEarlyMonday,
                 const bool blockJuly,
                 const bool blockYearEnd,
                 string &rejectReason)
{
   rejectReason = REASON_OK;

   if(IsTradingBlockedByCalendar(blockLateFriday,
                                 blockEarlyMonday,
                                 blockJuly,
                                 blockYearEnd))
   {
      rejectReason = REASON_SESSION;
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Update account/portfolio risk snapshot                           |
//+------------------------------------------------------------------+
void UpdateRiskSnapshot(PortfolioStats &stats,
                        const string &brokerSymbols[],
                        const double freezeDdPct,
                        const double emergencyDdPct,
                        const double minMarginLevelPct,
                        const ulong magicBase = 0,
                        const bool filterMagic = false)
{
   UpdatePortfolioStats(stats);

   stats.totalLots    = GetTotalOpenLots();
   stats.totalBaskets = CountActiveBasketsMapped(brokerSymbols, magicBase, filterMagic);
   stats.riskState    = GetPortfolioRiskState(freezeDdPct,
                                              emergencyDdPct,
                                              minMarginLevelPct);
}

//+------------------------------------------------------------------+
//| Update pair spread state                                         |
//+------------------------------------------------------------------+
void UpdatePairSpreadState(PairData &pair,
                           const ENUM_TIMEFRAMES atrTF,
                           const int atrPeriod,
                           const double maxSpreadPointsFX,
                           const double maxSpreadPointsMetal,
                           const double maxSpreadAtrFraction)
{
   string rejectReason = REASON_OK;

   pair.spreadOk = IsSpreadOk(pair.symbol,
                              atrTF,
                              atrPeriod,
                              maxSpreadPointsFX,
                              maxSpreadPointsMetal,
                              maxSpreadAtrFraction,
                              pair.spreadPoints,
                              pair.spreadToAtrM5,
                              rejectReason);

   if(!pair.spreadOk)
   {
      pair.basketState = BASKET_BLOCKED_SPREAD;
      pair.stateText   = STATE_BLOCK_SPREAD;
      pair.blockReason = rejectReason;
   }
}

//+------------------------------------------------------------------+
//| Update pair session state                                        |
//+------------------------------------------------------------------+
void UpdatePairSessionState(PairData &pair,
                            const bool blockLateFriday,
                            const bool blockEarlyMonday,
                            const bool blockJuly,
                            const bool blockYearEnd)
{
   string rejectReason = REASON_OK;

   pair.sessionOk = IsSessionOk(blockLateFriday,
                                blockEarlyMonday,
                                blockJuly,
                                blockYearEnd,
                                rejectReason);

   if(!pair.sessionOk)
   {
      pair.basketState = BASKET_BLOCKED_SESSION;
      pair.stateText   = STATE_BLOCK_SESSION;
      pair.blockReason = rejectReason;
   }
}

//+------------------------------------------------------------------+
//| Update pair account-risk gate                                    |
//| This is a portfolio gate, applied per pair for simplicity        |
//+------------------------------------------------------------------+
void UpdatePairRiskState(PairData &pair,
                         const PortfolioStats &stats)
{
   pair.riskOk = IsEntryAllowedByRiskState(stats.riskState);

   if(!pair.riskOk)
   {
      pair.basketState = BASKET_BLOCKED_RISK;
      pair.stateText   = STATE_BLOCK_RISK;

      if(stats.riskState == RISK_EMERGENCY)
         pair.blockReason = REASON_EMERGENCY_DD;
      else
         pair.blockReason = REASON_FREEZE_DD;
   }
}

//+------------------------------------------------------------------+
//| Full pre-entry risk gate                                         |
//| Checks account state + symbol spread + session + limits + margin |
//+------------------------------------------------------------------+
bool IsCandidateAllowedByRisk(const EntryCandidate &candidate,
                              const string &brokerSymbols[],
                              const PortfolioStats &stats,
                              const int maxTotalPositions,
                              const double maxTotalLots,
                              const int maxBaskets,
                              const double plannedLotSize,
                              const bool blockLateFriday,
                              const bool blockEarlyMonday,
                              const bool blockJuly,
                              const bool blockYearEnd,
                              string &rejectReason,
                              const ulong magicBase = 0,
                              const bool filterMagic = false)
{
   rejectReason = REASON_OK;

   if(!IsEntryAllowedByRiskState(stats.riskState))
   {
      rejectReason = (stats.riskState == RISK_EMERGENCY) ? REASON_EMERGENCY_DD : REASON_FREEZE_DD;
      return false;
   }

   if(!IsUnderMaxPositions(maxTotalPositions, rejectReason))
      return false;

   if(!IsUnderMaxLots(maxTotalLots, plannedLotSize, rejectReason))
      return false;

   if(!IsUnderMaxBaskets(brokerSymbols, maxBaskets, rejectReason, magicBase, filterMagic))
      return false;

   if(!IsSessionOk(blockLateFriday, blockEarlyMonday, blockJuly, blockYearEnd, rejectReason))
      return false;

   int orderType = (candidate.direction == TREND_SELL) ? ORDER_TYPE_SELL : ORDER_TYPE_BUY;

   if(!HasSufficientMarginForOrder(candidate.symbol, orderType, plannedLotSize, rejectReason))
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| Expansion gate                                                   |
//| For add-ons: positions and baskets are not checked the same way  |
//+------------------------------------------------------------------+
bool IsBasketExpansionAllowed(const string symbol,
                              const int orderType,
                              const double plannedLotSize,
                              const PortfolioStats &stats,
                              const double maxTotalLots,
                              const bool blockLateFriday,
                              const bool blockEarlyMonday,
                              const bool blockJuly,
                              const bool blockYearEnd,
                              string &rejectReason)
{
   rejectReason = REASON_OK;

   if(!IsExpansionAllowedByRiskState(stats.riskState))
   {
      rejectReason = (stats.riskState == RISK_EMERGENCY) ? REASON_EMERGENCY_DD : REASON_FREEZE_DD;
      return false;
   }

   if(!IsUnderMaxLots(maxTotalLots, plannedLotSize, rejectReason))
      return false;

   if(!IsSessionOk(blockLateFriday, blockEarlyMonday, blockJuly, blockYearEnd, rejectReason))
      return false;

   if(!HasSufficientMarginForOrder(symbol, orderType, plannedLotSize, rejectReason))
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| Emergency-close condition                                        |
//+------------------------------------------------------------------+
bool IsEmergencyCloseRequired(const PortfolioStats &stats)
{
   return (stats.riskState == RISK_EMERGENCY);
}

#endif // __TMD_LITE_RISK_MQH__