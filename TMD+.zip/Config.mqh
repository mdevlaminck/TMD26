#ifndef __TMD_LITE_CONFIG_MQH__
#define __TMD_LITE_CONFIG_MQH__

//+------------------------------------------------------------------+
//| Core universe                                                    |
//+------------------------------------------------------------------+
#define TMD_LITE_CURRENCY_COUNT 10
#define TMD_LITE_SYMBOL_COUNT   30

static const string TMD_CURRENCIES[TMD_LITE_CURRENCY_COUNT] =
{
   "USD",
   "EUR",
   "GBP",
   "JPY",
   "CHF",
   "AUD",
   "NZD",
   "CAD",
   "XAU",
   "XAG"
};

static const string TMD_SYMBOLS[TMD_LITE_SYMBOL_COUNT] =
{
   "EURUSD",
   "GBPUSD",
   "AUDUSD",
   "NZDUSD",
   "USDJPY",
   "USDCHF",
   "USDCAD",

   "EURGBP",
   "EURAUD",
   "EURNZD",
   "EURJPY",
   "EURCHF",
   "EURCAD",

   "GBPAUD",
   "GBPNZD",
   "GBPJPY",
   "GBPCHF",
   "GBPCAD",

   "AUDNZD",
   "AUDJPY",
   "AUDCHF",
   "AUDCAD",

   "NZDJPY",
   "NZDCHF",
   "NZDCAD",

   "CADJPY",
   "CADCHF",
   "CHFJPY",

   "XAUUSD",
   "XAGUSD"
};

//+------------------------------------------------------------------+
//| Instrument classification                                        |
//+------------------------------------------------------------------+
enum ENUM_SYMBOL_CLASS
{
   SYMBOL_CLASS_UNKNOWN = 0,
   SYMBOL_CLASS_FX,
   SYMBOL_CLASS_METAL
};

//+------------------------------------------------------------------+
//| Panel / UI constants                                             |
//+------------------------------------------------------------------+
#define PANEL_PREFIX         "TMDL_"
#define PANEL_HEADER_ROWS    6
#define PANEL_STRENGTH_ROWS  10
#define PANEL_SYMBOL_ROWS    30

#define PANEL_ROW_HEIGHT     18
#define PANEL_COL1_X         10
#define PANEL_COL2_X         145
#define PANEL_COL3_X         255
#define PANEL_COL4_X         355
#define PANEL_START_Y        20

//+------------------------------------------------------------------+
//| Magic helpers                                                    |
//+------------------------------------------------------------------+
#define MAGIC_BUY_OFFSET     1000
#define MAGIC_SELL_OFFSET    2000

//+------------------------------------------------------------------+
//| State labels                                                     |
//+------------------------------------------------------------------+
#define STATE_READY          "READY"
#define STATE_PB_BUY         "PB BUY"
#define STATE_PB_SELL        "PB SELL"
#define STATE_TRG_BUY        "TRG BUY"
#define STATE_TRG_SELL       "TRG SELL"
#define STATE_GRID_BUY       "GRID BUY"
#define STATE_GRID_SELL      "GRID SELL"
#define STATE_BLOCK_SPREAD   "BLOCK SPR"
#define STATE_BLOCK_RISK     "BLOCK RISK"
#define STATE_BLOCK_EXPOSURE "BLOCK EXP"
#define STATE_BLOCK_SESSION  "BLOCK SES"
#define STATE_BLOCK_STRENGTH "BLOCK STR"
#define STATE_BLOCK_TREND    "BLOCK TRD"
#define STATE_BLOCK_PULLBACK "BLOCK PB"
#define STATE_BLOCK_TRIGGER  "BLOCK TRG"
#define STATE_STALE          "STALE"

//+------------------------------------------------------------------+
//| Log / reason labels                                              |
//+------------------------------------------------------------------+
#define REASON_OK            "OK"
#define REASON_SPREAD        "Spread filter"
#define REASON_RISK          "Risk filter"
#define REASON_EXPOSURE      "Directional currency lock"
#define REASON_SESSION       "Session / calendar block"
#define REASON_STRENGTH      "Strength filter"
#define REASON_TREND         "Trend filter"
#define REASON_PULLBACK      "Pullback filter"
#define REASON_TRIGGER       "Trigger filter"
#define REASON_MAX_POSITIONS "Max positions reached"
#define REASON_MAX_LOTS      "Max lots reached"
#define REASON_MAX_BASKETS   "Max baskets reached"
#define REASON_MARGIN        "Margin protection"
#define REASON_FREEZE_DD     "Freeze DD active"
#define REASON_EMERGENCY_DD  "Emergency DD active"

//+------------------------------------------------------------------+
//| Strength internal constants                                      |
//+------------------------------------------------------------------+
#define STRENGTH_HISTORY_SIZE 8

//+------------------------------------------------------------------+
//| === Broker Settings ===                                          |
//+------------------------------------------------------------------+
input group "=== Broker Settings ===";
input string InpBrokerSymbolSuffix = "";
input string InpBrokerSymbolPrefix = "";
input bool   InpPreferSuffix       = true;

//+------------------------------------------------------------------+
//| === General ===                                                  |
//+------------------------------------------------------------------+
input group "=== General ===";
input ulong  InpMagicBase          = 260401;
input int    InpTimerSeconds       = 5;
input bool   InpEnableLogging      = false;
input bool   InpFilterByMagicOnly  = true;

//+------------------------------------------------------------------+
//| === Trend Settings ===                                           |
//+------------------------------------------------------------------+
input group "=== Trend Settings ===";
input ENUM_TIMEFRAMES InpTrendTF1  = PERIOD_H4;
input ENUM_TIMEFRAMES InpTrendTF2  = PERIOD_H1;
input int    InpTrendFastEMA       = 50;
input int    InpTrendSlowEMA       = 200;
input bool   InpRequireTrendSlope  = false;

//+------------------------------------------------------------------+
//| === Strength Settings ===                                        |
//+------------------------------------------------------------------+
input group "=== Strength Settings ===";
input ENUM_TIMEFRAMES InpStrengthTF      = PERIOD_H1;
input int    InpStrengthFastEMA          = 9;
input int    InpStrengthSlowEMA          = 28;
input int    InpStrengthATRPeriod        = 14;
input int    InpStrengthLookbackBars     = 6;
input double InpMinStrengthGap           = 0.60;

//+------------------------------------------------------------------+
//| === Entry Settings ===                                           |
//+------------------------------------------------------------------+
input group "=== Entry Settings ===";
input ENUM_TIMEFRAMES InpSetupTF         = PERIOD_M15;
input ENUM_TIMEFRAMES InpTriggerTF       = PERIOD_M5;
input int    InpPullbackEMAPeriod        = 20;
input int    InpTriggerEMAPeriod         = 9;
input int    InpATRPeriod                = 14;
input double InpMinPullbackATR           = 0.25;
input double InpMaxPullbackATR           = 1.50;

//+------------------------------------------------------------------+
//| === Grid Settings ===                                            |
//+------------------------------------------------------------------+
input group "=== Grid Settings ===";
input double InpGridStepATR              = 0.75;
input int    InpMaxOrdersPerBasket       = 4;
input int    InpMinSecondsBetweenAdds    = 180;
input bool   InpUseLotMultiplier         = false;
input double InpLotMultiplier            = 1.20;

//+------------------------------------------------------------------+
//| === Lot Settings ===                                             |
//+------------------------------------------------------------------+
input group "=== Lot Settings ===";
input bool   InpUseAutoLot               = true;
input double InpBalancePer001Lot         = 1000.0;
input double InpFixedLot                 = 0.01;

//+------------------------------------------------------------------+
//| === Risk Settings ===                                            |
//+------------------------------------------------------------------+
input group "=== Risk Settings ===";
input int    InpMaxTotalPositions        = 20;
input double InpMaxTotalLots             = 2.0;
input int    InpMaxBaskets               = 10;
input double InpFreezeDDPercent          = 5.0;
input double InpEmergencyDDPercent       = 10.0;
input double InpMinMarginLevelPct        = 200.0;

//+------------------------------------------------------------------+
//| === Spread Control ===                                           |
//+------------------------------------------------------------------+
input group "=== Spread Control ===";
input double InpMaxSpreadPointsFX        = 25.0;
input double InpMaxSpreadPointsMetal     = 50.0;
input double InpMaxSpreadToATR           = 0.15;

//+------------------------------------------------------------------+
//| === Session / Calendar Filters ===                               |
//+------------------------------------------------------------------+
input group "=== Session / Calendar Filters ===";
input bool   InpBlockLateFriday          = true;
input bool   InpBlockEarlyMonday         = true;
input bool   InpBlockJuly                = true;
input bool   InpBlockYearEnd             = true;

//+------------------------------------------------------------------+
//| === Exit Settings ===                                            |
//+------------------------------------------------------------------+
input group "=== Exit Settings ===";
input double InpBasketTargetPctBal       = 0.12;
input double InpBasketHardStopPctBal     = 0.60;
input double InpTimeExitStartDays        = 1.0;
input double InpLossAcceptDays           = 2.0;
input int    InpMinOrdersForTimeExit     = 2;
input double InpAllowedLossClosePctBal   = 0.25;
input bool   InpUsePortfolioNetExit      = true;
input double InpPortfolioNetTargetPct    = 0.20;

//+------------------------------------------------------------------+
//| === Exposure Control ===                                         |
//+------------------------------------------------------------------+
input group "=== Exposure Control ===";
input bool   InpUseDirectionalCurrencyLock = true;

input group "=== Debug Logging ===";
input bool InpEnableDebugSummary = true;
input int  InpDebugPrintEveryN   = 100;   // print every N cycles

#endif // __TMD_LITE_CONFIG_MQH__