#ifndef __TMD_LITE_TREND_MQH__
#define __TMD_LITE_TREND_MQH__

#include "Structs.mqh"
#include "Utils.mqh"

//+------------------------------------------------------------------+
//| Trend model result                                               |
//+------------------------------------------------------------------+
struct TrendSnapshot
{
   int    direction;
   bool   valid;

   double h1Close;
   double h4Close;

   double h1FastEma;
   double h1SlowEma;
   double h4FastEma;
   double h4SlowEma;

   double h1FastSlope;
   double h1SlowSlope;
};

//+------------------------------------------------------------------+
//| Return EMA slope between closed bars                             |
//| Positive = rising, negative = falling                            |
//+------------------------------------------------------------------+
double GetEMASlope(const string symbol,
                   const ENUM_TIMEFRAMES timeframe,
                   const int period,
                   const int shift_now = 1,
                   const int shift_prev = 2)
{
   double emaNow  = GetEMA(symbol, timeframe, period, shift_now);
   double emaPrev = GetEMA(symbol, timeframe, period, shift_prev);

   if(emaNow <= 0.0 || emaPrev <= 0.0)
      return 0.0;

   return (emaNow - emaPrev);
}

//+------------------------------------------------------------------+
//| Strong bullish trend test                                        |
//+------------------------------------------------------------------+
bool IsBullTrend(const TrendSnapshot &t, const bool requireSlope)
{
   bool structureOk =
      (t.h4Close   > t.h4SlowEma) &&
      (t.h1Close   > t.h1SlowEma) &&
      (t.h1FastEma > t.h1SlowEma);

   if(!structureOk)
      return false;

   if(requireSlope && t.h1FastSlope <= 0.0)
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| Strong bearish trend test                                        |
//+------------------------------------------------------------------+
bool IsSellTrend(const TrendSnapshot &t, const bool requireSlope)
{
   bool structureOk =
      (t.h4Close   < t.h4SlowEma) &&
      (t.h1Close   < t.h1SlowEma) &&
      (t.h1FastEma < t.h1SlowEma);

   if(!structureOk)
      return false;

   if(requireSlope && t.h1FastSlope >= 0.0)
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| Build trend snapshot from H4/H1                                  |
//| Uses closed candles only                                         |
//+------------------------------------------------------------------+
bool BuildTrendSnapshot(const string symbol,
                        const ENUM_TIMEFRAMES trendTF1,
                        const ENUM_TIMEFRAMES trendTF2,
                        const int fastPeriod,
                        const int slowPeriod,
                        TrendSnapshot &snap)
{
   snap.direction   = TREND_NONE;
   snap.valid       = false;

   snap.h1Close     = 0.0;
   snap.h4Close     = 0.0;
   snap.h1FastEma   = 0.0;
   snap.h1SlowEma   = 0.0;
   snap.h4FastEma   = 0.0;
   snap.h4SlowEma   = 0.0;
   snap.h1FastSlope = 0.0;
   snap.h1SlowSlope = 0.0;

   //--- by design:
   // trendTF1 = higher TF, typically H4
   // trendTF2 = lower trend TF, typically H1

   snap.h4Close   = GetClosePrice(symbol, trendTF1, 1);
   snap.h1Close   = GetClosePrice(symbol, trendTF2, 1);

   snap.h4FastEma = GetEMA(symbol, trendTF1, fastPeriod, 1);
   snap.h4SlowEma = GetEMA(symbol, trendTF1, slowPeriod, 1);

   snap.h1FastEma = GetEMA(symbol, trendTF2, fastPeriod, 1);
   snap.h1SlowEma = GetEMA(symbol, trendTF2, slowPeriod, 1);

   snap.h1FastSlope = GetEMASlope(symbol, trendTF2, fastPeriod, 1, 2);
   snap.h1SlowSlope = GetEMASlope(symbol, trendTF2, slowPeriod, 1, 2);

   if(snap.h4Close   <= 0.0 || snap.h1Close   <= 0.0 ||
      snap.h4FastEma <= 0.0 || snap.h4SlowEma <= 0.0 ||
      snap.h1FastEma <= 0.0 || snap.h1SlowEma <= 0.0)
   {
      return false;
   }

   snap.valid = true;
   return true;
}

//+------------------------------------------------------------------+
//| Resolve trend direction                                          |
//+------------------------------------------------------------------+
int GetTrendDirection(const string symbol,
                      const ENUM_TIMEFRAMES trendTF1,
                      const ENUM_TIMEFRAMES trendTF2,
                      const int fastPeriod,
                      const int slowPeriod,
                      const bool requireSlope,
                      TrendSnapshot &snap)
{
   if(!BuildTrendSnapshot(symbol, trendTF1, trendTF2, fastPeriod, slowPeriod, snap))
      return TREND_NONE;

   if(IsBullTrend(snap, requireSlope))
   {
      snap.direction = TREND_BUY;
      return TREND_BUY;
   }

   if(IsSellTrend(snap, requireSlope))
   {
      snap.direction = TREND_SELL;
      return TREND_SELL;
   }

   snap.direction = TREND_NONE;
   return TREND_NONE;
}

//+------------------------------------------------------------------+
//| Update pair trend fields                                         |
//+------------------------------------------------------------------+
void UpdatePairTrend(PairData &pair,
                     const ENUM_TIMEFRAMES trendTF1,
                     const ENUM_TIMEFRAMES trendTF2,
                     const int fastPeriod,
                     const int slowPeriod,
                     const bool requireSlope)
{
   TrendSnapshot snap;
   int dir = GetTrendDirection(pair.symbol,
                               trendTF1,
                               trendTF2,
                               fastPeriod,
                               slowPeriod,
                               requireSlope,
                               snap);

   pair.trendDir      = dir;
   pair.trendValid    = (dir != TREND_NONE && snap.valid);

   pair.trendFastEMA_H1 = snap.h1FastEma;
   pair.trendSlowEMA_H1 = snap.h1SlowEma;
   pair.trendFastEMA_H4 = snap.h4FastEma;
   pair.trendSlowEMA_H4 = snap.h4SlowEma;

   if(!snap.valid)
   {
      pair.basketState = BASKET_BLOCKED_TREND;
      pair.stateText   = STATE_BLOCK_TREND;
      pair.blockReason = REASON_TREND;
      return;
   }

   if(dir == TREND_NONE)
   {
      pair.basketState = BASKET_BLOCKED_TREND;
      pair.stateText   = STATE_BLOCK_TREND;
      pair.blockReason = REASON_TREND;
      return;
   }
}

//+------------------------------------------------------------------+
//| Helper: bullish trend valid for pair                             |
//+------------------------------------------------------------------+
bool PairTrendBuyOk(const PairData &pair)
{
   return (pair.trendValid && pair.trendDir == TREND_BUY);
}

//+------------------------------------------------------------------+
//| Helper: bearish trend valid for pair                             |
//+------------------------------------------------------------------+
bool PairTrendSellOk(const PairData &pair)
{
   return (pair.trendValid && pair.trendDir == TREND_SELL);
}

//+------------------------------------------------------------------+
//| Optional trend label for panel                                   |
//+------------------------------------------------------------------+
string TrendDirToText(const int dir)
{
   switch(dir)
   {
      case TREND_BUY:  return "BUY";
      case TREND_SELL: return "SELL";
   }

   return "NONE";
}

#endif // __TMD_LITE_TREND_MQH__