#ifndef __TMD_LITE_CHARTSTYLE_MQH__
#define __TMD_LITE_CHARTSTYLE_MQH__

#include "Config.mqh"

// --- palette reused from old EA style ---
color tmdGreen    = C'38,166,154';
color tmdRed      = C'239,83,80';
color tmdOrange   = C'255,152,0';
color tmdSilver   = C'219,219,219';
color tmdBg       = C'16,26,37';
color tmdSubtleBg = C'42,58,79';
color tmdBid      = C'41,98,255';
color tmdAsk      = C'247,82,95';

color tmdLineDim  = C'34,48,66';
color tmdLabelDim = C'70,90,110';
color tmdCyan     = C'0,230,230';
color tmdTeal     = C'0,190,190';
color tmdOnline   = C'0,230,120';
color tmdGold     = C'255,215,0';
color tmdPurple   = C'180,40,220';
color tmdPanelBg  = C'8,14,24';

color tmdFrame = C'170,170,170';

string gPanelObjects[];

//+------------------------------------------------------------------+
//| tracked object helper                                            |
//+------------------------------------------------------------------+
void RegisterPanelObject(const string name)
{
   int n = ArraySize(gPanelObjects);
   ArrayResize(gPanelObjects, n + 1);
   gPanelObjects[n] = name;
}

//+------------------------------------------------------------------+
string PanelObjName(const string suffix)
{
   return PANEL_PREFIX + suffix;
}

//+------------------------------------------------------------------+
void DeleteAllPanelObjects(const long chartId = 0)
{
   for(int i = ArraySize(gPanelObjects) - 1; i >= 0; i--)
      ObjectDelete(chartId, gPanelObjects[i]);

   ArrayResize(gPanelObjects, 0);
}

//+------------------------------------------------------------------+
bool CreatePanelRect(const string key,
                     const int x,
                     const int y,
                     const int w,
                     const int h,
                     const color bg,
                     const color border,
                     const long chartId = 0)
{
   string name = PanelObjName(key);

   if(ObjectFind(chartId, name) < 0)
   {
      if(!ObjectCreate(chartId, name, OBJ_RECTANGLE_LABEL, 0, 0, 0))
         return false;
      RegisterPanelObject(name);
   }

   ObjectSetInteger(chartId, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(chartId, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(chartId, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(chartId, name, OBJPROP_XSIZE, w);
   ObjectSetInteger(chartId, name, OBJPROP_YSIZE, h);
   ObjectSetInteger(chartId, name, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(chartId, name, OBJPROP_BORDER_COLOR, border);
   ObjectSetInteger(chartId, name, OBJPROP_COLOR, bg);
   ObjectSetInteger(chartId, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(chartId, name, OBJPROP_BACK, false);
   ObjectSetInteger(chartId, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(chartId, name, OBJPROP_HIDDEN, true);
   return true;
}

//+------------------------------------------------------------------+
bool CreatePanelLabel(const string key,
                      const int x,
                      const int y,
                      const int size,
                      const color clr,
                      const string text,
                      const ENUM_ANCHOR_POINT anchor = ANCHOR_LEFT_UPPER,
                      const long chartId = 0)
{
   string name = PanelObjName(key);

   if(ObjectFind(chartId, name) < 0)
   {
      if(!ObjectCreate(chartId, name, OBJ_LABEL, 0, 0, 0))
         return false;
      RegisterPanelObject(name);
   }

   ObjectSetInteger(chartId, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(chartId, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(chartId, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(chartId, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(chartId, name, OBJPROP_FONTSIZE, size);
   ObjectSetInteger(chartId, name, OBJPROP_ANCHOR, anchor);
   ObjectSetString(chartId,  name, OBJPROP_FONT, "Consolas");
   ObjectSetString(chartId,  name, OBJPROP_TEXT, text);
   ObjectSetInteger(chartId, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(chartId, name, OBJPROP_HIDDEN, true);
   return true;
}

//+------------------------------------------------------------------+
void SetPanelText(const string key,
                  const string text,
                  const color clr,
                  const long chartId = 0)
{
   string name = PanelObjName(key);
   if(ObjectFind(chartId, name) < 0)
      return;

   ObjectSetString(chartId, name, OBJPROP_TEXT, text);
   ObjectSetInteger(chartId, name, OBJPROP_COLOR, clr);
}

//+------------------------------------------------------------------+
color GetRiskColor(const int riskState)
{
   if(riskState == RISK_OK)        return tmdGreen;
   if(riskState == RISK_FREEZE)    return tmdOrange;
   if(riskState == RISK_EMERGENCY) return tmdRed;
   return tmdSilver;
}

//+------------------------------------------------------------------+
color GetPnlColor(const double pnl)
{
   if(pnl > 0.0) return tmdGreen;
   if(pnl < 0.0) return tmdRed;
   return tmdSilver;
}

//+------------------------------------------------------------------+
color GetTrendColor(const int dir)
{
   if(dir == TREND_BUY)  return tmdGreen;
   if(dir == TREND_SELL) return tmdPurple;
   return tmdSilver;
}

//+------------------------------------------------------------------+
color GetStateColor(const string stateText)
{
   if(stateText == STATE_READY)          return tmdGreen;
   if(stateText == STATE_GRID_BUY)       return tmdCyan;
   if(stateText == STATE_GRID_SELL)      return tmdPurple;
   if(stateText == STATE_TRG_BUY)        return tmdGreen;
   if(stateText == STATE_TRG_SELL)       return tmdPurple;
   if(stateText == STATE_PB_BUY)         return tmdOrange;
   if(stateText == STATE_PB_SELL)        return tmdOrange;
   if(stateText == STATE_BLOCK_RISK)     return tmdRed;
   if(stateText == STATE_BLOCK_SPREAD)   return tmdOrange;
   if(stateText == STATE_BLOCK_EXPOSURE) return tmdOrange;
   if(stateText == STATE_BLOCK_SESSION)  return tmdOrange;
   if(stateText == STATE_BLOCK_STRENGTH) return tmdOrange;
   if(stateText == STATE_BLOCK_TREND)    return tmdRed;
   if(stateText == STATE_BLOCK_PULLBACK) return tmdOrange;
   if(stateText == STATE_BLOCK_TRIGGER)  return tmdOrange;
   if(stateText == STATE_STALE)          return tmdOrange;
   return tmdSilver;
}

//+------------------------------------------------------------------+
color GetDotColor(const PairData &pair)
{
   if(pair.hasBuyBasket)
      return (pair.buyProfit < 0.0 ? tmdOrange : tmdCyan);

   if(pair.hasSellBasket)
      return (pair.sellProfit < 0.0 ? tmdOrange : tmdPurple);

   if(pair.stateText == STATE_READY)
      return tmdGreen;

   if(pair.stateText == STATE_BLOCK_RISK || pair.stateText == STATE_BLOCK_TREND)
      return tmdRed;

   if(pair.stateText != STATE_READY)
      return tmdOrange;

   return tmdSilver;
}

//+------------------------------------------------------------------+
void ApplyChartStyle(const long chartId = 0)
{
   ChartSetInteger(chartId, CHART_COLOR_BACKGROUND, tmdBg);
   ChartSetInteger(chartId, CHART_COLOR_FOREGROUND, tmdSilver);
   ChartSetInteger(chartId, CHART_COLOR_GRID, tmdSubtleBg);
   ChartSetInteger(chartId, CHART_COLOR_CANDLE_BULL, tmdGreen);
   ChartSetInteger(chartId, CHART_COLOR_CANDLE_BEAR, tmdRed);
   ChartSetInteger(chartId, CHART_COLOR_CHART_UP, tmdGreen);
   ChartSetInteger(chartId, CHART_COLOR_CHART_DOWN, tmdRed);
   ChartSetInteger(chartId, CHART_COLOR_BID, tmdBid);
   ChartSetInteger(chartId, CHART_COLOR_ASK, tmdAsk);

   ChartSetInteger(chartId, CHART_SHOW_GRID, false);
   ChartSetInteger(chartId, CHART_SHOW_VOLUMES, false);
   ChartSetInteger(chartId, CHART_SHOW_PERIOD_SEP, false);
   ChartSetInteger(chartId, CHART_SHOW_OBJECT_DESCR, false);
   ChartSetInteger(chartId, CHART_SHOW_OHLC, true);
   ChartSetInteger(chartId, CHART_SHOW_ASK_LINE, true);
   ChartSetInteger(chartId, CHART_SHOW_BID_LINE, true);

   ChartSetInteger(chartId, CHART_MODE, CHART_CANDLES);
   ChartSetInteger(chartId, CHART_SCALE, 3);
   ChartSetInteger(chartId, CHART_AUTOSCROLL, true);
   ChartSetInteger(chartId, CHART_SHIFT, true);

   ChartRedraw(chartId);
}

//+------------------------------------------------------------------+
void ApplyChartLayout(const long chartId = 0)
{
   ApplyChartStyle(chartId);
}

#endif // __TMD_LITE_CHARTSTYLE_MQH__