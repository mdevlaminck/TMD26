#ifndef __TMD_LITE_EXIT_MQH__
#define __TMD_LITE_EXIT_MQH__

#include <Trade/Trade.mqh>

#include "Structs.mqh"
#include "Config.mqh"
#include "Symbols.mqh"
#include "Utils.mqh"
#include "Risk.mqh"

//+------------------------------------------------------------------+
//| Close all positions of one basket                                |
//+------------------------------------------------------------------+
bool CloseBasket(CTrade &trade,
                 const string symbol,
                 const int orderType,
                 string &resultReason,
                 const ulong magicBase = 0,
                 const bool filterMagic = false)
{
   bool hadAny = false;
   bool allOk  = true;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(posSymbol != symbol)
         continue;
      if(posType != orderType)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      hadAny = true;

      if(!trade.PositionClose(ticket))
         allOk = false;
   }

   if(!hadAny)
   {
      if(resultReason == "" || resultReason == REASON_OK)
         resultReason = "No basket positions found";
      return false;
   }

   if(!allOk)
   {
      resultReason = "One or more basket closes failed";
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Close all EA positions                                           |
//+------------------------------------------------------------------+
bool CloseAllManagedPositions(CTrade &trade,
                              string &resultReason,
                              const ulong magicBase = 0,
                              const bool filterMagic = false)
{
   bool hadAny = false;
   bool allOk  = true;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      ulong posMagic = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      hadAny = true;

      if(!trade.PositionClose(ticket))
         allOk = false;
   }

   if(!hadAny)
   {
      if(resultReason == "" || resultReason == REASON_OK)
         resultReason = "No managed positions found";
      return false;
   }

   if(!allOk)
   {
      resultReason = "One or more global closes failed";
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Basket TP in money                                               |
//| pct is true percent, e.g. 0.12 = 0.12% of balance                |
//+------------------------------------------------------------------+
bool IsBasketTargetHit(const BasketInfo &basket,
                       const double basketTargetPctBal)
{
   if(!basket.valid)
      return false;

   double targetMoney = PercentBalanceToMoney(basketTargetPctBal);
   if(targetMoney <= 0.0)
      return false;

   return (basket.netProfit >= targetMoney);
}

//+------------------------------------------------------------------+
//| Stale basket BE/profit exit                                      |
//+------------------------------------------------------------------+
bool IsBasketTimeExitReady(const BasketInfo &basket,
                           const double timeExitStartDays,
                           const int minOrdersForTimeExit)
{
   if(!basket.valid)
      return false;

   if(basket.orders < minOrdersForTimeExit)
      return false;

   if(basket.ageDays < timeExitStartDays)
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| Break-even or better stale close                                 |
//+------------------------------------------------------------------+
bool IsBasketBreakEvenCloseReady(const BasketInfo &basket,
                                 const double timeExitStartDays,
                                 const int minOrdersForTimeExit)
{
   if(!IsBasketTimeExitReady(basket, timeExitStartDays, minOrdersForTimeExit))
      return false;

   return (basket.netProfit >= 0.0);
}

//+------------------------------------------------------------------+
//| Controlled loss close                                            |
//| allowedLossClosePctBal is true percent of balance                |
//+------------------------------------------------------------------+
bool IsBasketControlledLossCloseReady(const BasketInfo &basket,
                                      const double lossAcceptDays,
                                      const int minOrdersForTimeExit,
                                      const double allowedLossClosePctBal)
{
   if(!basket.valid)
      return false;

   if(basket.orders < minOrdersForTimeExit)
      return false;

   if(basket.ageDays < lossAcceptDays)
      return false;

   double allowedLossMoney = PercentBalanceToMoney(allowedLossClosePctBal);
   if(allowedLossMoney <= 0.0)
      return false;

   return (basket.netProfit >= -allowedLossMoney);
}

//+------------------------------------------------------------------+
//| Sum floating pnl of managed positions                            |
//+------------------------------------------------------------------+
double GetManagedFloatingPnL(const ulong magicBase = 0,
                             const bool filterMagic = false)
{
   double total = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      ulong posMagic = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      total += PositionGetDouble(POSITION_PROFIT);
      total += PositionGetDouble(POSITION_SWAP);
   }

   return total;
}

//+------------------------------------------------------------------+
//| Portfolio net target in money                                    |
//+------------------------------------------------------------------+
bool IsPortfolioNetTargetHit(const double portfolioNetTargetPctBal,
                             const ulong magicBase = 0,
                             const bool filterMagic = false)
{
   double targetMoney = PercentBalanceToMoney(portfolioNetTargetPctBal);
   if(targetMoney <= 0.0)
      return false;

   double pnl = GetManagedFloatingPnL(magicBase, filterMagic);
   return (pnl >= targetMoney);
}

//+------------------------------------------------------------------+
//| Find worst basket among managed baskets                          |
//| Optional: stale baskets only                                     |
//+------------------------------------------------------------------+
bool FindWorstBasket(const string &brokerSymbols[],
                     BasketInfo &worstBasket,
                     const bool staleOnly,
                     const double staleDays,
                     const int minOrdersForTimeExit,
                     const ulong magicBase = 0,
                     const bool filterMagic = false)
{
   worstBasket.valid = false;
   double worstPnl = 0.0;

   for(int i = 0; i < ArraySize(brokerSymbols); i++)
   {
      string symbol = brokerSymbols[i];
      if(symbol == "")
         continue;

      BasketInfo buyBasket, sellBasket;
      bool hasBuy  = BuildBasketInfo(symbol, ORDER_TYPE_BUY,  buyBasket,  magicBase, filterMagic);
      bool hasSell = BuildBasketInfo(symbol, ORDER_TYPE_SELL, sellBasket, magicBase, filterMagic);

      if(hasBuy)
      {
         bool eligible = true;

         if(staleOnly)
            eligible = IsBasketTimeExitReady(buyBasket, staleDays, minOrdersForTimeExit);

         if(eligible && (!worstBasket.valid || buyBasket.netProfit < worstPnl))
         {
            worstBasket = buyBasket;
            worstPnl    = buyBasket.netProfit;
         }
      }

      if(hasSell)
      {
         bool eligible = true;

         if(staleOnly)
            eligible = IsBasketTimeExitReady(sellBasket, staleDays, minOrdersForTimeExit);

         if(eligible && (!worstBasket.valid || sellBasket.netProfit < worstPnl))
         {
            worstBasket = sellBasket;
            worstPnl    = sellBasket.netProfit;
         }
      }
   }

   return worstBasket.valid;
}

//+------------------------------------------------------------------+
//| Process one basket exit rules                                    |
//| Returns true if a close was attempted and succeeded              |
//+------------------------------------------------------------------+
bool ProcessBasketExit(CTrade &trade,
                       const BasketInfo &basket,
                       const double basketTargetPctBal,
                       const double basketHardStopPctBal,
                       const double timeExitStartDays,
                       const int minOrdersForTimeExit,
                       const double lossAcceptDays,
                       const double allowedLossClosePctBal,
                       string &resultReason,
                       const ulong magicBase = 0,
                       const bool filterMagic = false)
{
   resultReason = REASON_OK;

   if(!basket.valid)
   {
      resultReason = "Invalid basket";
      return false;
   }

   if(IsBasketTargetHit(basket, basketTargetPctBal))
   {
      resultReason = "Basket TP hit";
      return CloseBasket(trade, basket.symbol, basket.direction, resultReason, magicBase, filterMagic);
   }

   if(IsBasketHardStopHit(basket, basketHardStopPctBal))
   {
      resultReason = "Basket hard stop hit";
      return CloseBasket(trade, basket.symbol, basket.direction, resultReason, magicBase, filterMagic);
   }

   if(IsBasketBreakEvenCloseReady(basket, timeExitStartDays, minOrdersForTimeExit))
   {
      resultReason = "Stale BE close";
      return CloseBasket(trade, basket.symbol, basket.direction, resultReason, magicBase, filterMagic);
   }

   if(IsBasketControlledLossCloseReady(basket,
                                       lossAcceptDays,
                                       minOrdersForTimeExit,
                                       allowedLossClosePctBal))
   {
      resultReason = "Controlled loss close";
      return CloseBasket(trade, basket.symbol, basket.direction, resultReason, magicBase, filterMagic);
   }

   resultReason = "No exit condition";
   return false;
}

//+------------------------------------------------------------------+
//| Process all basket exits                                         |
//+------------------------------------------------------------------+
void ProcessAllBasketExits(CTrade &trade,
                           const string &brokerSymbols[],
                           const double basketTargetPctBal,
                           const double basketHardStopPctBal,
                           const double timeExitStartDays,
                           const int minOrdersForTimeExit,
                           const double lossAcceptDays,
                           const double allowedLossClosePctBal,
                           DebugStats &dbg,
                           const ulong magicBase = 0,
                           const bool filterMagic = false)
{
   for(int i = 0; i < ArraySize(brokerSymbols); i++)
   {
      string symbol = brokerSymbols[i];
      if(symbol == "")
         continue;

      BasketInfo buyBasket, sellBasket;
      bool hasBuy  = BuildBasketInfo(symbol, ORDER_TYPE_BUY,  buyBasket,  magicBase, filterMagic);
      bool hasSell = BuildBasketInfo(symbol, ORDER_TYPE_SELL, sellBasket, magicBase, filterMagic);

      string reason = "";

      if(hasBuy)
      {
         reason = "";
         if(ProcessBasketExit(trade,
                              buyBasket,
                              basketTargetPctBal,
                              basketHardStopPctBal,
                              timeExitStartDays,
                              minOrdersForTimeExit,
                              lossAcceptDays,
                              allowedLossClosePctBal,
                              reason,
                              magicBase,
                              filterMagic))
         {
            if(reason == "Basket TP hit")                 dbg.exitTP++;
            else if(reason == "Basket hard stop hit")    dbg.exitHardStop++;
            else if(reason == "Stale BE close")          dbg.exitStaleBE++;
            else if(reason == "Controlled loss close")   dbg.exitControlledLoss++;

            Print("CLOSE | ", buyBasket.symbol, " | BUY | reason=", ExitReasonToShortText(reason),
                  " | ord=", buyBasket.orders,
                  " | lots=", DoubleToString(buyBasket.lots, 2),
                  " | pnl=", DoubleToString(buyBasket.netProfit, 2),
                  " | ageD=", DoubleToString(buyBasket.ageDays, 2));
         }
      }

      if(hasSell)
      {
         reason = "";
         if(ProcessBasketExit(trade,
                              sellBasket,
                              basketTargetPctBal,
                              basketHardStopPctBal,
                              timeExitStartDays,
                              minOrdersForTimeExit,
                              lossAcceptDays,
                              allowedLossClosePctBal,
                              reason,
                              magicBase,
                              filterMagic))
         {
            if(reason == "Basket TP hit")                 dbg.exitTP++;
            else if(reason == "Basket hard stop hit")    dbg.exitHardStop++;
            else if(reason == "Stale BE close")          dbg.exitStaleBE++;
            else if(reason == "Controlled loss close")   dbg.exitControlledLoss++;

            Print("CLOSE | ", sellBasket.symbol, " | SELL | reason=", ExitReasonToShortText(reason),
                  " | ord=", sellBasket.orders,
                  " | lots=", DoubleToString(sellBasket.lots, 2),
                  " | pnl=", DoubleToString(sellBasket.netProfit, 2),
                  " | ageD=", DoubleToString(sellBasket.ageDays, 2));
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Portfolio net rescue                                             |
//| If net floating pnl >= target, close worst stale losing basket   |
//+------------------------------------------------------------------+
bool ProcessPortfolioNetRescue(CTrade &trade,
                               const string &brokerSymbols[],
                               const bool usePortfolioNetExit,
                               const double portfolioNetTargetPctBal,
                               const double staleDays,
                               const int minOrdersForTimeExit,
                               string &resultReason,
                               const ulong magicBase = 0,
                               const bool filterMagic = false)
{
   resultReason = REASON_OK;

   if(!usePortfolioNetExit)
   {
      resultReason = "Portfolio net exit disabled";
      return false;
   }

   if(!IsPortfolioNetTargetHit(portfolioNetTargetPctBal, magicBase, filterMagic))
   {
      resultReason = "Portfolio target not hit";
      return false;
   }

   BasketInfo worstBasket;
   if(!FindWorstBasket(brokerSymbols,
                       worstBasket,
                       true,
                       staleDays,
                       minOrdersForTimeExit,
                       magicBase,
                       filterMagic))
   {
      resultReason = "No stale basket eligible";
      return false;
   }

   if(worstBasket.netProfit >= 0.0)
   {
      resultReason = "No losing stale basket found";
      return false;
   }

   resultReason = "Portfolio net rescue";

   bool ok = CloseBasket(trade,
                         worstBasket.symbol,
                         worstBasket.direction,
                         resultReason,
                         magicBase,
                         filterMagic);

   if(ok)
   {
      Print("CLOSE | ", worstBasket.symbol, " | ",
            (worstBasket.direction == ORDER_TYPE_BUY ? "BUY" : "SELL"),
            " | reason=", ExitReasonToShortText(resultReason),
            " | ord=", worstBasket.orders,
            " | lots=", DoubleToString(worstBasket.lots, 2),
            " | pnl=", DoubleToString(worstBasket.netProfit, 2),
            " | ageD=", DoubleToString(worstBasket.ageDays, 2));
   }

   return ok;
}

//+------------------------------------------------------------------+
//| Emergency close all                                              |
//+------------------------------------------------------------------+
bool ProcessEmergencyClose(CTrade &trade,
                           const PortfolioStats &stats,
                           string &resultReason,
                           const ulong magicBase = 0,
                           const bool filterMagic = false)
{
   resultReason = REASON_OK;

   if(!IsEmergencyCloseRequired(stats))
   {
      resultReason = "No emergency close required";
      return false;
   }

   resultReason = "Emergency close all";
   return CloseAllManagedPositions(trade, resultReason, magicBase, filterMagic);
}

//+------------------------------------------------------------------+
//| Logging helper                                                   |
//+------------------------------------------------------------------+
string ExitDecisionToText(const BasketInfo &basket,
                          const double basketTargetPctBal,
                          const double basketHardStopPctBal,
                          const double timeExitStartDays,
                          const int minOrdersForTimeExit,
                          const double lossAcceptDays,
                          const double allowedLossClosePctBal)
{
   string txt = BasketInfoToText(basket);

   if(IsBasketTargetHit(basket, basketTargetPctBal))
      return txt + " | exit=TP";

   if(IsBasketHardStopHit(basket, basketHardStopPctBal))
      return txt + " | exit=HARDSTOP";

   if(IsBasketBreakEvenCloseReady(basket, timeExitStartDays, minOrdersForTimeExit))
      return txt + " | exit=STALE_BE";

   if(IsBasketControlledLossCloseReady(basket,
                                       lossAcceptDays,
                                       minOrdersForTimeExit,
                                       allowedLossClosePctBal))
      return txt + " | exit=CTRL_LOSS";

   return txt + " | exit=NONE";
}
string ExitReasonToShortText(const string reason)
{
   if(reason == "Basket TP hit")               return "TP";
   if(reason == "Basket hard stop hit")        return "HARDSTOP";
   if(reason == "Stale BE close")              return "STALE_BE";
   if(reason == "Controlled loss close")       return "CTRL_LOSS";
   if(reason == "Portfolio net rescue")        return "PORT_RESCUE";
   if(reason == "Emergency close all")         return "EMERGENCY";
   return reason;
}
#endif // __TMD_LITE_EXIT_MQH__