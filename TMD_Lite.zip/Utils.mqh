#ifndef __TMD_LITE_UTILS_MQH__
#define __TMD_LITE_UTILS_MQH__

#include <Trade/PositionInfo.mqh>
#include "Config.mqh"
#include "Structs.mqh"
#include "Symbols.mqh"

//+------------------------------------------------------------------+
//| Basic math helpers                                               |
//+------------------------------------------------------------------+
double ClampDouble(const double value, const double minValue, const double maxValue)
{
   if(value < minValue)
      return minValue;
   if(value > maxValue)
      return maxValue;
   return value;
}

//+------------------------------------------------------------------+
//| Normalize value to 0..1                                          |
//+------------------------------------------------------------------+
double Normalize01(const double value, const double minValue, const double maxValue)
{
   if(maxValue <= minValue)
      return 0.0;

   double x = (value - minValue) / (maxValue - minValue);
   return ClampDouble(x, 0.0, 1.0);
}

//+------------------------------------------------------------------+
//| Safe division                                                    |
//+------------------------------------------------------------------+
double SafeDiv(const double numerator, const double denominator, const double fallback = 0.0)
{
   if(MathAbs(denominator) < 1e-12)
      return fallback;
   return numerator / denominator;
}

//+------------------------------------------------------------------+
//| Sign helper                                                      |
//+------------------------------------------------------------------+
int SignOf(const double value)
{
   if(value > 0.0)
      return 1;
   if(value < 0.0)
      return -1;
   return 0;
}

//+------------------------------------------------------------------+
//| Round price to symbol digits                                     |
//+------------------------------------------------------------------+
double NormalizePrice(const string symbol, const double price)
{
   int digits = GetSymbolDigitsSafe(symbol);
   return NormalizeDouble(price, digits);
}

//+------------------------------------------------------------------+
//| Normalize lots to broker constraints                             |
//+------------------------------------------------------------------+
double NormalizeLots(const string symbol, double lots)
{
   double minLot  = 0.0;
   double maxLot  = 0.0;
   double lotStep = 0.0;

   if(!SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN, minLot))
      minLot = 0.01;
   if(!SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX, maxLot))
      maxLot = 100.0;
   if(!SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP, lotStep))
      lotStep = 0.01;

   if(lotStep <= 0.0)
      lotStep = 0.01;

   lots = MathMax(minLot, MathMin(maxLot, lots));
   lots = MathFloor(lots / lotStep) * lotStep;

   int volDigits = 2;
   if(lotStep == 1.0)      volDigits = 0;
   else if(lotStep == 0.1) volDigits = 1;
   else if(lotStep == 0.01) volDigits = 2;
   else if(lotStep == 0.001) volDigits = 3;

   return NormalizeDouble(lots, volDigits);
}

//+------------------------------------------------------------------+
//| New bar detection                                                |
//| Call with a static datetime variable per symbol/timeframe        |
//+------------------------------------------------------------------+
bool IsNewBar(const string symbol, const ENUM_TIMEFRAMES timeframe, datetime &lastBarTime)
{
   datetime currentBarTime = iTime(symbol, timeframe, 0);
   if(currentBarTime <= 0)
      return false;

   if(lastBarTime == 0)
   {
      lastBarTime = currentBarTime;
      return false;
   }

   if(currentBarTime != lastBarTime)
   {
      lastBarTime = currentBarTime;
      return true;
   }

   return false;
}

//+------------------------------------------------------------------+
//| Copy latest closed close price                                   |
//+------------------------------------------------------------------+
double GetClosePrice(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   double buffer[];
   ArraySetAsSeries(buffer, true);

   if(CopyClose(symbol, timeframe, shift, 1, buffer) < 1)
      return 0.0;

   return buffer[0];
}

//+------------------------------------------------------------------+
//| Copy latest closed open price                                    |
//+------------------------------------------------------------------+
double GetOpenPrice(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   double buffer[];
   ArraySetAsSeries(buffer, true);

   if(CopyOpen(symbol, timeframe, shift, 1, buffer) < 1)
      return 0.0;

   return buffer[0];
}

//+------------------------------------------------------------------+
//| Copy latest closed high price                                    |
//+------------------------------------------------------------------+
double GetHighPrice(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   double buffer[];
   ArraySetAsSeries(buffer, true);

   if(CopyHigh(symbol, timeframe, shift, 1, buffer) < 1)
      return 0.0;

   return buffer[0];
}

//+------------------------------------------------------------------+
//| Copy latest closed low price                                     |
//+------------------------------------------------------------------+
double GetLowPrice(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   double buffer[];
   ArraySetAsSeries(buffer, true);

   if(CopyLow(symbol, timeframe, shift, 1, buffer) < 1)
      return 0.0;

   return buffer[0];
}

//+------------------------------------------------------------------+
//| Safe EMA accessor                                                |
//+------------------------------------------------------------------+
double GetEMA(const string symbol,
              const ENUM_TIMEFRAMES timeframe,
              const int period,
              const int shift = 1)
{
   int handle = iMA(symbol, timeframe, period, 0, MODE_EMA, PRICE_CLOSE);
   if(handle == INVALID_HANDLE)
      return 0.0;

   double buffer[];
   ArraySetAsSeries(buffer, true);

   int copied = CopyBuffer(handle, 0, shift, 1, buffer);
   IndicatorRelease(handle);

   if(copied < 1)
      return 0.0;

   return buffer[0];
}

//+------------------------------------------------------------------+
//| Safe ATR accessor                                                |
//+------------------------------------------------------------------+
double GetATR(const string symbol,
              const ENUM_TIMEFRAMES timeframe,
              const int period,
              const int shift = 1)
{
   int handle = iATR(symbol, timeframe, period);
   if(handle == INVALID_HANDLE)
      return 0.0;

   double buffer[];
   ArraySetAsSeries(buffer, true);

   int copied = CopyBuffer(handle, 0, shift, 1, buffer);
   IndicatorRelease(handle);

   if(copied < 1)
      return 0.0;

   return buffer[0];
}

//+------------------------------------------------------------------+
//| Closed-candle candle body                                        |
//+------------------------------------------------------------------+
double GetCandleBody(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   double openPrice  = GetOpenPrice(symbol, timeframe, shift);
   double closePrice = GetClosePrice(symbol, timeframe, shift);
   return (closePrice - openPrice);
}

//+------------------------------------------------------------------+
//| Closed-candle upper wick                                         |
//+------------------------------------------------------------------+
double GetUpperWick(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   double openPrice  = GetOpenPrice(symbol, timeframe, shift);
   double closePrice = GetClosePrice(symbol, timeframe, shift);
   double highPrice  = GetHighPrice(symbol, timeframe, shift);

   double topBody = MathMax(openPrice, closePrice);
   return (highPrice - topBody);
}

//+------------------------------------------------------------------+
//| Closed-candle lower wick                                         |
//+------------------------------------------------------------------+
double GetLowerWick(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   double openPrice  = GetOpenPrice(symbol, timeframe, shift);
   double closePrice = GetClosePrice(symbol, timeframe, shift);
   double lowPrice   = GetLowPrice(symbol, timeframe, shift);

   double bottomBody = MathMin(openPrice, closePrice);
   return (bottomBody - lowPrice);
}

//+------------------------------------------------------------------+
//| Bullish candle on closed bar                                     |
//+------------------------------------------------------------------+
bool IsBullishCandle(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   return (GetClosePrice(symbol, timeframe, shift) > GetOpenPrice(symbol, timeframe, shift));
}

//+------------------------------------------------------------------+
//| Bearish candle on closed bar                                     |
//+------------------------------------------------------------------+
bool IsBearishCandle(const string symbol, const ENUM_TIMEFRAMES timeframe, const int shift = 1)
{
   return (GetClosePrice(symbol, timeframe, shift) < GetOpenPrice(symbol, timeframe, shift));
}

//+------------------------------------------------------------------+
//| Return current account drawdown % from balance                   |
//+------------------------------------------------------------------+
double GetAccountDrawdownPct()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);

   if(balance <= 0.0)
      return 0.0;

   if(equity >= balance)
      return 0.0;

   return ((balance - equity) / balance) * 100.0;
}

//+------------------------------------------------------------------+
//| Return current floating pnl                                      |
//+------------------------------------------------------------------+
double GetFloatingPnL()
{
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   return (equity - balance);
}

//+------------------------------------------------------------------+
//| Fill portfolio stats snapshot                                    |
//+------------------------------------------------------------------+
void UpdatePortfolioStats(PortfolioStats &stats)
{
   stats.balance       = AccountInfoDouble(ACCOUNT_BALANCE);
   stats.equity        = AccountInfoDouble(ACCOUNT_EQUITY);
   stats.margin        = AccountInfoDouble(ACCOUNT_MARGIN);
   stats.freeMargin    = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   stats.marginLevel   = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);

   stats.floatingPnl   = stats.equity - stats.balance;
   stats.floatingPnlPct= SafeDiv(stats.floatingPnl, stats.balance, 0.0) * 100.0;
   stats.drawdownPct   = GetAccountDrawdownPct();

   stats.totalPositions = PositionsTotal();
   stats.totalBaskets   = 0;
   stats.totalLots      = 0.0;
   stats.riskState      = RISK_OK;
}

//+------------------------------------------------------------------+
//| Days elapsed since datetime                                      |
//+------------------------------------------------------------------+
double GetAgeDays(const datetime timeValue)
{
   if(timeValue <= 0)
      return 0.0;

   return (double)(TimeCurrent() - timeValue) / 86400.0;
}

//+------------------------------------------------------------------+
//| Convert enum basket state to short label                         |
//+------------------------------------------------------------------+
string BasketStateToText(const int state)
{
   switch(state)
   {
      case BASKET_IDLE:              return STATE_READY;
      case BASKET_ACTIVE:            return "ACTIVE";
      case BASKET_BLOCKED_SPREAD:    return STATE_BLOCK_SPREAD;
      case BASKET_BLOCKED_RISK:      return STATE_BLOCK_RISK;
      case BASKET_BLOCKED_EXPOSURE:  return STATE_BLOCK_EXPOSURE;
      case BASKET_BLOCKED_SESSION:   return STATE_BLOCK_SESSION;
      case BASKET_BLOCKED_STRENGTH:  return STATE_BLOCK_STRENGTH;
      case BASKET_BLOCKED_TREND:     return STATE_BLOCK_TREND;
      case BASKET_BLOCKED_PULLBACK:  return STATE_BLOCK_PULLBACK;
      case BASKET_BLOCKED_TRIGGER:   return STATE_BLOCK_TRIGGER;
      case BASKET_STALE:             return STATE_STALE;
   }

   return "UNKNOWN";
}

//+------------------------------------------------------------------+
//| Convert risk state to text                                       |
//+------------------------------------------------------------------+
string RiskStateToText(const int state)
{
   switch(state)
   {
      case RISK_OK:        return "OK";
      case RISK_FREEZE:    return "FREEZE";
      case RISK_EMERGENCY: return "EMERGENCY";
   }

   return "UNKNOWN";
}

//+------------------------------------------------------------------+
//| Build deterministic basket magic number                          |
//| direction should be ORDER_TYPE_BUY or ORDER_TYPE_SELL            |
//+------------------------------------------------------------------+
ulong BuildBasketMagic(const ulong magicBase, const string symbol, const int direction)
{
   int idx = GetUniverseSymbolIndex(symbol);
   if(idx < 0)
      idx = 999;

   ulong dirOffset = (direction == ORDER_TYPE_SELL) ? MAGIC_SELL_OFFSET : MAGIC_BUY_OFFSET;
   return (ulong)(magicBase + dirOffset + idx);
}

//+------------------------------------------------------------------+
//| Check whether position belongs to this EA base magic range       |
//+------------------------------------------------------------------+
bool IsOurMagic(const ulong positionMagic, const ulong magicBase)
{
   if(positionMagic >= magicBase + MAGIC_BUY_OFFSET &&
      positionMagic <  magicBase + MAGIC_BUY_OFFSET + 1000)
      return true;

   if(positionMagic >= magicBase + MAGIC_SELL_OFFSET &&
      positionMagic <  magicBase + MAGIC_SELL_OFFSET + 1000)
      return true;

   return false;
}

//+------------------------------------------------------------------+
//| Sum lots of all open positions                                   |
//+------------------------------------------------------------------+
double GetTotalOpenLots()
{
   double totalLots = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      totalLots += PositionGetDouble(POSITION_VOLUME);
   }

   return totalLots;
}

//+------------------------------------------------------------------+
//| Count positions by symbol and direction                          |
//+------------------------------------------------------------------+
int CountPositionsBySymbolDirection(const string symbol, const int direction, const ulong magicBase = 0, const bool filterMagic = false)
{
   int count = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(posSymbol != symbol)
         continue;
      if(posType != direction)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      count++;
   }

   return count;
}

//+------------------------------------------------------------------+
//| Sum lots by symbol and direction                                 |
//+------------------------------------------------------------------+
double SumLotsBySymbolDirection(const string symbol, const int direction, const ulong magicBase = 0, const bool filterMagic = false)
{
   double lots = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(posSymbol != symbol)
         continue;
      if(posType != direction)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      lots += PositionGetDouble(POSITION_VOLUME);
   }

   return lots;
}

//+------------------------------------------------------------------+
//| Sum profit by symbol and direction                               |
//+------------------------------------------------------------------+
double SumProfitBySymbolDirection(const string symbol, const int direction, const ulong magicBase = 0, const bool filterMagic = false)
{
   double profit = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(posSymbol != symbol)
         continue;
      if(posType != direction)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      profit += PositionGetDouble(POSITION_PROFIT);
      profit += PositionGetDouble(POSITION_SWAP);
   }

   return profit;
}

//+------------------------------------------------------------------+
//| Oldest open time by symbol and direction                         |
//+------------------------------------------------------------------+
datetime GetOldestPositionTime(const string symbol, const int direction, const ulong magicBase = 0, const bool filterMagic = false)
{
   datetime oldest = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);
      datetime openTime= (datetime)PositionGetInteger(POSITION_TIME);

      if(posSymbol != symbol)
         continue;
      if(posType != direction)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      if(oldest == 0 || openTime < oldest)
         oldest = openTime;
   }

   return oldest;
}

//+------------------------------------------------------------------+
//| Newest open time by symbol and direction                         |
//+------------------------------------------------------------------+
datetime GetNewestPositionTime(const string symbol, const int direction, const ulong magicBase = 0, const bool filterMagic = false)
{
   datetime newest = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);
      datetime openTime= (datetime)PositionGetInteger(POSITION_TIME);

      if(posSymbol != symbol)
         continue;
      if(posType != direction)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      if(openTime > newest)
         newest = openTime;
   }

   return newest;
}

//+------------------------------------------------------------------+
//| Average open price by symbol and direction                       |
//+------------------------------------------------------------------+
double GetAverageOpenPrice(const string symbol, const int direction, const ulong magicBase = 0, const bool filterMagic = false)
{
   double weightedPrice = 0.0;
   double totalLots     = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(posSymbol != symbol)
         continue;
      if(posType != direction)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      double lots  = PositionGetDouble(POSITION_VOLUME);
      double price = PositionGetDouble(POSITION_PRICE_OPEN);

      weightedPrice += price * lots;
      totalLots     += lots;
   }

   return SafeDiv(weightedPrice, totalLots, 0.0);
}

//+------------------------------------------------------------------+
//| Fill basket aggregate info                                       |
//+------------------------------------------------------------------+
bool BuildBasketInfo(const string symbol, const int direction, BasketInfo &basket, const ulong magicBase = 0, const bool filterMagic = false)
{
   basket.symbol         = symbol;
   basket.direction      = direction;
   basket.magic          = BuildBasketMagic(magicBase, symbol, direction);
   basket.orders         = CountPositionsBySymbolDirection(symbol, direction, magicBase, filterMagic);
   basket.lots           = SumLotsBySymbolDirection(symbol, direction, magicBase, filterMagic);
   basket.netProfit      = 0.0;
   basket.grossProfit    = 0.0;
   basket.swap           = 0.0;
   basket.commission     = 0.0;
   basket.avgPrice       = GetAverageOpenPrice(symbol, direction, magicBase, filterMagic);
   basket.oldestOpenTime = GetOldestPositionTime(symbol, direction, magicBase, filterMagic);
   basket.newestOpenTime = GetNewestPositionTime(symbol, direction, magicBase, filterMagic);
   basket.lastEntryPrice = 0.0;
   basket.ageDays        = GetAgeDays(basket.oldestOpenTime);
   basket.valid          = (basket.orders > 0);

   if(!basket.valid)
      return false;

   datetime newestTime = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(!PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      int    posType   = (int)PositionGetInteger(POSITION_TYPE);
      ulong  posMagic  = (ulong)PositionGetInteger(POSITION_MAGIC);

      if(posSymbol != symbol)
         continue;
      if(posType != direction)
         continue;

      if(filterMagic && !IsOurMagic(posMagic, magicBase))
         continue;

      basket.grossProfit += PositionGetDouble(POSITION_PROFIT);
      basket.swap        += PositionGetDouble(POSITION_SWAP);

      datetime openTime = (datetime)PositionGetInteger(POSITION_TIME);
      if(openTime >= newestTime)
      {
         newestTime = openTime;
         basket.lastEntryPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      }
   }

   basket.netProfit = basket.grossProfit + basket.swap;
   return true;
}

//+------------------------------------------------------------------+
//| Calculate auto lot from balance                                  |
//| balancePer001Lot = account balance needed for 0.01 lot           |
//+------------------------------------------------------------------+
double CalculateAutoLot(const string symbol, const double balancePer001Lot)
{
   if(balancePer001Lot <= 0.0)
      return NormalizeLots(symbol, InpFixedLot);

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double lots    = (balance / balancePer001Lot) * 0.01;

   return NormalizeLots(symbol, lots);
}

//+------------------------------------------------------------------+
//| Return money value of pct balance                                |
//+------------------------------------------------------------------+
double PercentBalanceToMoney(const double pct)
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   return balance * pct / 100.0;
}

//+------------------------------------------------------------------+
//| Check if month is blocked                                        |
//+------------------------------------------------------------------+
bool IsBlockedMonth(const int month, const bool blockJuly)
{
   if(blockJuly && month == 7)
      return true;

   return false;
}

//+------------------------------------------------------------------+
//| Check if date is in year-end blocked window                      |
//| From Dec 20 until Jan 10 inclusive                               |
//+------------------------------------------------------------------+
bool IsInYearEndBlock(const MqlDateTime &tm, const bool blockYearEnd)
{
   if(!blockYearEnd)
      return false;

   if(tm.mon == 12 && tm.day >= 20)
      return true;

   if(tm.mon == 1 && tm.day <= 10)
      return true;

   return false;
}

//+------------------------------------------------------------------+
//| Check if current broker time is inside late-Friday block         |
//| Friday from 19:00 broker time onwards                            |
//+------------------------------------------------------------------+
bool IsLateFridayBlocked(const MqlDateTime &tm, const bool blockLateFriday)
{
   if(!blockLateFriday)
      return false;

   if(tm.day_of_week == 5 && tm.hour >= 19)
      return true;

   return false;
}

//+------------------------------------------------------------------+
//| Check if current broker time is inside early-Monday block        |
//| Monday before 05:00 broker time                                  |
//+------------------------------------------------------------------+
bool IsEarlyMondayBlocked(const MqlDateTime &tm, const bool blockEarlyMonday)
{
   if(!blockEarlyMonday)
      return false;

   if(tm.day_of_week == 1 && tm.hour < 5)
      return true;

   return false;
}

//+------------------------------------------------------------------+
//| Combined calendar/session block                                  |
//+------------------------------------------------------------------+
bool IsTradingBlockedByCalendar(const bool blockLateFriday,
                                const bool blockEarlyMonday,
                                const bool blockJuly,
                                const bool blockYearEnd)
{
   MqlDateTime tm;
   TimeToStruct(TimeCurrent(), tm);

   if(IsBlockedMonth(tm.mon, blockJuly))
      return true;

   if(IsInYearEndBlock(tm, blockYearEnd))
      return true;

   if(IsLateFridayBlocked(tm, blockLateFriday))
      return true;

   if(IsEarlyMondayBlocked(tm, blockEarlyMonday))
      return true;

   return false;
}

void ResetDebugStats(DebugStats &d)
{
   d.scannedPairs        = 0;

   d.blockedTrend        = 0;
   d.blockedStrength     = 0;
   d.blockedPullback     = 0;
   d.blockedTrigger      = 0;
   d.blockedSpread       = 0;
   d.blockedExposure     = 0;
   d.blockedSession      = 0;
   d.blockedRisk         = 0;

   d.readyBuy            = 0;
   d.readySell           = 0;

   d.openedBaskets       = 0;
   d.expandedBaskets     = 0;

   d.exitTP              = 0;
   d.exitHardStop        = 0;
   d.exitStaleBE         = 0;
   d.exitControlledLoss  = 0;
   d.exitPortfolioRescue = 0;
   d.exitEmergency       = 0;
}

#endif // __TMD_LITE_UTILS_MQH__