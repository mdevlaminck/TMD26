#ifndef __TMD_LITE_GRIDMANAGER_MQH__
#define __TMD_LITE_GRIDMANAGER_MQH__

#include <Trade/Trade.mqh>

#include "Structs.mqh"
#include "Config.mqh"
#include "Symbols.mqh"
#include "Utils.mqh"
#include "Risk.mqh"

//+------------------------------------------------------------------+
//| Basket runtime helpers                                           |
//+------------------------------------------------------------------+
bool HasOpenBasket(const string symbol,
                   const int orderType,
                   const ulong magicBase = 0,
                   const bool filterMagic = false)
{
   return (CountPositionsBySymbolDirection(symbol, orderType, magicBase, filterMagic) > 0);
}

//+------------------------------------------------------------------+
//| Refresh pair basket fields                                       |
//+------------------------------------------------------------------+
void UpdatePairBasketState(PairData &pair,
                           const ulong magicBase = 0,
                           const bool filterMagic = false)
{
   BasketInfo buyBasket, sellBasket;

   bool hasBuy  = BuildBasketInfo(pair.symbol, ORDER_TYPE_BUY,  buyBasket,  magicBase, filterMagic);
   bool hasSell = BuildBasketInfo(pair.symbol, ORDER_TYPE_SELL, sellBasket, magicBase, filterMagic);

   pair.hasBuyBasket = hasBuy;
   pair.hasSellBasket = hasSell;

   pair.buyOrders   = hasBuy  ? buyBasket.orders    : 0;
   pair.sellOrders  = hasSell ? sellBasket.orders   : 0;

   pair.buyLots     = hasBuy  ? buyBasket.lots      : 0.0;
   pair.sellLots    = hasSell ? sellBasket.lots     : 0.0;

   pair.buyProfit   = hasBuy  ? buyBasket.netProfit : 0.0;
   pair.sellProfit  = hasSell ? sellBasket.netProfit: 0.0;

   pair.buyAgeDays  = hasBuy  ? buyBasket.ageDays   : 0.0;
   pair.sellAgeDays = hasSell ? sellBasket.ageDays  : 0.0;
}

//+------------------------------------------------------------------+
//| Initial lot size                                                 |
//+------------------------------------------------------------------+
double GetInitialLotSize(const string symbol,
                         const bool useAutoLot,
                         const double balancePer001Lot,
                         const double fixedLot)
{
   double lots = useAutoLot ? CalculateAutoLot(symbol, balancePer001Lot)
                            : NormalizeLots(symbol, fixedLot);

   return NormalizeLots(symbol, lots);
}

//+------------------------------------------------------------------+
//| Next add-on lot size                                             |
//| existingOrders = number of already open positions in basket      |
//| If no multiplier: same as initial lot                            |
//| If multiplier: initial * multiplier^(existingOrders)             |
//+------------------------------------------------------------------+
double GetNextGridLotSize(const string symbol,
                          const int existingOrders,
                          const bool useLotMultiplier,
                          const double lotMultiplier,
                          const bool useAutoLot,
                          const double balancePer001Lot,
                          const double fixedLot)
{
   double baseLot = GetInitialLotSize(symbol,
                                      useAutoLot,
                                      balancePer001Lot,
                                      fixedLot);

   if(!useLotMultiplier)
      return baseLot;

   if(lotMultiplier <= 1.0)
      return baseLot;

   double lots = baseLot * MathPow(lotMultiplier, existingOrders);
   return NormalizeLots(symbol, lots);
}

//+------------------------------------------------------------------+
//| ATR-based grid step in price units                               |
//+------------------------------------------------------------------+
double GetGridStepPrice(const string symbol,
                        const ENUM_TIMEFRAMES setupTF,
                        const int atrPeriod,
                        const double gridStepAtr)
{
   double atr = GetATR(symbol, setupTF, atrPeriod, 1);
   if(atr <= 0.0)
      return 0.0;

   return atr * gridStepAtr;
}

//+------------------------------------------------------------------+
//| Distance from average basket price in price units               |
//| Positive value = adverse move against basket                     |
//+------------------------------------------------------------------+
double GetAdverseDistanceFromAverage(const string symbol,
                                     const int orderType,
                                     const double avgPrice)
{
   double bid = 0.0;
   double ask = 0.0;

   if(!SymbolInfoDouble(symbol, SYMBOL_BID, bid))
      return 0.0;
   if(!SymbolInfoDouble(symbol, SYMBOL_ASK, ask))
      return 0.0;

   if(orderType == ORDER_TYPE_BUY)
      return (avgPrice - bid);

   if(orderType == ORDER_TYPE_SELL)
      return (ask - avgPrice);

   return 0.0;
}

//+------------------------------------------------------------------+
//| Distance from last entry in price units                         |
//| Positive value = adverse move against last entry                 |
//+------------------------------------------------------------------+
double GetAdverseDistanceFromLastEntry(const string symbol,
                                       const int orderType,
                                       const double lastEntryPrice)
{
   double bid = 0.0;
   double ask = 0.0;

   if(!SymbolInfoDouble(symbol, SYMBOL_BID, bid))
      return 0.0;
   if(!SymbolInfoDouble(symbol, SYMBOL_ASK, ask))
      return 0.0;

   if(orderType == ORDER_TYPE_BUY)
      return (lastEntryPrice - bid);

   if(orderType == ORDER_TYPE_SELL)
      return (ask - lastEntryPrice);

   return 0.0;
}

//+------------------------------------------------------------------+
//| Cooldown check for add-ons                                       |
//+------------------------------------------------------------------+
bool IsAddCooldownPassed(const BasketInfo &basket,
                         const int minSecondsBetweenAdds)
{
   if(!basket.valid)
      return false;

   if(basket.newestOpenTime <= 0)
      return false;

   return ((TimeCurrent() - basket.newestOpenTime) >= minSecondsBetweenAdds);
}

//+------------------------------------------------------------------+
//| Can this basket add another order?                               |
//+------------------------------------------------------------------+
bool CanExpandBasket(const BasketInfo &basket,
                     const int maxOrdersPerBasket)
{
   if(!basket.valid)
      return false;

   if(basket.orders <= 0)
      return false;

   if(basket.orders >= maxOrdersPerBasket)
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| Expansion trigger                                                |
//| Requires:                                                        |
//| - active basket                                                  |
//| - losing basket                                                  |
//| - ATR step reached from avg OR last entry                        |
//| - cooldown passed                                                |
//+------------------------------------------------------------------+
bool IsGridExpansionSignal(const BasketInfo &basket,
                           const ENUM_TIMEFRAMES setupTF,
                           const int atrPeriod,
                           const double gridStepAtr,
                           const int minSecondsBetweenAdds,
                           const bool useAveragePriceStep = true)
{
   if(!basket.valid)
      return false;

   if(basket.netProfit >= 0.0)
      return false;

   if(!IsAddCooldownPassed(basket, minSecondsBetweenAdds))
      return false;

   double stepPrice = GetGridStepPrice(basket.symbol, setupTF, atrPeriod, gridStepAtr);
   if(stepPrice <= 0.0)
      return false;

   double adverseDistance = useAveragePriceStep
      ? GetAdverseDistanceFromAverage(basket.symbol, basket.direction, basket.avgPrice)
      : GetAdverseDistanceFromLastEntry(basket.symbol, basket.direction, basket.lastEntryPrice);

   if(adverseDistance <= 0.0)
      return false;

   return (adverseDistance >= stepPrice);
}

//+------------------------------------------------------------------+
//| Basket hard stop in money                                        |
//| pct is a real percent, e.g. 0.60 = 0.60% of balance              |
//+------------------------------------------------------------------+
bool IsBasketHardStopHit(const BasketInfo &basket,
                         const double basketHardStopPctBal)
{
   if(!basket.valid)
      return false;

   double hardStopMoney = PercentBalanceToMoney(basketHardStopPctBal);
   if(hardStopMoney <= 0.0)
      return false;

   return (basket.netProfit <= -hardStopMoney);
}

//+------------------------------------------------------------------+
//| Open one market order                                            |
//+------------------------------------------------------------------+
bool OpenBasketOrder(CTrade &trade,
                     const string symbol,
                     const int orderType,
                     const double lotSize,
                     const ulong magic,
                     const string commentText = "")
{
   trade.SetExpertMagicNumber(magic);

   bool result = false;

   if(orderType == ORDER_TYPE_BUY)
      result = trade.Buy(lotSize, symbol, 0.0, 0.0, 0.0, commentText);
   else if(orderType == ORDER_TYPE_SELL)
      result = trade.Sell(lotSize, symbol, 0.0, 0.0, 0.0, commentText);

   return result;
}

//+------------------------------------------------------------------+
//| Start a new basket from entry candidate                          |
//+------------------------------------------------------------------+
bool TryOpenInitialBasket(CTrade &trade,
                          const EntryCandidate &candidate,
                          const bool useAutoLot,
                          const double balancePer001Lot,
                          const double fixedLot,
                          const string &brokerSymbols[],
                          const PortfolioStats &stats,
                          const int maxTotalPositions,
                          const double maxTotalLots,
                          const int maxBaskets,
                          const bool blockLateFriday,
                          const bool blockEarlyMonday,
                          const bool blockJuly,
                          const bool blockYearEnd,
                          const ulong magicBase,
                          string &resultReason,
                          const bool filterMagic = false)
{
   resultReason = REASON_OK;

   if(!candidate.valid)
   {
      resultReason = candidate.rejectReason;
      return false;
   }

   int orderType = (candidate.direction == TREND_SELL) ? ORDER_TYPE_SELL : ORDER_TYPE_BUY;

   if(HasOpenBasket(candidate.symbol, orderType, magicBase, filterMagic))
   {
      resultReason = "Basket already open";
      return false;
   }

   double lotSize = GetInitialLotSize(candidate.symbol,
                                      useAutoLot,
                                      balancePer001Lot,
                                      fixedLot);

   if(lotSize <= 0.0)
   {
      resultReason = "Invalid lot size";
      return false;
   }

   if(!IsCandidateAllowedByRisk(candidate,
                                brokerSymbols,
                                stats,
                                maxTotalPositions,
                                maxTotalLots,
                                maxBaskets,
                                lotSize,
                                blockLateFriday,
                                blockEarlyMonday,
                                blockJuly,
                                blockYearEnd,
                                resultReason,
                                magicBase,
                                filterMagic))
   {
      return false;
   }

   ulong magic = BuildBasketMagic(magicBase, candidate.symbol, orderType);
   string commentText = "TMDLite start";

   if(!OpenBasketOrder(trade,
                       candidate.symbol,
                       orderType,
                       lotSize,
                       magic,
                       commentText))
   {
      resultReason = "Order send failed";
      return false;
   }

   resultReason = REASON_OK;
   return true;
}

//+------------------------------------------------------------------+
//| Try to expand an existing basket                                 |
//+------------------------------------------------------------------+
bool TryExpandBasket(CTrade &trade,
                     const BasketInfo &basket,
                     const PortfolioStats &stats,
                     const ENUM_TIMEFRAMES setupTF,
                     const int atrPeriod,
                     const double gridStepAtr,
                     const int minSecondsBetweenAdds,
                     const int maxOrdersPerBasket,
                     const bool useLotMultiplier,
                     const double lotMultiplier,
                     const bool useAutoLot,
                     const double balancePer001Lot,
                     const double fixedLot,
                     const double maxTotalLots,
                     const double basketHardStopPctBal,
                     const bool blockLateFriday,
                     const bool blockEarlyMonday,
                     const bool blockJuly,
                     const bool blockYearEnd,
                     const ulong magicBase,
                     string &resultReason)
{
   resultReason = REASON_OK;

   if(!basket.valid)
   {
      resultReason = "Basket invalid";
      return false;
   }
   
   if(IsBasketHardStopHit(basket, basketHardStopPctBal))
   {
      resultReason = "Basket hard stop hit";
      return false;
   }

   if(!CanExpandBasket(basket, maxOrdersPerBasket))
   {
      resultReason = "Max basket orders reached";
      return false;
   }

   if(!IsGridExpansionSignal(basket,
                             setupTF,
                             atrPeriod,
                             gridStepAtr,
                             minSecondsBetweenAdds,
                             true))
   {
      resultReason = "No expansion signal";
      return false;
   }

   double nextLot = GetNextGridLotSize(basket.symbol,
                                       basket.orders,
                                       useLotMultiplier,
                                       lotMultiplier,
                                       useAutoLot,
                                       balancePer001Lot,
                                       fixedLot);

   if(nextLot <= 0.0)
   {
      resultReason = "Invalid next lot size";
      return false;
   }

   if(!IsBasketExpansionAllowed(basket.symbol,
                                basket.direction,
                                nextLot,
                                stats,
                                maxTotalLots,
                                blockLateFriday,
                                blockEarlyMonday,
                                blockJuly,
                                blockYearEnd,
                                resultReason))
   {
      return false;
   }

   string commentText = "TMDLite add";
   
   ulong magic = BuildBasketMagic(magicBase, basket.symbol, basket.direction);

   if(!OpenBasketOrder(trade,
                       basket.symbol,
                       basket.direction,
                       nextLot,
                       magic,
                       commentText))
   {
      resultReason = "Expansion order failed";
      return false;
   }

   resultReason = REASON_OK;
   return true;
}

//+------------------------------------------------------------------+
//| Helper: basket direction text                                    |
//+------------------------------------------------------------------+
string BasketDirectionToText(const int orderType)
{
   if(orderType == ORDER_TYPE_BUY)
      return "BUY";
   if(orderType == ORDER_TYPE_SELL)
      return "SELL";

   return "NONE";
}

//+------------------------------------------------------------------+
//| Logging helper                                                   |
//+------------------------------------------------------------------+
string BasketInfoToText(const BasketInfo &basket)
{
   string txt = basket.symbol + " ";
   txt += BasketDirectionToText(basket.direction);
   txt += " | orders=" + IntegerToString(basket.orders);
   txt += " | lots=" + DoubleToString(basket.lots, 2);
   txt += " | pnl=" + DoubleToString(basket.netProfit, 2);
   txt += " | avg=" + DoubleToString(basket.avgPrice, GetSymbolDigitsSafe(basket.symbol));
   txt += " | ageD=" + DoubleToString(basket.ageDays, 2);
   return txt;
}

//+------------------------------------------------------------------+
//| Refresh all pair basket fields                                   |
//+------------------------------------------------------------------+
void UpdateAllPairBasketStates(PairData &pairs[],
                               const ulong magicBase = 0,
                               const bool filterMagic = false)
{
   int count = ArraySize(pairs);
   for(int i = 0; i < count; i++)
      UpdatePairBasketState(pairs[i], magicBase, filterMagic);
}

#endif // __TMD_LITE_GRIDMANAGER_MQH__