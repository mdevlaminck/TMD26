//+------------------------------------------------------------------+
//|                                                     EdgeScore.mqh|
//|                                                              MDV |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"

input group "=== Edge Score Engine ===";
input ENUM_ONOFF InpUseEdgeScoreEngine        = OFF;
input double     InpMinEdgeScore              = 6.0;
input double     InpEdgeWeightComp            = 2.0;
input double     InpEdgeWeightMomentum        = 2.0;
input double     InpEdgeWeightPullback        = 2.0;
input double     InpEdgeWeightTrend           = 1.6;
input double     InpEdgeWeightRegime          = 1.2;
input double     InpEdgeWeightTrigger         = 1.2;
input double     InpEdgeBestStretchM15        = 0.45;
input double     InpEdgeWorstStretchM15       = 1.20;
input double     InpEdgeBestStretchH1         = 0.35;
input double     InpEdgeWorstStretchH1        = 1.00;
input bool       InpUseEdgeScoreForTopPairs   = true;
input bool       InpUseEdgeScoreForLotSizing  = true;
input bool       InpUseRankOnlySelection      = false;
input bool       InpUseSoftCandidateFloors    = true;
input double     InpSoftMinCompForRanking     = 5.5;
input double     InpSoftMinEdgeForRanking     = 6.1;
input int        InpMaxRankedCandidates       = 28;

double ScoreStretchQuality(const double stretchAbs, const double best, const double worst)
{
   if(stretchAbs <= 0.0)
      return 5.5;

   if(stretchAbs <= best)
   {
      double t = SafeDiv(stretchAbs, best, 0.0);
      return 7.0 + (1.0 - t) * 2.0;   // up to ~9 when nicely reset
   }

   if(stretchAbs >= worst)
      return 1.5;

   double t = SafeDiv(stretchAbs - best, worst - best, 1.0);
   return 7.0 - t * 5.5;
}

double GetEdgeMomentumScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   double score = 0.0;

   score += Pairs[idx].slope * 0.55;
   score += Pairs[idx].accel * 0.45;

   if(Pairs[idx].aligned)
      score += 0.5;

   return Clamp(score, 0.0, 10.0);
}

double GetEdgePullbackScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   double m15Abs = MathAbs(Pairs[idx].entryStretchM15);
   double h1Abs  = MathAbs(Pairs[idx].entryStretchH1);

   double m15Score = ScoreStretchQuality(m15Abs, InpEdgeBestStretchM15, InpEdgeWorstStretchM15);
   double h1Score  = ScoreStretchQuality(h1Abs,  InpEdgeBestStretchH1,  InpEdgeWorstStretchH1);

   double score = m15Score * 0.65 + h1Score * 0.35;

   if(!Pairs[idx].locationOk)
      score = MathMin(score, 3.0);

   return Clamp(score, 0.0, 10.0);
}

double GetEdgeTrendScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   double score = 5.0;

   if(Pairs[idx].direction == ORDER_TYPE_BUY)
   {
      if(Pairs[idx].trendH4 == UPTREND) score += 2.0;
      if(Pairs[idx].trendH1 == UPTREND) score += 1.5;
      if(Pairs[idx].trendH4 == DOWNTREND) score -= 2.0;
      if(Pairs[idx].trendH1 == DOWNTREND) score -= 1.0;
   }
   else if(Pairs[idx].direction == ORDER_TYPE_SELL)
   {
      if(Pairs[idx].trendH4 == DOWNTREND) score += 2.0;
      if(Pairs[idx].trendH1 == DOWNTREND) score += 1.5;
      if(Pairs[idx].trendH4 == UPTREND) score -= 2.0;
      if(Pairs[idx].trendH1 == UPTREND) score -= 1.0;
   }

   return Clamp(score, 0.0, 10.0);
}

double GetEdgeRegimeScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   switch(Pairs[idx].regime)
   {
      case REGIME_TREND:     return 8.2;
      case REGIME_RANGE:     return 6.2;
      case REGIME_RISK_OFF:  return 4.2;
      case REGIME_EXPANSION: return 2.0;
   }

   return 5.0;
}

double GetEdgeTriggerScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   double score = 0.0;

   if(Pairs[idx].direction == ORDER_TYPE_BUY)
   {
      if(Pairs[idx].rsiBuyOk) score += 3.5;
      if(!InpUseBB || Pairs[idx].bbBuyOk) score += 3.0;
      if(IsBullishConfirmCandle(Pairs[idx].symbol)) score += 3.0;
   }
   else if(Pairs[idx].direction == ORDER_TYPE_SELL)
   {
      if(Pairs[idx].rsiSellOk) score += 3.5;
      if(!InpUseBB || Pairs[idx].bbSellOk) score += 3.0;
      if(IsBearishConfirmCandle(Pairs[idx].symbol)) score += 3.0;
   }

   return Clamp(score, 0.0, 10.0);
}

double ComputeFinalEdgeScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   double raw =
      Pairs[idx].comp         * InpEdgeWeightComp +
      Pairs[idx].edgeMomentum * InpEdgeWeightMomentum +
      Pairs[idx].edgePullback * InpEdgeWeightPullback +
      Pairs[idx].edgeTrend    * InpEdgeWeightTrend +
      Pairs[idx].edgeRegime   * InpEdgeWeightRegime +
      Pairs[idx].edgeTrigger  * InpEdgeWeightTrigger;

   double denom =
      InpEdgeWeightComp +
      InpEdgeWeightMomentum +
      InpEdgeWeightPullback +
      InpEdgeWeightTrend +
      InpEdgeWeightRegime +
      InpEdgeWeightTrigger;

   if(denom <= 0.0)
      return 0.0;

   return Clamp(raw / denom, 0.0, 10.0);
}

void UpdateEdgeScores()
{
   for(int i = 0; i < PairSize; i++)
   {
      Pairs[i].edgeMomentum = GetEdgeMomentumScore(i);
      Pairs[i].edgePullback = GetEdgePullbackScore(i);
      Pairs[i].edgeTrend    = GetEdgeTrendScore(i);
      Pairs[i].edgeRegime   = GetEdgeRegimeScore(i);
      Pairs[i].edgeTrigger  = GetEdgeTriggerScore(i);
      Pairs[i].edgeScore    = ComputeFinalEdgeScore(i);
   }
}

double GetPairSelectionScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return -999.0;

   if(InpUseEdgeScoreEngine && InpUseEdgeScoreForTopPairs)
      return Pairs[idx].edgeScore;

   return Pairs[idx].comp;
}

double GetLotSizingSignal(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   if(InpUseEdgeScoreEngine && InpUseEdgeScoreForLotSizing)
      return Pairs[idx].edgeScore;

   return Pairs[idx].comp;
}

bool IsPairHardBlockedForRanking(const int idx, string &reason)
{
   reason = "";

   if(idx < 0 || idx >= PairSize)
   {
      reason = "IDX";
      return true;
   }

   if(Pairs[idx].direction == -1)
   {
      reason = "DIR";
      return true;
   }

   if(!Pairs[idx].aligned)
   {
      reason = "ALIGN";
      return true;
   }

   if(InpUseMarketRegimeEngine)
   {
      bool buyDir = (Pairs[idx].direction == ORDER_TYPE_BUY);
      string regimeReason = "";
      if(IsRegimeBlockingEntry(idx, buyDir, regimeReason))
      {
         reason = regimeReason;
         return true;
      }
   }

   if(InpUsePersistentInvalidationExit)
   {
      if(Pairs[idx].direction == ORDER_TYPE_BUY && Pairs[idx].buyExpansionFrozenByInvalidation)
      {
         reason = "PI BUY";
         return true;
      }

      if(Pairs[idx].direction == ORDER_TYPE_SELL && Pairs[idx].sellExpansionFrozenByInvalidation)
      {
         reason = "PI SELL";
         return true;
      }
   }

   if( Pairs[idx].adaptiveState >= AGS_BLOCK)
   {
      reason = "AGS";
      return true;
   }

   return false;
}

bool PassesSoftRankingFloor(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(!InpUseSoftCandidateFloors)
      return true;

   if(Pairs[idx].comp < InpSoftMinCompForRanking)
      return false;

   if(InpUseEdgeScoreEngine && Pairs[idx].edgeScore < InpSoftMinEdgeForRanking)
      return false;

   return true;
}