//+------------------------------------------------------------------+
//|                                      SoftBasketSurvivability.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
// Responsibility:
// - Detect soft basket damage
// - Apply soft expansion throttling
// - Reduce basket TP for escape logic
// This module owns SOFT damage state, not hard blocking.
#property copyright "MDV"
#property link      "https://www.mql5.com"

input group "=== Soft Basket Survivability ===";
input ENUM_ONOFF InpUseSoftAdverseRegime          = ON;
input int        InpAdverseBarsForThrottle        = 5;      
input bool       InpThrottleOnOppositeH4          = true;
input bool       InpThrottleOnCurrencyFlip        = true;
input bool       InpThrottleOnStrongMomentum      = false;
input double     InpThrottleMomentumSlopeMin      = 5.8;
input double     InpThrottleMomentumAccelMin      = 5.5;
input ENUM_ONOFF InpUseReducedTpEscape            = ON;
input int        InpReducedTpAfterAdverseBars     = 7;
input double     InpReducedTpFactor               = 0.75;   // % of normal TP once damaged
input double     InpReducedTpMinMoney             = 0.50;   // never reduce below this money target
input group "=== Currency Exposure Caps Soft ===";
input ENUM_ONOFF InpUseCurrencyExposureCaps       = ON;
input int        InpMaxLivePairsPerCurrency       = 4;
input double     InpMaxLotsPerCurrency            = 1.20;

bool IsBuyBasketOpposedByH4Soft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   return (Pairs[idx].trendH4 == DOWNTREND);
}

bool IsSellBasketOpposedByH4Soft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   return (Pairs[idx].trendH4 == UPTREND);
}

bool IsBuyBasketCurrencyFlippedSoft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   return (Pairs[idx].baseStrength <= Pairs[idx].quoteStrength);
}

bool IsSellBasketCurrencyFlippedSoft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   return (Pairs[idx].quoteStrength <= Pairs[idx].baseStrength);
}

bool IsBuyBasketUnderAdverseMomentumSoft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].direction != ORDER_TYPE_SELL)
      return false;

   if(Pairs[idx].slope < InpThrottleMomentumSlopeMin)
      return false;

   if(Pairs[idx].accel < InpThrottleMomentumAccelMin)
      return false;

   return true;
}

bool IsSellBasketUnderAdverseMomentumSoft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].direction != ORDER_TYPE_BUY)
      return false;

   if(Pairs[idx].slope < InpThrottleMomentumSlopeMin)
      return false;

   if(Pairs[idx].accel < InpThrottleMomentumAccelMin)
      return false;

   return true;
}

int GetBuyBasketAdverseScoreSoft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   int score = 0;

   if(Pairs[idx].direction == ORDER_TYPE_SELL)
      score += 2;

   if(InpThrottleOnOppositeH4 && IsBuyBasketOpposedByH4Soft(idx))
      score += 1;

   if(InpThrottleOnCurrencyFlip && IsBuyBasketCurrencyFlippedSoft(idx))
      score += 1;

   if(InpThrottleOnStrongMomentum && IsBuyBasketUnderAdverseMomentumSoft(idx))
      score += 1;

   return score;
}

int GetSellBasketAdverseScoreSoft(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   int score = 0;

   if(Pairs[idx].direction == ORDER_TYPE_BUY)
      score += 2;

   if(InpThrottleOnOppositeH4 && IsSellBasketOpposedByH4Soft(idx))
      score += 1;

   if(InpThrottleOnCurrencyFlip && IsSellBasketCurrencyFlippedSoft(idx))
      score += 1;

   if(InpThrottleOnStrongMomentum && IsSellBasketUnderAdverseMomentumSoft(idx))
      score += 1;

   return score;
}

void UpdateSoftAdverseBasketState()
{
   if(!InpUseSoftAdverseRegime)
      return;

   int barsNeeded = MathMax(1, InpAdverseBarsForThrottle);

   for(int i = 0; i < PairSize; i++)
   {
      // BUY basket
      if(Pairs[i].buyGrid.CountPositions() > 0)
      {
         int score = GetBuyBasketAdverseScoreSoft(i);

         if(score >= 3)
            Pairs[i].buyAdverseBars++;
         else if(Pairs[i].buyAdverseBars > 0)
            Pairs[i].buyAdverseBars--;

         Pairs[i].buySoftThrottle = (Pairs[i].buyAdverseBars >= barsNeeded);


      }
      else
      {
         Pairs[i].buyAdverseBars     = 0;
         Pairs[i].buySoftThrottle    = false;

      }

      // SELL basket
      if(Pairs[i].sellGrid.CountPositions() > 0)
      {
         int score = GetSellBasketAdverseScoreSoft(i);

         if(score >= 3)
            Pairs[i].sellAdverseBars++;
         else if(Pairs[i].sellAdverseBars > 0)
            Pairs[i].sellAdverseBars--;

         Pairs[i].sellSoftThrottle = (Pairs[i].sellAdverseBars >= barsNeeded);


      }
      else
      {
         Pairs[i].sellAdverseBars     = 0;
         Pairs[i].sellSoftThrottle    = false;

      }
   }
}

double GetReducedTpEscapeTargetMoney(const int idx, const bool isBuyGrid, const double normalTargetMoney)
{
   if(!InpUseReducedTpEscape)
      return normalTargetMoney;

   if(idx < 0 || idx >= PairSize)
      return normalTargetMoney;

   bool damaged = false;

   if(isBuyGrid)
      damaged = (Pairs[idx].buyAdverseBars >= MathMax(1, InpReducedTpAfterAdverseBars));
   else
      damaged = (Pairs[idx].sellAdverseBars >= MathMax(1, InpReducedTpAfterAdverseBars));

   if(!damaged)
      return normalTargetMoney;

   double reduced = normalTargetMoney * InpReducedTpFactor;
   if(reduced < InpReducedTpMinMoney)
      reduced = InpReducedTpMinMoney;

   return MathMin(normalTargetMoney, reduced);
}
