﻿//+------------------------------------------------------------------+
//|                                                        Trend.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"


//--- Trend constants
#define     UPTREND      1
#define     DOWNTREND   -1
#define     FLATTREND    0



string TrendToArrow(const int trend)
{
   if(trend == UPTREND)
      return "↑";
   if(trend == DOWNTREND)
      return "↓";
   return "-";
}

string TrendComboText(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return "-/-";

   return TrendToArrow(Pairs[idx].trendH1) + "/" + TrendToArrow(Pairs[idx].trendH4);
}

color TrendComboColor(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return tmdSilver;

   if(Pairs[idx].direction == -1)
      return tmdSilver;

   bool h1Up   = (Pairs[idx].trendH1 == UPTREND);
   bool h1Down = (Pairs[idx].trendH1 == DOWNTREND);
   bool h4Up   = (Pairs[idx].trendH4 == UPTREND);
   bool h4Down = (Pairs[idx].trendH4 == DOWNTREND);

   // Perfect agreement with trade direction
   if(Pairs[idx].direction == ORDER_TYPE_BUY && h4Up)
      return tmdGreen;

   if(Pairs[idx].direction == ORDER_TYPE_SELL && h4Down)
      return tmdGreen;

   // Both TFs agree, but against intended direction
   if((h1Up && h4Up) || (h1Down && h4Down))
      return tmdRed;

   // Mixed / flat / uncertain
   return tmdOrange;
}

double GetEMA(string symbol, ENUM_TIMEFRAMES tf, int period, int shift=0)
{
   int handle = iMA(symbol, tf, period, 0, MODE_EMA, PRICE_CLOSE);
   if(handle == INVALID_HANDLE)
      return 0;

   double buffer[];
   if(CopyBuffer(handle, 0, shift, 2, buffer) < 2)
      return 0;

   return buffer[0];
}




int GetH4Trend(string symbol)
{
   // --- Closed candles only (important)
   double closeH4 = iClose(symbol, PERIOD_H4, 1);
   double closeH1 = iClose(symbol, PERIOD_H1, 1);

   double emaH4_1 = GetEMA(symbol, PERIOD_H4, 200, 1);
   double emaH4_4 = GetEMA(symbol, PERIOD_H4, 200, 4);
   double emaH1_1 = GetEMA(symbol, PERIOD_H1, 200, 1);

   int score = 0;

   // --- H4 position (strong weight)
   if(closeH4 > emaH4_1)
      score += 2;
   else if(closeH4 < emaH4_1)
      score -= 2;

   // --- H4 slope
   if(emaH4_1 > emaH4_4)
      score += 1;
   else if(emaH4_1 < emaH4_4)
      score -= 1;

   // --- H1 confirmation
   if(closeH1 > emaH1_1)
      score += 1;
   else if(closeH1 < emaH1_1)
      score -= 1;

   // --- Convert score → trend state
   if(score >= 1)
      return UPTREND;

   if(score <= -1)
      return DOWNTREND;

   return FLATTREND;
}

int GetH1Trend(string symbol)
{
   // --- Closed candles only
   double closeH1  = iClose(symbol, PERIOD_H1, 1);
   double closeM15 = iClose(symbol, PERIOD_M15, 1);

   double emaH1_1  = GetEMA(symbol, PERIOD_H1, 200, 1);
   double emaH1_4  = GetEMA(symbol, PERIOD_H1, 200, 4);
   double emaM15_1 = GetEMA(symbol, PERIOD_M15, 200, 1);

   int score = 0;

   // --- H1 position vs EMA (main weight)
   if(closeH1 > emaH1_1)
      score += 2;
   else if(closeH1 < emaH1_1)
      score -= 2;

   // --- H1 slope
   if(emaH1_1 > emaH1_4)
      score += 1;
   else if(emaH1_1 < emaH1_4)
      score -= 1;

   // --- M15 confirmation
   if(closeM15 > emaM15_1)
      score += 1;
   else if(closeM15 < emaM15_1)
      score -= 1;

   // --- Convert score to trend state
   if(score >= 1)
      return UPTREND;

   if(score <= -1)
      return DOWNTREND;

   return FLATTREND;
}