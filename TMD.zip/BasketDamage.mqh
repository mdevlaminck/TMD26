#ifndef __TMD_BASKET_DAMAGE_MQH__
#define __TMD_BASKET_DAMAGE_MQH__

input group "=== Basket Damage Engine ===";
input ENUM_ONOFF InpUseBasketDamageEngine        = OFF;
input double     InpDamageMinAdversePctBal       = 10;
input double     InpCriticalMinAdversePctBal     = 15;
input double     InpExitOnlyMinAdversePctBal     = 20;
input int        InpDamageMinAgeBarsM15          = 80;
input int        InpCriticalMinAgeBarsM15        = 160;
input int        InpExitOnlyMinAgeBarsM15        = 320;
input double     InpRecoveryRatioForNormal       = 0.60;
input double     InpRecoveryRatioForDamaged      = 0.35;
input double     InpRecoveryRatioForCritical     = 0.15;
input bool       InpDamageUpgradeOnSoftThrottle  = true;
input bool       InpDamageUpgradeOnInvalidation  = true;
input bool       InpDamageUpgradeOnExpansionRegime = true;
input bool       InpFreezeExpansionAtCritical    = true;
input bool       InpFreezeExpansionAtExitOnly    = true;

double GetBasketAdversePctBalance(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   double pnl = isBuyGrid ? Pairs[idx].buyGrid.GridPnL()
                          : Pairs[idx].sellGrid.GridPnL();

   if(pnl >= 0.0)
      return 0.0;

   return (-pnl / balance) * 100.0;
}

int GetBasketAgeBarsM15(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   double ageDays = GetGridAgeDays(idx, isBuyGrid);
   if(ageDays <= 0.0)
      return 0;

   return (int)MathFloor(ageDays * 96.0);
}

double GetBasketRecoveryRatio(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 1.0;

   double curPnL = isBuyGrid ? Pairs[idx].buyGrid.GridPnL()
                                 : Pairs[idx].sellGrid.GridPnL();

   double worstPnL   = isBuyGrid ? Pairs[idx].buyWorstPnL
                                 : Pairs[idx].sellWorstPnL;

   if(worstPnL >= 0.0)
      return 1.0;

   if(curPnL <= worstPnL)
      return 0.0;

   double lossSpan = -worstPnL;
   if(lossSpan <= 0.0)
      return 1.0;

   double recovered = curPnL - worstPnL;
   double ratio = recovered / lossSpan;

   if(ratio < 0.0)
      ratio = 0.0;
   if(ratio > 1.0)
      ratio = 1.0;

   return ratio;
}

BasketDamageState ComputeBasketDamageState(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return BDS_NORMAL;

   int count = isBuyGrid ? Pairs[idx].buyGrid.CountPositions()
                         : Pairs[idx].sellGrid.CountPositions();

   if(count <= 0)
      return BDS_NORMAL;

   if(InpUseBasketDamageEngine != ON)
      return BDS_NORMAL;

   double adversePct   = GetBasketAdversePctBalance(idx, isBuyGrid);
   int    ageBarsM15   = GetBasketAgeBarsM15(idx, isBuyGrid);
   double recoveryRatio = GetBasketRecoveryRatio(idx, isBuyGrid);

   bool softThrottle = isBuyGrid ? Pairs[idx].buySoftThrottle
                                 : Pairs[idx].sellSoftThrottle;

   bool invalidFrozen = isBuyGrid ? Pairs[idx].buyExpansionFrozenByInvalidation
                                  : Pairs[idx].sellExpansionFrozenByInvalidation;

   BasketDamageState st = BDS_NORMAL;

   if(adversePct >= InpDamageMinAdversePctBal &&
      ageBarsM15 >= InpDamageMinAgeBarsM15)
   {
      st = BDS_DAMAGED;
   }

   if(InpDamageUpgradeOnSoftThrottle && softThrottle)
      st = (BasketDamageState)MathMax((int)st, (int)BDS_DAMAGED);

   if(InpDamageUpgradeOnInvalidation && invalidFrozen)
      st = (BasketDamageState)MathMax((int)st, (int)BDS_DAMAGED);

   if(adversePct >= InpCriticalMinAdversePctBal &&
      ageBarsM15 >= InpCriticalMinAgeBarsM15)
   {
      st = BDS_CRITICAL;
   }

   if(InpDamageUpgradeOnExpansionRegime &&
      Pairs[idx].regime == REGIME_EXPANSION &&
      Pairs[idx].highVolatility &&
      st >= BDS_DAMAGED &&
      recoveryRatio < InpRecoveryRatioForDamaged)
   {
      st = BDS_CRITICAL;
   }

   if(adversePct >= InpExitOnlyMinAdversePctBal &&
      ageBarsM15 >= InpExitOnlyMinAgeBarsM15 &&
      recoveryRatio < InpRecoveryRatioForCritical)
   {
      st = BDS_EXIT_ONLY;
   }

   if(gPortfolioPressureState == PPS_BLOCK &&
      st == BDS_CRITICAL &&
      recoveryRatio < InpRecoveryRatioForCritical)
   {
      st = BDS_EXIT_ONLY;
   }

   if(st == BDS_DAMAGED &&
      adversePct < InpDamageMinAdversePctBal &&
      recoveryRatio >= InpRecoveryRatioForNormal &&
      !softThrottle &&
      !invalidFrozen)
   {
      st = BDS_NORMAL;
   }

   if(st == BDS_CRITICAL &&
      adversePct < InpCriticalMinAdversePctBal &&
      recoveryRatio >= InpRecoveryRatioForDamaged &&
      !invalidFrozen)
   {
      st = BDS_DAMAGED;
   }

   return st;
}

void UpdateBasketDamageStates()
{
   for(int i = 0; i < PairSize; i++)
   {
      if(Pairs[i].buyGrid.CountPositions() > 0)
      {
         Pairs[i].buyRecoveryRatio  = GetBasketRecoveryRatio(i, true);
         Pairs[i].buyBasketAgeBarsM15 = GetBasketAgeBarsM15(i, true);
         Pairs[i].buyDamageState    = ComputeBasketDamageState(i, true);
      }
      else
      {
         Pairs[i].buyRecoveryRatio    = 1.0;
         Pairs[i].buyBasketAgeBarsM15 = 0;
         Pairs[i].buyDamageState      = BDS_NORMAL;
      }

      if(Pairs[i].sellGrid.CountPositions() > 0)
      {
         Pairs[i].sellRecoveryRatio  = GetBasketRecoveryRatio(i, false);
         Pairs[i].sellBasketAgeBarsM15 = GetBasketAgeBarsM15(i, false);
         Pairs[i].sellDamageState    = ComputeBasketDamageState(i, false);
      }
      else
      {
         Pairs[i].sellRecoveryRatio    = 1.0;
         Pairs[i].sellBasketAgeBarsM15 = 0;
         Pairs[i].sellDamageState      = BDS_NORMAL;
      }
   }
}

#endif