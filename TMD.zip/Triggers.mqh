//+------------------------------------------------------------------+
//|                                                     Triggers.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"


bool GetRSITurn(int handle, double &rsi1, double &rsi2)
{
   double rsi[];
   ArraySetAsSeries(rsi, true);

   if(CopyBuffer(handle, 0, 1, 2, rsi) < 2)
      return false;

   rsi1 = rsi[0];
   rsi2 = rsi[1];
   return true;
}

bool IsBuyRSITurnTrigger(int idx)
{
   double rsi1, rsi2;
   if(!GetRSITurn(Pairs[idx].rsiM5Handle, rsi1, rsi2))
      return false;

   return (rsi2 < InpBuyRsi && rsi1 > rsi2);
}

bool IsSellRSITurnTrigger(int idx)
{
   double rsi1, rsi2;
   if(!GetRSITurn(Pairs[idx].rsiM5Handle, rsi1, rsi2))
      return false;

   return (rsi2 > InpSellRsi && rsi1 < rsi2);
}

bool IsBuyReentryTrigger(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;
   if(!Pairs[idx].filtersValid)
      return false;

   MqlRates bar1, bar2;
   if(!GetLastClosedM5(Pairs[idx].symbol, bar1, bar2))
      return false;

   double bbUpper[], bbLower[];
   ArraySetAsSeries(bbUpper, true);
   ArraySetAsSeries(bbLower, true);

   if(CopyBuffer(Pairs[idx].bbM5Handle, 1, 1, 2, bbUpper) < 2)
      return false;
   if(CopyBuffer(Pairs[idx].bbM5Handle, 2, 1, 2, bbLower) < 2)
      return false;

   bool wasOutside = (bar2.close < bbLower[1]);
   bool reentered  = (bar1.close > bbLower[0]);
   bool bullClose  = (bar1.close > bar1.open);

   return (wasOutside && reentered && bullClose);
}

bool IsSellReentryTrigger(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;
   if(!Pairs[idx].filtersValid)
      return false;

   MqlRates bar1, bar2;
   if(!GetLastClosedM5(Pairs[idx].symbol, bar1, bar2))
      return false;

   double bbUpper[], bbLower[];
   ArraySetAsSeries(bbUpper, true);
   ArraySetAsSeries(bbLower, true);

   if(CopyBuffer(Pairs[idx].bbM5Handle, 1, 1, 2, bbUpper) < 2)
      return false;
   if(CopyBuffer(Pairs[idx].bbM5Handle, 2, 1, 2, bbLower) < 2)
      return false;

   bool wasOutside = (bar2.close > bbUpper[1]);
   bool reentered  = (bar1.close < bbUpper[0]);
   bool bearClose  = (bar1.close < bar1.open);

   return (wasOutside && reentered && bearClose);
}

bool IsBullishConfirmCandle(string symbol)
{
   MqlRates bar1, bar2;
   if(!GetLastClosedM5(symbol, bar1, bar2))
      return false;

   double prevMid = (bar2.high + bar2.low) * 0.5;
   return (bar1.close > bar1.open && bar1.close > prevMid);
}

bool IsBearishConfirmCandle(string symbol)
{
   MqlRates bar1, bar2;
   if(!GetLastClosedM5(symbol, bar1, bar2))
      return false;

   double prevMid = (bar2.high + bar2.low) * 0.5;
   return (bar1.close < bar1.open && bar1.close < prevMid);
}

bool HasEntryTrigger(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].direction == ORDER_TYPE_BUY)
   {
      bool rsiTurn        = IsBuyRSITurnTrigger(idx);
      bool bbReentry      = InpUseBB ? IsBuyReentryTrigger(idx) : true;
      bool bullishConfirm = IsBullishConfirmCandle(Pairs[idx].symbol);
      return (rsiTurn && bbReentry && bullishConfirm);
   }

   if(Pairs[idx].direction == ORDER_TYPE_SELL)
   {
      bool rsiTurn     = IsSellRSITurnTrigger(idx);
      bool bbReentry   = InpUseBB ? IsSellReentryTrigger(idx) : true;
      bool bearConfirm = IsBearishConfirmCandle(Pairs[idx].symbol);
      return (rsiTurn && bbReentry && bearConfirm);
   }

   return false;
}
