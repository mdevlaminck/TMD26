#ifndef __TMD_CHARTSTYLE_MQH__
#define __TMD_CHARTSTYLE_MQH__

void StyleChart()
{
   if(!InpStyleChart)
      return;

   long chart = ChartID();

   ChartSetInteger(chart, CHART_COLOR_BACKGROUND, tmdBg);
   ChartSetInteger(chart, CHART_COLOR_FOREGROUND, tmdSilver);
   ChartSetInteger(chart, CHART_COLOR_GRID, tmdSubtleBg);
   ChartSetInteger(chart, CHART_COLOR_CANDLE_BULL, tmdGreen);
   ChartSetInteger(chart, CHART_COLOR_CANDLE_BEAR, tmdRed);
   ChartSetInteger(chart, CHART_COLOR_CHART_UP, tmdGreen);
   ChartSetInteger(chart, CHART_COLOR_CHART_DOWN, tmdRed);
   ChartSetInteger(chart, CHART_COLOR_STOP_LEVEL, tmdOrange);
   ChartSetInteger(chart, CHART_COLOR_BID, tmdBid);
   ChartSetInteger(chart, CHART_COLOR_ASK, tmdAsk);

   ChartSetInteger(chart, CHART_SHOW_GRID, false);
   ChartSetInteger(chart, CHART_SHOW_VOLUMES, false);
   ChartSetInteger(chart, CHART_SHOW_PERIOD_SEP, false);
   ChartSetInteger(chart, CHART_SHOW_OBJECT_DESCR, false);
   ChartSetInteger(chart, CHART_SHOW_OHLC, true);
   ChartSetInteger(chart, CHART_SHOW_ASK_LINE, true);
   ChartSetInteger(chart, CHART_SHOW_BID_LINE, true);

   ChartSetInteger(chart, CHART_MODE, CHART_CANDLES);
   ChartSetInteger(chart, CHART_SCALE, 3);
   ChartSetInteger(chart, CHART_AUTOSCROLL, true);
   ChartSetInteger(chart, CHART_SHIFT, true);

   ChartRedraw();
}

#endif