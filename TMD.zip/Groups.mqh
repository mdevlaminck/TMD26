#ifndef __TMD_GROUPS_MQH__
#define __TMD_GROUPS_MQH__

bool IsInGroup(string symbol, string &group[])
{
   for(int i = 0; i < ArraySize(group); i++)
   {
      if(symbol == InpPrefix + group[i] + InpSuffix)
         return true;
   }
   return false;
}

int GetGroup(string symbol)
{
   if(IsInGroup(symbol, GROUP_USD))    return 0;
   if(IsInGroup(symbol, GROUP_EUR))    return 1;
   if(IsInGroup(symbol, GROUP_GBP))    return 2;
   if(IsInGroup(symbol, GROUP_AUDNZD)) return 3;
   if(IsInGroup(symbol, GROUP_SAFE))   return 4;
   return -1;
}

bool CanOpenGrid(string symbol, bool isBuy)
{
   int group = GetGroup(symbol);
   if(group == -1)
      return true;

   int total = gGroupStates[group].buyCount + gGroupStates[group].sellCount;
   if(total >= 2)
      return false;

   if(isBuy && gGroupStates[group].buyCount > 0)
      return false;

   if(!isBuy && gGroupStates[group].sellCount > 0)
      return false;

   return true;
}

void RefreshGroupStates()
{
   for(int g = 0; g < 5; g++)
   {
      gGroupStates[g].buyCount = 0;
      gGroupStates[g].sellCount = 0;
   }

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;

      string sym = PositionGetString(POSITION_SYMBOL);
      int group  = GetGroup(sym);
      if(group < 0)
         continue;

      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      if(type == POSITION_TYPE_BUY)  gGroupStates[group].buyCount = 1;
      if(type == POSITION_TYPE_SELL) gGroupStates[group].sellCount = 1;
   }
}



#endif