// Utils

//+------------------------------------------------------------------+
//| BASIC MATH HELPERS                                               |
//+------------------------------------------------------------------+

double Clamp(double value, double minVal, double maxVal)
{
   if(value < minVal) return minVal;
   if(value > maxVal) return maxVal;
   return value;
}

double SafeDiv(double num, double den, double fallback = 0.0)
{
   if(den == 0.0)
      return fallback;
   return num / den;
}

double Normalize01(double value, double minVal, double maxVal)
{
   if(maxVal - minVal == 0.0)
      return 0.0;

   return Clamp((value - minVal) / (maxVal - minVal), 0.0, 1.0);
}



//+------------------------------------------------------------------+
//| PRICE / LOT HELPERS                                              |
//+------------------------------------------------------------------+

double PointsToPrice(string symbol, double points)
{
   double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
   return points * point;
}

double PriceToPoints(string symbol, double priceDiff)
{
   double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
   if(point <= 0.0)
      return 0.0;

   return priceDiff / point;
}

double NormalizeLot(string symbol, double lots)
{
   double step = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
   double min  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
   double max  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);

   if(step <= 0.0) step = 0.01;
   if(min <= 0.0)  min  = step;
   if(max <= 0.0)  max  = 100.0;

   lots = MathFloor(lots / step) * step;

   if(lots < min) lots = min;
   if(lots > max) lots = max;

   return lots;
}

//+------------------------------------------------------------------+
//| FORMATTING HELPERS                                               |
//+------------------------------------------------------------------+

string FormatDouble(double value, int digits = 2)
{
   return DoubleToString(value, digits);
}

string FormatMoney(double value)
{
   return DoubleToString(value, 2);
}

string FormatLots(double lots)
{
   return DoubleToString(lots, 2);
}

string FormatPercent(double value, int digits = 1)
{
   return DoubleToString(value, digits) + "%";
}




//+------------------------------------------------------------------+
//| STRING HELPERS                                                   |
//+------------------------------------------------------------------+

string ToUpper(string s)
{
   StringToUpper(s);
   return s;
}



//+------------------------------------------------------------------+
//| TIME HELPERS                                                     |
//+------------------------------------------------------------------+

string FormatTime(datetime t)
{
   MqlDateTime dt;
   TimeToStruct(t, dt);

   string hh = (dt.hour < 10 ? "0" : "") + IntegerToString(dt.hour);
   string mm = (dt.min  < 10 ? "0" : "") + IntegerToString(dt.min);
   string ss = (dt.sec  < 10 ? "0" : "") + IntegerToString(dt.sec);

   return hh + ":" + mm + ":" + ss;
}

bool IsNewBar(string symbol, ENUM_TIMEFRAMES tf, datetime &lastTime)
{
   datetime t = iTime(symbol, tf, 0);
   if(t != lastTime)
   {
      lastTime = t;
      return true;
   }
   return false;
}


bool CheckMarketOpen(string symbol)
{
   MqlDateTime date_cur;
   TimeTradeServer(date_cur);
   datetime seconds_cur = date_cur.hour * 3600 + date_cur.min * 60 + date_cur.sec;

   for(int i = 0; ; i++)
   {
      datetime seconds_from = 0, seconds_to = 0;
      if(!SymbolInfoSessionTrade(symbol, (ENUM_DAY_OF_WEEK)date_cur.day_of_week, i, seconds_from, seconds_to))
         break;

      if(seconds_cur >= seconds_from && seconds_cur < seconds_to)
         return true;
   }
   return false;
}

bool IsBrokerTradeWindow()
{
   MqlDateTime broker;
   TimeToStruct(TimeCurrent(), broker);

   // --- BLOCK: July (month = 7)
   if(broker.mon == 7)
      return false;

   // --- BLOCK: 20 Dec -> 31 Dec
   if(broker.mon == 12 && broker.day >= 20)
      return false;

   // --- BLOCK: 1 Jan -> 10 Jan
   if(broker.mon == 1 && broker.day <= 10)
      return false;

   // --- OPTIONAL: broker session filters (fix your logic)
   // Monday before 05:00 -> NO trading
   if(broker.day_of_week == 1 && broker.hour < 10)
      return false;

   // Friday after 19:00 -> NO trading
   if(broker.day_of_week == 5 && broker.hour >= 19)
      return false;

   return true;
}
double CalculateLotSize(string symbol, double balancePerLot = 500.0, double lotPerBalance = 0.01)
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double exponent   = 0.65;
   double capBalance = 10000.0;

   double lots = (balance / balancePerLot) * lotPerBalance;

   if(balance > capBalance)
   {
      double baseLots = (capBalance / balancePerLot) * lotPerBalance;
      double excess   = balance - capBalance;
      lots = baseLots + MathPow(excess / balancePerLot, exponent) * lotPerBalance;
   }

   return NormalizeLot(symbol, lots);
}



string GetLeverageText()
{
   long lev = AccountInfoInteger(ACCOUNT_LEVERAGE);
   return "1:" + IntegerToString((int)lev);
}

string GetBrokerText()
{
   return AccountInfoString(ACCOUNT_COMPANY);
}

string GetAccountNameText()
{
   return AccountInfoString(ACCOUNT_NAME);
}

bool IsIndexInArray(const int value, const int &arr[])
{
   for(int i = 0; i < ArraySize(arr); i++)
   {
      if(arr[i] == value)
         return true;
   }
   return false;
}

bool GetLastClosedM5(string symbol, MqlRates &bar1, MqlRates &bar2)
{
   MqlRates rates[];
   ArraySetAsSeries(rates, true);

   if(CopyRates(symbol, PERIOD_M5, 1, 2, rates) < 2)
      return false;

   bar1 = rates[0];
   bar2 = rates[1];
   return true;
}

double ATRToPoints(string symbol, double atrPrice)
{
   double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
   if(point <= 0.0)
      return 0.0;

   return atrPrice / point;
}


