CTrade trade;

#define PANEL_PREFIX   "TMDP_"
#define PANEL_CUR_ROWS 10
#define PANEL_SYM_ROWS 30

string Symbols[] = {
   "EURUSD","GBPUSD","AUDUSD","NZDUSD",
   "USDJPY","USDCHF","USDCAD",
   "EURGBP","EURJPY","EURCHF","EURAUD","EURNZD","EURCAD",
   "GBPJPY","GBPCHF","GBPAUD","GBPNZD","GBPCAD",
   "AUDJPY","AUDCHF","AUDNZD","AUDCAD",
   "NZDJPY","NZDCHF","NZDCAD",
   "CADJPY","CADCHF","CHFJPY",
   "XAUUSD","XAGUSD"
};

string Currencies[] = {
   "USD","EUR","GBP","JPY","CHF","AUD","NZD","CAD","XAU","XAG"
};

string GROUP_USD[]    = {"EURUSD","GBPUSD","AUDUSD","NZDUSD","USDJPY","USDCHF","USDCAD"};
string GROUP_EUR[]    = {"EURGBP","EURJPY","EURCHF","EURAUD","EURNZD","EURCAD"};
string GROUP_GBP[]    = {"GBPJPY","GBPCHF","GBPAUD","GBPNZD","GBPCAD"};
string GROUP_AUDNZD[] = {"AUDJPY","AUDCHF","AUDNZD","AUDCAD","NZDJPY","NZDCHF","NZDCAD"};
string GROUP_SAFE[]   = {"CADJPY","CADCHF","CHFJPY"};

color tmdGreen    = C'38,166,154';
color tmdRed      = C'239,83,80';
color tmdOrange   = C'255,152,0';
color tmdSilver   = C'219,219,219';
color tmdBg       = C'16,26,37';
color tmdSubtleBg = C'42,58,79';
color tmdBid      = C'41,98,255';
color tmdAsk      = C'247,82,95';

string gPanelObjects[];
double currencyStrength[10];


double currentPnL = 0.0;
int    PairSize   = 0;
bool   brokerWindowOpen = false;


double gPeakEquity       = 0.0;
bool   gFreezeNewEntries = false;
bool   gEmergencyClose   = false;

string gRiskStateText    = "NORMAL";
color  gRiskStateColor   = clrNONE;
string gEntryStateText   = "ALLOWED";
color  gEntryStateColor  = clrNONE;
string gExpandStateText  = "ALLOWED";
color  gExpandStateColor = clrNONE;
string gRiskReasonText   = "-";
color  gRiskReasonColor  = clrNONE;

bool gRiskOffActive = false;
bool gRiskOffCooldown = false;