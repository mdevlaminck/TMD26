//+------------------------------------------------------------------+
//|                                                     PairData.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+

input group "=== Pair Filter ===";
input int InpHistory = 8 ; 
input double InpScoreWeight = 3.0;
input double InpAccWeight = 1.5;
input double InpSlopeWeight = 2.5;
input double InpCurrScore = 3.0;
input double InpStrongAccelThreshold = 6.5;


struct PairData
{
   string symbol;

   double score;

   double history[];
   int    index;
   bool   filled;

   double slope;
   double accel;
   double baseStrength;
   double quoteStrength;
   bool   aligned;
   double currencyScore;
   double comp;
   
   double edgeScore;
   double edgeMomentum;
   double edgePullback;
   double edgeTrend;
   double edgeRegime;
   double edgeTrigger;
   
    bool         isTopPair;

   int direction;

   GridManager *buyGrid;
   GridManager *sellGrid;

   int rsiM5Handle;
   int bbM5Handle;

   int atrM5Handle;
   int atrM15Handle;
   int atrH1Handle;
   int atrH4Handle;

   double sM5;
   double sM15;
   double sH1;
   double sH4;
   double bullScore;
   double signedStrength;
   double atrNormM15;

   bool   eligibleNow;
   string stateText;
   color  stateColor;
   color  dotColor;

   bool   filtersValid;
   double rsiM5;
   double bbUpperM5;
   double bbLowerM5;
   bool   rsiBuyOk;
   bool   rsiSellOk;
   bool   bbBuyOk;
   bool   bbSellOk;


   bool structurallyValid;

   bool marketOpen;

   int    openCount;
   double openLots;
   
   // Volatility filter
   int    atrHandle;
   double atrValuePoints;
   double atrValuePrice;
   bool   highVolatility;
   
   string waitReason;
   
   GapBias mondayGapBias;
   int     mondayGapDay;
   
   int    trendH4;
   int    trendH1;

   
   // Soft adverse regime state for live baskets
   int    buyAdverseBars;
   int    sellAdverseBars;
   bool   buySoftThrottle;
   bool   sellSoftThrottle;

   
   AdaptiveGridState adaptiveState;
   bool              adaptiveBlockEntry;
   
   // Persistent invalidation tracking
   int    buyInvalidBars;
   int    sellInvalidBars;
   bool   buyExpansionFrozenByInvalidation;
   bool   sellExpansionFrozenByInvalidation;
   
   int    emaM15Handle;
   int    emaH1Handle;

   double emaM15;
   double emaH1;

   double entryStretchM15;
   double entryStretchH1;

   bool   locationOk;
   
   double buyWorstPnL;
   double sellWorstPnL;
   
   BasketDamageState buyDamageState;
   BasketDamageState sellDamageState;
   double            buyRecoveryRatio;
   double            sellRecoveryRatio;
   int               buyBasketAgeBarsM15;
   int               sellBasketAgeBarsM15;
   
   MarketRegime regime;
   int          regimeScoreTrend;
   int          regimeScoreExpansion;
   bool         regimeBlockBuy;
   bool         regimeBlockSell;
   

   
};

void InitPairs()
{
   int total = ArraySize(Symbols);
   PairSize = total;
   ArrayResize(Pairs, total);

   for(int i = 0; i < total; i++)
   {
      Pairs[i].symbol = InpPrefix + Symbols[i] + InpSuffix;
      SymbolSelect(Pairs[i].symbol, true);

      Pairs[i].index = 0;
      Pairs[i].filled = false;
      ArrayInitialize(Pairs[i].history, 0.0);
      ArrayResize(Pairs[i].history,InpHistory);

      Pairs[i].rsiM5Handle = iRSI(Pairs[i].symbol, PERIOD_M5, 14, PRICE_CLOSE);
      Pairs[i].bbM5Handle  = iBands(Pairs[i].symbol, PERIOD_M5, 20, 0, 2, PRICE_CLOSE);

      double initialLot = InpInitialLot;
      if(InpUseAutoLot)
         initialLot = CalculateLotSize(Pairs[i].symbol, InpBalancePerLot);

      Pairs[i].buyGrid = new GridManager(Pairs[i].symbol, GRID_BUY, initialLot, GetGapPoints(Pairs[i].symbol), InpProfitPercent, InpMaxOrders);
      Pairs[i].buyGrid.SetGridMagicNumber(InpMagicBuy + i);
      Pairs[i].buyGrid.SetGridMultiplier(InpGridMultiplier);
      Pairs[i].buyGrid.SetGridMaxDD(InpBasketHardStopPctBal);

      Pairs[i].sellGrid = new GridManager(Pairs[i].symbol, GRID_SELL, initialLot, GetGapPoints(Pairs[i].symbol), InpProfitPercent, InpMaxOrders);
      Pairs[i].sellGrid.SetGridMagicNumber(InpMagicSell + i);
      Pairs[i].sellGrid.SetGridMultiplier(InpGridMultiplier);
      Pairs[i].sellGrid.SetGridMaxDD(InpBasketHardStopPctBal);
      
      Pairs[i].buyGrid.SetUseInternalTPClose(false);
      Pairs[i].sellGrid.SetUseInternalTPClose(false);

      Pairs[i].atrM5Handle  = iATR(Pairs[i].symbol, PERIOD_M5, 14);
      Pairs[i].atrM15Handle = iATR(Pairs[i].symbol, PERIOD_M15, 14);
      Pairs[i].atrH1Handle  = iATR(Pairs[i].symbol, PERIOD_H1, 14);
      Pairs[i].atrH4Handle  = iATR(Pairs[i].symbol, PERIOD_H4, 14);
      
      Pairs[i].emaM15Handle = iMA(Pairs[i].symbol, PERIOD_M15, InpLocationEmaPeriodM15, 0, MODE_EMA, PRICE_CLOSE);
      Pairs[i].emaH1Handle  = iMA(Pairs[i].symbol, PERIOD_H1,  InpLocationEmaPeriodH1,  0, MODE_EMA, PRICE_CLOSE);

      Pairs[i].filtersValid = false;
      Pairs[i].rsiM5        = 0.0;
      Pairs[i].bbUpperM5    = 0.0;
      Pairs[i].bbLowerM5    = 0.0;
      Pairs[i].rsiBuyOk     = false;
      Pairs[i].rsiSellOk    = false;
      Pairs[i].bbBuyOk      = false;
      Pairs[i].bbSellOk     = false;

      Pairs[i].eligibleNow = false;
      Pairs[i].stateText   = "WAIT";
      Pairs[i].stateColor  = tmdSilver;
      Pairs[i].dotColor    = tmdSilver;

      Pairs[i].structurallyValid  = false;

      Pairs[i].sM5 = 0.0;
      Pairs[i].sM15 = 0.0;
      Pairs[i].sH1 = 0.0;
      Pairs[i].sH4 = 0.0;
      Pairs[i].bullScore = 5.0;
      Pairs[i].signedStrength = 0.0;
      Pairs[i].atrNormM15 = 1.0;

      Pairs[i].marketOpen = false;
      Pairs[i].openCount  = 0;
      Pairs[i].openLots   = 0.0;
      
      Pairs[i].atrHandle = iATR(Pairs[i].symbol, InpVolatilityTF, InpATRPeriod);
      Pairs[i].atrValuePoints = 0.0;
      Pairs[i].atrValuePrice  = 0.0;
      Pairs[i].highVolatility = false;
      
      Pairs[i].mondayGapBias = GAP_NONE;
      Pairs[i].mondayGapDay  = -1;
      
      Pairs[i].trendH1 = FLATTREND;
      Pairs[i].trendH4 = FLATTREND;
      
      Pairs[i].buyAdverseBars    = 0;
      Pairs[i].sellAdverseBars   = 0;
      Pairs[i].buySoftThrottle   = false;
      Pairs[i].sellSoftThrottle  = false;

      
      Pairs[i].adaptiveState      = AGS_NORMAL;
      Pairs[i].adaptiveBlockEntry = false;
      
      Pairs[i].buyInvalidBars  = 0;
      Pairs[i].sellInvalidBars = 0;
      Pairs[i].buyExpansionFrozenByInvalidation  = false;
      Pairs[i].sellExpansionFrozenByInvalidation = false;
      
      Pairs[i].emaM15          = 0.0;
      Pairs[i].emaH1           = 0.0;
      Pairs[i].entryStretchM15 = 0.0;
      Pairs[i].entryStretchH1  = 0.0;
      Pairs[i].locationOk      = true;
      Pairs[i].buyWorstPnL  = 0.0;
      Pairs[i].sellWorstPnL = 0.0;
      
      Pairs[i].edgeScore    = 0.0;
      Pairs[i].edgeMomentum = 0.0;
      Pairs[i].edgePullback = 0.0;
      Pairs[i].edgeTrend    = 0.0;
      Pairs[i].edgeRegime   = 0.0;
      Pairs[i].edgeTrigger  = 0.0;
      Pairs[i].isTopPair    = false;
      
      Pairs[i].buyDamageState    = BDS_NORMAL;
      Pairs[i].sellDamageState   = BDS_NORMAL;
      Pairs[i].buyRecoveryRatio  = 1.0;
      Pairs[i].sellRecoveryRatio = 1.0;
      Pairs[i].buyBasketAgeBarsM15  = 0;
      Pairs[i].sellBasketAgeBarsM15 = 0;
      
      
      if(Pairs[i].atrHandle == INVALID_HANDLE)
      {
         Print("Failed to create ATR handle for ", Pairs[i].symbol);
      }
      
      if(Pairs[i].emaM15Handle == INVALID_HANDLE)
         Print("Failed to create M15 EMA handle for ", Pairs[i].symbol);

      if(Pairs[i].emaH1Handle == INVALID_HANDLE)
         Print("Failed to create H1 EMA handle for ", Pairs[i].symbol);
      
   }
}



void UpdateAllPairs()
{
   ArrayInitialize(currencyStrength, 0.0);

   int counts[10];
   ArrayInitialize(counts, 0);

   for(int i = 0; i < PairSize; i++)
   {
      Pairs[i].marketOpen = CheckMarketOpen(Pairs[i].symbol);

      Pairs[i].sM5  = GetStrengthFast(Pairs[i].symbol, PERIOD_M5,  Pairs[i].atrM5Handle);
      Pairs[i].sM15 = GetStrengthFast(Pairs[i].symbol, PERIOD_M15, Pairs[i].atrM15Handle);
      Pairs[i].sH1  = GetStrengthFast(Pairs[i].symbol, PERIOD_H1,  Pairs[i].atrH1Handle);
      Pairs[i].sH4  = GetStrengthFast(Pairs[i].symbol, PERIOD_H4,  Pairs[i].atrH4Handle);

      Pairs[i].direction      = GetDirectionFromStrengths(Pairs[i].sH1, Pairs[i].sH4, Pairs[i].sM15);
      Pairs[i].bullScore      = GetBullScoreFromStrengths(Pairs[i].sM5, Pairs[i].sM15, Pairs[i].sH1, Pairs[i].sH4);
      Pairs[i].signedStrength = Pairs[i].bullScore - 5.0;
      Pairs[i].score          = ToDirectionalScore(Pairs[i].bullScore, Pairs[i].direction);
      Pairs[i].atrNormM15     = GetATRNormalizedFast(Pairs[i].symbol, Pairs[i].atrM15Handle, PERIOD_M15);
      
      Pairs[i].trendH1 = (int) GetH1Trend(Pairs[i].symbol);
      Pairs[i].trendH4 = (int) GetH4Trend(Pairs[i].symbol);
            
      UpdatePairVolatility(Pairs[i]);
      UpdatePairLocationState(Pairs[i]);

      UpdatePairHistory(Pairs[i], Pairs[i].score);
      UpdateMomentum(Pairs[i]);

      string base  = StringSubstr(Pairs[i].symbol, 0, 3);
      string quote = StringSubstr(Pairs[i].symbol, 3, 3);

      int baseIdx  = GetCurrencyIndexFast(base);
      int quoteIdx = GetCurrencyIndexFast(quote);

      if(baseIdx >= 0)
      {
         currencyStrength[baseIdx] += Pairs[i].signedStrength;
         counts[baseIdx]++;
      }

      if(quoteIdx >= 0)
      {
         currencyStrength[quoteIdx] -= Pairs[i].signedStrength;
         counts[quoteIdx]++;
      }
   }

   for(int i = 0; i < 10; i++)
   {
      if(counts[i] > 0)
         currencyStrength[i] /= counts[i];
   }

   for(int i = 0; i < PairSize; i++)
   {
      int baseIdx, quoteIdx;
      GetPairCurrencies(Pairs[i].symbol, baseIdx, quoteIdx);

      if(baseIdx < 0 || quoteIdx < 0)
      {
         Pairs[i].aligned       = false;
         Pairs[i].baseStrength  = 0.0;
         Pairs[i].quoteStrength = 0.0;
         Pairs[i].currencyScore = 0.0;
         Pairs[i].comp          = 0.0;
         continue;
      }

      double baseStr  = currencyStrength[baseIdx];
      double quoteStr = currencyStrength[quoteIdx];

      Pairs[i].baseStrength  = baseStr;
      Pairs[i].quoteStrength = quoteStr;

      double dirSpread = 0.0;
      if(Pairs[i].direction == ORDER_TYPE_BUY)
         dirSpread = baseStr - quoteStr;
      else if(Pairs[i].direction == ORDER_TYPE_SELL)
         dirSpread = quoteStr - baseStr;

      double curScore = (MathTanh(dirSpread * 1.2) + 1.0) * 5.0;
      Pairs[i].currencyScore = Clamp(curScore, 0.0, 10.0);

      Pairs[i].aligned =
         (Pairs[i].direction == ORDER_TYPE_BUY  && baseStr > quoteStr) ||
         (Pairs[i].direction == ORDER_TYPE_SELL && quoteStr > baseStr);
      

      
      double compRaw =
         Pairs[i].score         * InpScoreWeight +
         Pairs[i].slope         * InpSlopeWeight +
         Pairs[i].accel         * InpAccWeight +
         Pairs[i].currencyScore * InpCurrScore;

      Pairs[i].comp = Clamp(compRaw / 10.0, 0.0, 10.0);
      

      
   }

   UpdateRiskOffState();
}

void UpdatePairVolatility(PairData &pair)
{
   pair.atrValuePrice  = GetATRValue(pair.atrHandle);
   pair.atrValuePoints = ATRToPoints(pair.symbol, pair.atrValuePrice);
   pair.highVolatility = IsHighVolatility(pair.symbol, pair.atrValuePrice);
}

void ReleasePairHandles()
{
   for(int i = 0; i < ArraySize(Pairs); i++)
   {
      if(Pairs[i].rsiM5Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].rsiM5Handle);
         Pairs[i].rsiM5Handle = INVALID_HANDLE;
      }

      if(Pairs[i].bbM5Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].bbM5Handle);
         Pairs[i].bbM5Handle = INVALID_HANDLE;
      }

      if(Pairs[i].atrM5Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].atrM5Handle);
         Pairs[i].atrM5Handle = INVALID_HANDLE;
      }

      if(Pairs[i].atrM15Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].atrM15Handle);
         Pairs[i].atrM15Handle = INVALID_HANDLE;
      }

      if(Pairs[i].atrH1Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].atrH1Handle);
         Pairs[i].atrH1Handle = INVALID_HANDLE;
      }

      if(Pairs[i].atrH4Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].atrH4Handle);
         Pairs[i].atrH4Handle = INVALID_HANDLE;
      }

      if(Pairs[i].atrHandle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].atrHandle);
         Pairs[i].atrHandle = INVALID_HANDLE;
      }
      if(Pairs[i].emaM15Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].emaM15Handle);
         Pairs[i].emaM15Handle = INVALID_HANDLE;
      }

      if(Pairs[i].emaH1Handle != INVALID_HANDLE)
      {
         IndicatorRelease(Pairs[i].emaH1Handle);
         Pairs[i].emaH1Handle = INVALID_HANDLE;
      }
   }
}

void RefreshPositionCaches()
{
   for(int i = 0; i < PairSize; i++)
   {
      Pairs[i].openCount = 0;
      Pairs[i].openLots  = 0.0;
   }

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;

      string sym = PositionGetString(POSITION_SYMBOL);
      double vol = PositionGetDouble(POSITION_VOLUME);

      for(int j = 0; j < PairSize; j++)
      {
         if(Pairs[j].symbol == sym)
         {
            Pairs[j].openCount++;
            Pairs[j].openLots += vol;
            break;
         }
      }
   }
}

void RefreshAllPairFilterCaches()
{
   for(int i = 0; i < PairSize; i++)
   {
      bool hasLive    = HasActiveGrid(Pairs[i]);
      bool structural = IsPairStructurallyValid(i);

      Pairs[i].structurallyValid  = structural;


      if(structural || hasLive)
         RefreshPairFilterCache(i);
      else
         InvalidatePairFilterCache(i);
   }
}

bool IsPairEligibleNow(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   Pairs[idx].waitReason = "";

   if(!Pairs[idx].structurallyValid)
      return false;

   if(IsBlockedByMondayGap(Pairs[idx], Pairs[idx].direction))
   {
      Pairs[idx].waitReason = "MON GAP";
      return false;
   }
   if(!Pairs[idx].filtersValid)
   {
      Pairs[idx].waitReason = "LOAD";
      return false;
   }

   string riskReason = "";
   if(!AllowNewRiskEntry(idx, riskReason))
   {
      Pairs[idx].waitReason = riskReason;
      return false;
   }

   if(Pairs[idx].direction == ORDER_TYPE_BUY)
   {
      if(Pairs[idx].buyGrid.CountPositions() > 0)
      {
         Pairs[idx].waitReason = "IN BUY";
         return false;
      }

      if(!CanOpenGrid(Pairs[idx].symbol, true))
      {
         Pairs[idx].waitReason = "NO BUY";
         return false;
      }

      return true;
   }

   if(Pairs[idx].direction == ORDER_TYPE_SELL)
   {
      if(Pairs[idx].sellGrid.CountPositions() > 0)
      {
         Pairs[idx].waitReason = "IN SELL";
         return false;
      }

      if(!CanOpenGrid(Pairs[idx].symbol, false))
      {
         Pairs[idx].waitReason = "NO SELL";
         return false;
      }

      return true;
   }

   return false;
}


void UpdatePairHistory(PairData &p, double score)
{
   p.history[p.index] = score;
   p.index++;

   if(p.index >= InpHistory)
   {
      p.index = 0;
      p.filled = true;
   }
}

void UpdateMomentum(PairData &p)
{
   int count = p.filled ? InpHistory : p.index;

   if(count < 2)
   {
      p.slope = 5.0;
      p.accel = 5.0;
      return;
   }

   int newestIdx = (p.index - 1 + InpHistory) % InpHistory;
   int oldestIdx = p.filled ? p.index : 0;

   double rawSlope = (p.history[newestIdx] - p.history[oldestIdx]) / (count - 1);
   double rawAccel = 0.0;

   if(count >= 3)
   {
      int idx2 = (newestIdx - 1 + InpHistory) % InpHistory;
      int idx3 = (newestIdx - 2 + InpHistory) % InpHistory;

      double slopeNow  = p.history[newestIdx] - p.history[idx2];
      double slopePrev = p.history[idx2] - p.history[idx3];
      rawAccel = slopeNow - slopePrev;
   }

   double vol = p.atrNormM15;
   if(vol <= 0.0)
      vol = 1.0;

   double slopeMult = 1.2 / vol;
   double accelMult = 2.0 / vol;

   p.slope = (MathTanh(rawSlope * slopeMult) + 1.0) * 5.0;
   p.accel = (MathTanh(rawAccel * accelMult) + 1.0) * 5.0;

   p.slope = Clamp(p.slope, 0.0, 10.0);
   p.accel = Clamp(p.accel, 0.0, 10.0);
}
bool HasActiveGrid(PairData &p)
{
   return (p.buyGrid.CountPositions() > 0 || p.sellGrid.CountPositions() > 0);
}

void InvalidatePairFilterCache(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return;

   Pairs[idx].filtersValid = false;
   Pairs[idx].rsiM5        = 0.0;
   Pairs[idx].bbUpperM5    = 0.0;
   Pairs[idx].bbLowerM5    = 0.0;
   Pairs[idx].rsiBuyOk     = false;
   Pairs[idx].rsiSellOk    = false;
   Pairs[idx].bbBuyOk      = false;
   Pairs[idx].bbSellOk     = false;
}

void RefreshPairFilterCache(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return;

   InvalidatePairFilterCache(idx);

   MqlRates bar1, bar2;
   if(!GetLastClosedM5(Pairs[idx].symbol, bar1, bar2))
      return;

   double rsiBuf[];
   ArraySetAsSeries(rsiBuf, true);
   if(CopyBuffer(Pairs[idx].rsiM5Handle, 0, 1, 2, rsiBuf) < 2)
      return;

   Pairs[idx].rsiM5 = rsiBuf[0];

   if(InpUseBB)
   {
      double bbUpper[], bbLower[];
      ArraySetAsSeries(bbUpper, true);
      ArraySetAsSeries(bbLower, true);

      if(CopyBuffer(Pairs[idx].bbM5Handle, 1, 1, 2, bbUpper) < 2)
         return;
      if(CopyBuffer(Pairs[idx].bbM5Handle, 2, 1, 2, bbLower) < 2)
         return;

      Pairs[idx].bbUpperM5 = bbUpper[0];
      Pairs[idx].bbLowerM5 = bbLower[0];

      Pairs[idx].bbBuyOk  = IsBuyReentryTrigger(idx);
      Pairs[idx].bbSellOk = IsSellReentryTrigger(idx);
   }
   else
   {
      Pairs[idx].bbUpperM5 = 0.0;
      Pairs[idx].bbLowerM5 = 0.0;
      Pairs[idx].bbBuyOk   = true;
      Pairs[idx].bbSellOk  = true;
   }

   Pairs[idx].rsiBuyOk  = (rsiBuf[1] < InpBuyRsi  && rsiBuf[0] > rsiBuf[1]);
   Pairs[idx].rsiSellOk = (rsiBuf[1] > InpSellRsi && rsiBuf[0] < rsiBuf[1]);

   Pairs[idx].filtersValid = true;
}

bool IsPairStructurallyValid(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(!brokerWindowOpen)
      return false;
   if(!Pairs[idx].marketOpen)
      return false;
   if(Pairs[idx].direction == -1)
      return false;
   if(!Pairs[idx].aligned)
      return false;
   if(!InpUseRankOnlySelection)
   {
      if(Pairs[idx].comp < InpMinScore)
         return false;
      if(InpUseEdgeScoreEngine && Pairs[idx].edgeScore < InpMinEdgeScore)
         return false;
   }       
   if(Pairs[idx].accel < InpMinAccel)
      return false;
   if(Pairs[idx].accel > InpMaxAccel)
      return false; 
     if(Pairs[idx].slope < InpMinSl)
      return false;     
   if(Pairs[idx].edgePullback < InpMinPB)
      return false;
   if(Pairs[idx].edgeRegime < InpMinReg)
      return false;    
   if (Pairs[idx].edgeScore < InpMinEdgeScore) {
      return false;   
   }        
   if(IsMetal(Pairs[idx].symbol))
   {
      if(Pairs[idx].accel < 5.0)
         return false;
   
      if(Pairs[idx].comp < MathMax(InpMinScore, 7.2))
         return false;
   }
   if(InpUseLocationFilter && !Pairs[idx].locationOk)
      return false;   
   if(InpUseRiskProtection)
   {
      if(gEmergencyClose || gFreezeNewEntries)
         return false;

      if(IsExposureTooHigh())
         return false;

      if(!SpreadAcceptable(Pairs[idx].symbol, InpMaxSpreadPoints))
         return false;
   }

   return true;
}



int CountLiveBasketsForCurrency(const string currency)
{
   if(currency == "")
      return 0;

   int count = 0;

   for(int i = 0; i < PairSize; i++)
   {
      bool hasLive = (Pairs[i].buyGrid.CountPositions() > 0 || Pairs[i].sellGrid.CountPositions() > 0);
      if(!hasLive)
         continue;

      string base  = StringSubstr(Pairs[i].symbol, 0, 3);
      string quote = StringSubstr(Pairs[i].symbol, 3, 3);

      if(base == currency || quote == currency)
         count++;
   }

   return count;
}

double GetLiveLotsForCurrency(const string currency)
{
   if(currency == "")
      return 0.0;

   double lots = 0.0;

   for(int i = 0; i < PairSize; i++)
   {
      string base  = StringSubstr(Pairs[i].symbol, 0, 3);
      string quote = StringSubstr(Pairs[i].symbol, 3, 3);

      if(base != currency && quote != currency)
         continue;

      lots += Pairs[i].buyGrid.CountLots();
      lots += Pairs[i].sellGrid.CountLots();
   }

   return lots;
}

int GetCurrencyIndexFast(string cur)
{
   cur = ToUpper(cur);

   if(cur == "USD") return 0;
   if(cur == "EUR") return 1;
   if(cur == "GBP") return 2;
   if(cur == "JPY") return 3;
   if(cur == "CHF") return 4;
   if(cur == "AUD") return 5;
   if(cur == "NZD") return 6;
   if(cur == "CAD") return 7;
   if(cur == "XAU") return 8;
   if(cur == "XAG") return 9;

   return -1;
}
void GetPairCurrencies(string symbol, int &baseIdx, int &quoteIdx)
{
   string base  = StringSubstr(symbol, 0, 3);
   string quote = StringSubstr(symbol, 3, 3);

   baseIdx  = GetCurrencyIndexFast(base);
   quoteIdx = GetCurrencyIndexFast(quote);
}

bool IsMetal(string symbol)
{
   return (StringFind(symbol, "XAU") >= 0 ||
           StringFind(symbol, "XAG") >= 0);
}

int GetGapPoints(string symbol)
{
   if(StringFind(symbol, "XAU") >= 0) return 1800;
   if(StringFind(symbol, "XAG") >= 0) return 1400;
   return InpGapPoints;
}

double GetStrengthFast(string symbol, ENUM_TIMEFRAMES tf, int atrHandle)
{
   if(atrHandle == INVALID_HANDLE)
      return 0.0;

   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   if(CopyRates(symbol, tf, 1, 1, rates) < 1)
      return 0.0;

   double atrBuf[];
   ArraySetAsSeries(atrBuf, true);
   if(CopyBuffer(atrHandle, 0, 1, 1, atrBuf) < 1)
      return 0.0;

   if(atrBuf[0] <= 0.0)
      return 0.0;

   double raw = (rates[0].close - rates[0].open) / atrBuf[0];
   return MathTanh(raw);
}


double GetATRNormalizedFast(string symbol, int atrHandle, ENUM_TIMEFRAMES tf)
{
   if(atrHandle == INVALID_HANDLE)
      return 1.0;

   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   if(CopyRates(symbol, tf, 1, 1, rates) < 1)
      return 1.0;

   double atrBuf[];
   ArraySetAsSeries(atrBuf, true);
   if(CopyBuffer(atrHandle, 0, 1, 1, atrBuf) < 1)
      return 1.0;

   if(rates[0].close <= 0.0)
      return 1.0;

   double atrPct = atrBuf[0] / rates[0].close;
   double norm   = atrPct * 1000.0;

   return Clamp(norm, 0.5, 2.0);
}




int GetDirectionFromStrengths(double h1, double h4, double m15)
{
   int dir = -1;

   if(h1 > 0.0 && h4 > 0.0)
      dir = ORDER_TYPE_BUY;
   else if(h1 < 0.0 && h4 < 0.0)
      dir = ORDER_TYPE_SELL;
   else
      return -1;

   if(!PassesM15DirectionFilter(dir, m15))
      return -1;

   return dir;
}


bool PassesM15DirectionFilter(int direction, double m15)
{
   if(!InpUseM15Filter)
      return true;

   if(direction == ORDER_TYPE_BUY)
      return (m15 >= InpM15FilterMin);

   if(direction == ORDER_TYPE_SELL)
      return (m15 <= -InpM15FilterMin);

   return false;
}



double GetBullScoreFromStrengths(double m5, double m15, double h1, double h4)
{
   double raw = (m5 * 1.0 + m15 * 1.5 + h1 * 3.5 + h4 * 4.0) / 10.0;
   return (MathTanh(raw) + 1.0) * 5.0;
}
double ToDirectionalScore(double bullScore, int direction)
{
   if(direction == ORDER_TYPE_BUY)  return bullScore;
   if(direction == ORDER_TYPE_SELL) return 10.0 - bullScore;
   return 5.0;
}

double GetATRValue(int atrHandle, int shift = 1)
{
   if(atrHandle == INVALID_HANDLE)
      return 0.0;

   double buf[];
   ArraySetAsSeries(buf, true);

   if(CopyBuffer(atrHandle, 0, shift, 1, buf) < 1)
      return 0.0;

   return buf[0];
}

bool CopySingleBufferValue(const int handle, const int shift, double &value)
{
   value = 0.0;

   if(handle == INVALID_HANDLE)
      return false;

   double buf[];
   ArraySetAsSeries(buf, true);

   if(CopyBuffer(handle, 0, shift, 1, buf) < 1)
      return false;

   value = buf[0];
   return true;
}

bool GetClosedBarClose(const string symbol, ENUM_TIMEFRAMES tf, double &closePrice)
{
   closePrice = 0.0;

   MqlRates rates[];
   ArraySetAsSeries(rates, true);

   if(CopyRates(symbol, tf, 1, 1, rates) < 1)
      return false;

   closePrice = rates[0].close;
   return true;
}
void UpdatePairLocationState(PairData &p)
{
   p.emaM15          = 0.0;
   p.emaH1           = 0.0;
   p.entryStretchM15 = 0.0;
   p.entryStretchH1  = 0.0;
   p.locationOk      = true;

   if(!InpUseLocationFilter)
      return;

   double closeM15 = 0.0;
   double closeH1  = 0.0;
   double emaM15   = 0.0;
   double emaH1    = 0.0;
   double atrM15   = GetATRValue(p.atrM15Handle, 1);
   double atrH1    = GetATRValue(p.atrH1Handle, 1);

   bool okCloseM15 = GetClosedBarClose(p.symbol, PERIOD_M15, closeM15);
   bool okCloseH1  = GetClosedBarClose(p.symbol, PERIOD_H1,  closeH1);
   bool okEmaM15   = CopySingleBufferValue(p.emaM15Handle, 1, emaM15);
   bool okEmaH1    = CopySingleBufferValue(p.emaH1Handle,  1, emaH1);

   if(!okCloseM15 || !okCloseH1 || !okEmaM15 || !okEmaH1 || atrM15 <= 0.0 || atrH1 <= 0.0)
   {
      p.locationOk = false;
      return;
   }

   p.emaM15 = emaM15;
   p.emaH1  = emaH1;

   p.entryStretchM15 = (closeM15 - emaM15) / atrM15;
   p.entryStretchH1  = (closeH1  - emaH1 ) / atrH1;

   if(p.direction == ORDER_TYPE_BUY)
   {
      if(p.entryStretchM15 > InpMaxEntryStretchM15ATR &&
         p.accel < InpStrongAccelThreshold)
      {
         p.locationOk = false;
         return;
      }
   
      if(p.entryStretchH1 > InpMaxEntryStretchH1ATR &&
         p.accel < InpStrongAccelThreshold)
      {
         p.locationOk = false;
         return;
      }
   }
   else if(p.direction == ORDER_TYPE_SELL)
   {
      if(p.entryStretchM15 < -InpMaxEntryStretchM15ATR &&
         p.accel < InpStrongAccelThreshold)
      {
         p.locationOk = false;
         return;
      }
   
      if(p.entryStretchH1 < -InpMaxEntryStretchH1ATR &&
         p.accel < InpStrongAccelThreshold)
      {
         p.locationOk = false;
         return;
      }
   }
   p.locationOk = true;
}

void UpdateWorstBasketPnLState(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return;

   // BUY basket
   if(Pairs[idx].buyGrid.CountPositions() > 0)
   {
      double pnlBuy = Pairs[idx].buyGrid.GridPnL();

      if(Pairs[idx].buyWorstPnL == 0.0)
         Pairs[idx].buyWorstPnL = pnlBuy;

      Pairs[idx].buyWorstPnL = MathMin(Pairs[idx].buyWorstPnL, pnlBuy);
   }
   else
   {
      Pairs[idx].buyWorstPnL = 0.0;
   }

   // SELL basket
   if(Pairs[idx].sellGrid.CountPositions() > 0)
   {
      double pnlSell = Pairs[idx].sellGrid.GridPnL();

      if(Pairs[idx].sellWorstPnL == 0.0)
         Pairs[idx].sellWorstPnL = pnlSell;

      Pairs[idx].sellWorstPnL = MathMin(Pairs[idx].sellWorstPnL, pnlSell);
   }
   else
   {
      Pairs[idx].sellWorstPnL = 0.0;
   }
}