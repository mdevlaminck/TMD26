//+------------------------------------------------------------------+
//|                                               RiskOffEngine.mqh  |
//+------------------------------------------------------------------+
#ifndef __RISK_OFF_ENGINE_MQH__
#define __RISK_OFF_ENGINE_MQH__
// New file
input group "=== Risk-Off Engine ===";
enum ENUM_RISK_OFF_MODE
{
   RISK_OFF_DISABLED = 0,
   RISK_OFF_BLOCK_NEW = 1,
   RISK_OFF_BLOCK_AND_STOP_EXPANSION = 2,
   RISK_OFF_FULL_PROTECTION = 3
};
input ENUM_RISK_OFF_MODE InpRiskOffMode = RISK_OFF_DISABLED;
input int    InpRiskOffScoreTrigger      = 5;    // Score Trigger
input int    InpRiskOffCooldownSec       = 1800; // Cooldown Seconds
input double InpRiskOffSlopeThreshold    = 0.15;
input double InpRiskOffAccelThreshold    = 0.25;
input int    InpRiskOffMinAlignedPairs   = 10;
input int    InpRiskOffMinJpyPairs       = 3;
input bool   InpRiskOffUseCHF            = true;
input bool   InpRiskOffUseVolatility     = true;
input ENUM_TIMEFRAMES InpRiskOffVolTF    = PERIOD_M5;
input int    InpRiskOffATRPeriod         = 14;
input double InpRiskOffATRSpikeRatio     = 1.50;
input bool   InpRiskOffUseAtrSymbol      = false;
input string InpRiskOffAtrSymbol         = "EURUSD";
input bool   InpRiskOffCloseProfitableGrids = true;
input double InpRiskOffTrendExitMinProfit   = 0.0;
input group "=== Risk-Off Entry Filter ===";
input bool   InpUseRiskOffDirectionalEntryFilter = true;   // Entry only for CHF/JPY pairs
input double InpRiskOffMinAccel                  = 0.08;   // Extra momentum requirement during risk-off
input double InpRiskOffMinComp                   = 0.0;    // Min Comp - 0 = use normal comp filter only
input bool   InpBlockSafeHavenVsSafeHaven        = true;   // Block CHFJPY/JPYCHF during risk-off

class RiskOffEngine
{
private:
   datetime m_lastRiskOffTime;
   int      m_lastScore;
   bool     m_isRiskOff;
   bool     m_isExtremeRiskOff;

public:
   RiskOffEngine()
   {
      m_lastRiskOffTime   = 0;
      m_lastScore         = 0;
      m_isRiskOff         = false;
      m_isExtremeRiskOff  = false;
   }

   void Reset()
   {
      m_lastRiskOffTime   = 0;
      m_lastScore         = 0;
      m_isRiskOff         = false;
      m_isExtremeRiskOff  = false;
   }

   datetime LastRiskOffTime() const { return m_lastRiskOffTime; }
   int      LastScore()       const { return m_lastScore;      }
   bool     IsRiskOff()       const { return m_isRiskOff;      }
   bool     IsExtreme()       const { return m_isExtremeRiskOff; }

   bool InCooldown(const int cooldownSeconds) const
   {
      if(m_lastRiskOffTime <= 0 || cooldownSeconds <= 0)
         return false;

      return (TimeCurrent() - m_lastRiskOffTime < cooldownSeconds);
   }

   bool Update(
      const double &currStrength[],
      const PairData &pairs[],
      const int pairSize,
      const double slopeThr,
      const double accelThr,
      const double minComp,
      const int idxJPY,
      const int idxCHF,
      const int idxAUD,
      const int idxNZD,
      const int idxCAD,
      const bool useCHF,
      const bool useVolatility,
      const double volSpikeRatio,
      const ENUM_TIMEFRAMES volTf,
      const int volAtrPeriod,
      const int minAlignedPairs,
      const int minJpyBearishPairs,
      const bool useSymbolAtrReference,
      const string atrSymbol,
      const int scoreTrigger
   )
   {
      int score = 0;

      double jpy = currStrength[idxJPY];
      double chf = currStrength[idxCHF];
      double aud = currStrength[idxAUD];
      double nzd = currStrength[idxNZD];
      double cad = currStrength[idxCAD];

      bool riskOffStrength = false;

      if(useCHF)
      {
         riskOffStrength =
            (jpy >  0.6 && chf >  0.4) &&
            (aud < -0.4 && nzd < -0.4);
      }
      else
      {
         riskOffStrength =
            (jpy >  0.6) &&
            (aud < -0.4 && nzd < -0.4);
      }

      if(cad < -0.4)
         riskOffStrength = riskOffStrength || (jpy > 0.6 && aud < -0.4 && nzd < -0.4 && cad < -0.4);

      if(riskOffStrength)
         score += 2;

      double slopeCutoff = 5.0 - (slopeThr * 5.0);
      int jpyBearishCount = 0;

      for(int i = 0; i < pairSize; i++)
      {
         string sym = pairs[i].symbol;
         if(sym == "")
            continue;

         string quote = StringSubstr(sym, 3, 3);

         if(quote == "JPY" && pairs[i].slope <= slopeCutoff)
            jpyBearishCount++;
      }

      bool jpyFlow = (jpyBearishCount >= minJpyBearishPairs);
      if(jpyFlow)
         score += 2;

      int alignedPairs = 0;
      for(int i = 0; i < pairSize; i++)
      {
         if(!pairs[i].aligned)
            continue;

         if(MathAbs(pairs[i].comp) >= minComp)
            alignedPairs++;
      }

      bool marketAligned = (alignedPairs >= minAlignedPairs);
      if(marketAligned)
         score += 1;

      double accelDistanceCutoff = accelThr * 5.0;
      int accelShockCount = 0;
      for(int i = 0; i < pairSize; i++)
      {
         if(MathAbs(pairs[i].accel - 5.0) >= accelDistanceCutoff)
            accelShockCount++;
      }

      bool accelShock = (accelShockCount >= 4);
      if(accelShock)
         score += 1;

      bool volSpike = false;

      if(useVolatility)
      {
         string refSymbol = useSymbolAtrReference ? atrSymbol : _Symbol;
         if(refSymbol == "")
            refSymbol = _Symbol;

         int atrHandle = iATR(refSymbol, volTf, volAtrPeriod);
         if(atrHandle != INVALID_HANDLE)
         {
            double atrBuf[];
            ArrayResize(atrBuf, 25);

            int copied = CopyBuffer(atrHandle, 0, 0, 25, atrBuf);
            if(copied >= 21)
            {
               double atrNow  = atrBuf[0];
               double atrPast = atrBuf[20];

               if(atrPast > 0.0 && atrNow >= atrPast * volSpikeRatio)
                  volSpike = true;
            }

            IndicatorRelease(atrHandle);
         }
      }

      if(volSpike)
         score += 1;

      int trigger = scoreTrigger;
      if(trigger < 1)
         trigger = 1;

      m_lastScore        = score;
      m_isRiskOff        = (score >= trigger);
      m_isExtremeRiskOff = (score >= trigger + 2);

      if(m_isRiskOff)
         m_lastRiskOffTime = TimeCurrent();

      return m_isRiskOff;
   }
};

void UpdateRiskOffState()
{
   if(InpRiskOffMode == RISK_OFF_DISABLED)
   {
      gRiskOffActive   = false;
      gRiskOffCooldown = false;
      return;
   }

   gRiskOffActive = gRiskOff.Update(
      currencyStrength,
      Pairs,
      PairSize,
      InpRiskOffSlopeThreshold,
      InpRiskOffAccelThreshold,
      InpMinScore,
      3, // JPY
      4, // CHF
      5, // AUD
      6, // NZD
      7, // CAD
      InpRiskOffUseCHF,
      InpRiskOffUseVolatility,
      InpRiskOffATRSpikeRatio,
      InpRiskOffVolTF,
      InpRiskOffATRPeriod,
      InpRiskOffMinAlignedPairs,
      InpRiskOffMinJpyPairs,
      InpRiskOffUseAtrSymbol,
      InpRiskOffAtrSymbol,
      InpRiskOffScoreTrigger
   );

   gRiskOffCooldown = gRiskOff.InCooldown(InpRiskOffCooldownSec);
}

bool IsRiskOffBlockingNewEntries()
{
   if(InpRiskOffMode == RISK_OFF_DISABLED)
      return false;

   return (gRiskOffActive || gRiskOffCooldown);
}

bool IsRiskOffBlockingExpansion()
{
   if(InpRiskOffMode < RISK_OFF_BLOCK_AND_STOP_EXPANSION)
      return false;

   return (gRiskOffActive || gRiskOffCooldown);
}

void ApplyRiskOffProtection()
{
   if(InpRiskOffMode != RISK_OFF_FULL_PROTECTION)
      return;

   if(!gRiskOffActive)
      return;

   if(!InpRiskOffCloseProfitableGrids)
      return;

   for(int i = 0; i < PairSize; i++)
   {
      if(Pairs[i].buyGrid.CountPositions() > 0)
      {
         double pnlBuy = Pairs[i].buyGrid.GridPnL();
         if(pnlBuy >= InpRiskOffTrendExitMinProfit)
            Pairs[i].buyGrid.CloseGrid();
      }

      if(Pairs[i].sellGrid.CountPositions() > 0)
      {
         double pnlSell = Pairs[i].sellGrid.GridPnL();
         if(pnlSell >= InpRiskOffTrendExitMinProfit)
            Pairs[i].sellGrid.CloseGrid();
      }
   }
}


//+------------------------------------------------------------------+
//| Safe-haven currency helpers                                      |
//+------------------------------------------------------------------+


bool RP_IsSafeHavenCurrency(const string ccy)
{
   return (ccy == "JPY" || ccy == "CHF");
}

string RP_GetBaseCurrency(const string symbol)
{
   if(StringLen(symbol) < 6)
      return "";

   return StringSubstr(symbol, 0, 3);
}

string RP_GetQuoteCurrency(const string symbol)
{
   if(StringLen(symbol) < 6)
      return "";

   return StringSubstr(symbol, 3, 3);
}
//+------------------------------------------------------------------+
//| During risk-off, only allow entries that BUY JPY or CHF          |
//| BUY base  => ORDER_TYPE_BUY                                      |
//| BUY quote => ORDER_TYPE_SELL                                     |
//+------------------------------------------------------------------+
bool RP_IsCorrectRiskOffSafeHavenDirection(const string symbol,
                                           const int direction,
                                           const bool blockSafeHavenVsSafeHaven = true)
{
   string base  = RP_GetBaseCurrency(symbol);
   string quote = RP_GetQuoteCurrency(symbol);

   if(base == "" || quote == "")
      return false;

   // Not a CHF/JPY related pair -> no restriction from this rule
   if(!RP_IsSafeHavenCurrency(base) && !RP_IsSafeHavenCurrency(quote))
      return true;

   // Block CHFJPY/JPYCHF if desired
   if(blockSafeHavenVsSafeHaven && RP_IsSafeHavenVsSafeHavenPair(symbol))
      return false;

   // Safe haven on base -> must BUY
   if(RP_IsSafeHavenCurrency(base))
      return (direction == ORDER_TYPE_BUY);

   // Safe haven on quote -> must SELL
   if(RP_IsSafeHavenCurrency(quote))
      return (direction == ORDER_TYPE_SELL);

   return true;
}
//+------------------------------------------------------------------+
//| Extra entry filter for CHF/JPY pairs during risk-off             |
//+------------------------------------------------------------------+
bool RP_PassRiskOffDirectionalEntryFilter(const PairData &pair,
                                          const bool riskOffActive,
                                          const bool useFilter,
                                          const double minAccel,
                                          const double minComp,
                                          const bool blockSafeHavenVsSafeHaven,
                                          string &reason)
{
   reason = "";

   if(!useFilter)
      return true;

   if(!riskOffActive)
      return true;

   // Only applies to CHF / JPY related pairs
   if(!RP_IsJPYOrCHFPair(pair.symbol))
      return true;

   // Direction must buy the safe haven
   if(!RP_IsCorrectRiskOffSafeHavenDirection(pair.symbol,
                                             pair.direction,
                                             blockSafeHavenVsSafeHaven))
   {
      reason = "RiskOff dir blocked";
      return false;
   }

   // Stronger momentum requirement during risk-off
   if(MathAbs(pair.accel - 5.0) < minAccel)
   {
      reason = "RiskOff accel low";
      return false;
   }

   // Optional stronger comp requirement during risk-off
   if(minComp > 0.0 && MathAbs(pair.comp) < minComp)
   {
      reason = "RiskOff comp low";
      return false;
   }

   return true;
}
string RP_GetRiskOffEntryRuleText(const PairData &pair, const bool riskOffActive)
{
   if(!riskOffActive)
      return "";

   if(!RP_IsJPYOrCHFPair(pair.symbol))
      return "";

   if(RP_IsSafeHavenVsSafeHavenPair(pair.symbol))
      return "SAFEHAVENx2";

   if(!RP_IsCorrectRiskOffSafeHavenDirection(pair.symbol, pair.direction, false))
      return "wrong RiskOff dir";

   return "RiskOff dir ok";
}
bool RP_IsJPYOrCHFPair(const string symbol)
{
   string base  = RP_GetBaseCurrency(symbol);
   string quote = RP_GetQuoteCurrency(symbol);

   return (RP_IsSafeHavenCurrency(base) || RP_IsSafeHavenCurrency(quote));
}

bool RP_IsSafeHavenVsSafeHavenPair(const string symbol)
{
   string base  = RP_GetBaseCurrency(symbol);
   string quote = RP_GetQuoteCurrency(symbol);

   return (RP_IsSafeHavenCurrency(base) && RP_IsSafeHavenCurrency(quote));
}




bool IsSelectiveRiskOffEntryModeActive()
{
   if(!InpUseRiskOffDirectionalEntryFilter)
      return false;

   if(InpRiskOffMode == RISK_OFF_DISABLED)
      return false;

   return (gRiskOffActive || gRiskOffCooldown);
}

#endif
