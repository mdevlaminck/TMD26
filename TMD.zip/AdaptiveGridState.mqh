//+------------------------------------------------------------------+
//|                                            AdaptiveGridState.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
// Responsibility:
// - Aggregate hard damage, soft damage, volatility, and risk regime
// - Classify pair into NORMAL / CAUTION / STRESS / BLOCK
// - Drive policy-level entry blocking and expansion brake factors
// This module does NOT own raw invalidation detection.
#property copyright "MDV"
#property link      "https://www.mql5.com"

input group "=== Adaptive Grid Engine ===";
input ENUM_ONOFF InpUseAdaptiveGridEngine     = OFF;

// Regime triggers
input bool       InpAdaptiveUseHighVol        = true;
input bool       InpAdaptiveUseRiskOff        = true;
input bool       InpAdaptiveUseSoftThrottle   = true;

// Entry policy
input bool       InpAdaptiveBlockEntriesAtStress = false;
input bool       InpAdaptiveBlockEntriesAtBlock  = true;
input double     InpAdaptiveStressMinComp        = 7.4;   

// Gap adaptation
input double     InpAdaptiveGapFactorCaution  = 1.15;
input double     InpAdaptiveGapFactorStress   = 1.35;
input double     InpAdaptiveGapFactorBlock    = 1.60;

input bool       InpAdaptiveUseMarketRegime     = true;
input bool       InpAdaptiveUseExpansionRegime  = true;
input bool       InpAdaptiveUseTrendRegime      = true;
input group "=== Adaptive Base Gap ===";
input bool       InpUseAdaptiveBaseGap          = true;
input double     InpGapATRFactorFX              = 0.90;
input double     InpGapATRFactorXAU             = 1.10;
input double     InpGapATRFactorXAG             = 1.00;
input int        InpMinGapPointsFX              = 120;
input int        InpMaxGapPointsFX              = 600;
input int        InpMinGapPointsXAU             = 900;
input int        InpMaxGapPointsXAU             = 4000;
input int        InpMinGapPointsXAG             = 700;
input int        InpMaxGapPointsXAG             = 3000;
input double     InpRegimeGapAddExpansion       = 0.15;
input double     InpRegimeGapAddRiskOff         = 0.10;


double GetAdaptiveGapRegimeFactor(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 1.0;

   double factor = 1.0;

   switch(Pairs[idx].adaptiveState)
   {
      case AGS_CAUTION: factor = InpAdaptiveGapFactorCaution; break;
      case AGS_STRESS:  factor = InpAdaptiveGapFactorStress;  break;
      case AGS_BLOCK:   factor = InpAdaptiveGapFactorBlock;   break;
      default:          factor = 1.0;                         break;
   }

   if(Pairs[idx].regime == REGIME_EXPANSION)
      factor += InpRegimeGapAddExpansion;

   if(Pairs[idx].regime == REGIME_RISK_OFF)
      factor += InpRegimeGapAddRiskOff;

   if(factor < 1.0)
      factor = 1.0;

   if(factor > 2.20)
      factor = 2.20;

   return factor;
}

int GetAdaptiveBaseGapPoints(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return InpGapPoints;

   string symbol = Pairs[idx].symbol;

   if(!InpUseAdaptiveBaseGap)
      return GetGapPoints(symbol);

   double atrM15 = GetATRValue(Pairs[idx].atrM15Handle, 1);
   if(atrM15 <= 0.0)
      return GetGapPoints(symbol);

   int atrPoints = (int)MathRound(ATRToPoints(symbol, atrM15));
   if(atrPoints <= 0)
      return GetGapPoints(symbol);

   int gapPoints = GetGapPoints(symbol);

   if(StringFind(symbol, "XAU") >= 0)
   {
      gapPoints = (int)MathRound((double)atrPoints * InpGapATRFactorXAU);
      gapPoints = (int)Clamp((double)gapPoints, (double)InpMinGapPointsXAU, (double)InpMaxGapPointsXAU);
      return gapPoints;
   }

   if(StringFind(symbol, "XAG") >= 0)
   {
      gapPoints = (int)MathRound((double)atrPoints * InpGapATRFactorXAG);
      gapPoints = (int)Clamp((double)gapPoints, (double)InpMinGapPointsXAG, (double)InpMaxGapPointsXAG);
      return gapPoints;
   }

   gapPoints = (int)MathRound((double)atrPoints * InpGapATRFactorFX);
   gapPoints = (int)Clamp((double)gapPoints, (double)InpMinGapPointsFX, (double)InpMaxGapPointsFX);
   return gapPoints;
}

int GetLiveGapPoints(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return InpGapPoints;

   int baseGap = GetAdaptiveBaseGapPoints(idx);

   double regimeFactor = GetAdaptiveGapRegimeFactor(idx, isBuyGrid);
   int liveGap = (int)MathRound((double)baseGap * regimeFactor);

   if(liveGap < baseGap)
      liveGap = baseGap;

   return liveGap;
}

int GetAdaptiveStressScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   int score = 0;

   if(InpAdaptiveUseHighVol && Pairs[idx].highVolatility)
      score += 1;

   if(InpAdaptiveUseRiskOff && (gRiskOffActive || gRiskOffCooldown))
      score += 1;

   if(InpAdaptiveUseSoftThrottle)
   {
      if(Pairs[idx].buySoftThrottle || Pairs[idx].sellSoftThrottle)
         score += 1;
   }

   if(Pairs[idx].direction == -1)
      score += 1;

   if(!Pairs[idx].aligned)
      score += 1;

   if(InpAdaptiveUseMarketRegime)
   {
      if(InpAdaptiveUseExpansionRegime && Pairs[idx].regime == REGIME_EXPANSION)
         score += 2;

      if(InpAdaptiveUseTrendRegime && Pairs[idx].regime == REGIME_RISK_OFF)
         score += 1;
   }

   return score;
}

AdaptiveGridState GetAdaptiveStateForPair(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return AGS_NORMAL;

   int score = GetAdaptiveStressScore(idx);

   if(score >= 4)
      return AGS_BLOCK;

   if(score >= 3)
      return AGS_STRESS;

   if(score >= 1)
      return AGS_CAUTION;

   return AGS_NORMAL;
}
void UpdateAdaptiveGridState()
{
   if(!InpUseAdaptiveGridEngine)
   {
      for(int i = 0; i < PairSize; i++)
      {
         Pairs[i].adaptiveState      = AGS_NORMAL;
         Pairs[i].adaptiveBlockEntry = false;
      }
      return;
   }

   for(int i = 0; i < PairSize; i++)
   {
      AdaptiveGridState st = GetAdaptiveStateForPair(i);

      Pairs[i].adaptiveState = st;
      Pairs[i].adaptiveBlockEntry = false;

      switch(st)
      {
         case AGS_CAUTION:
            break;

         case AGS_STRESS:
            Pairs[i].adaptiveBlockEntry = InpAdaptiveBlockEntriesAtStress;
            break;

         case AGS_BLOCK:
            Pairs[i].adaptiveBlockEntry = InpAdaptiveBlockEntriesAtBlock;
            break;

         default:
            break;
      }
   }
}
bool IsAdaptiveEntryBlocked(const int idx, string &reason)
{
   reason = "";

   if(!InpUseAdaptiveGridEngine)
      return false;

   if(idx < 0 || idx >= PairSize)
   {
      reason = "AD IDX";
      return true;
   }

   if(!Pairs[idx].adaptiveBlockEntry)
      return false;

   // In stress mode, allow only top quality setups if configured
   if(Pairs[idx].adaptiveState == AGS_STRESS)
   {
      if(Pairs[idx].comp >= InpAdaptiveStressMinComp)
         return false;
   }

   reason = (Pairs[idx].adaptiveState == AGS_BLOCK ? "AD BLOCK" : "AD STR");
   return true;
}


double GetExpansionBrakeFactor(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 1.0;

   double factor = 1.0;

   // Base gap adaptation is handled separately by GetLiveGapPoints().
   // This is only the live add-brake layer.

   BasketDamageState damageState = isBuyGrid ? Pairs[idx].buyDamageState
                                             : Pairs[idx].sellDamageState;

   if(isBuyGrid && Pairs[idx].buySoftThrottle)
      factor += 0.10;

   if(!isBuyGrid && Pairs[idx].sellSoftThrottle)
      factor += 0.10;

   if(Pairs[idx].highVolatility)
      factor += 0.05;

   if(damageState == BDS_DAMAGED)
      factor += 0.15;
   else if(damageState == BDS_CRITICAL)
      factor += 0.35;
   else if(damageState == BDS_EXIT_ONLY)
      factor += 0.60;

   if(factor > 1.75)
      factor = 1.75;

   if(factor < 1.0)
      factor = 1.0;

   return factor;
}


