//+------------------------------------------------------------------+
//|                                                EntryThrottle.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"

input group "=== Entry Throttle ===";
input ENUM_ONOFF InpUseEntryThrottle     = ON;
input int        InpEntryThrottleWindowSec = 900;   // Window Seconds
input int        InpMaxNewEntriesPerWindow = 3;      // Max new baskets per window


datetime gEntryThrottleWindowStart = 0;
int      gEntryThrottleCount       = 0;


void ResetEntryThrottleWindow()
{
   gEntryThrottleWindowStart = 0;
   gEntryThrottleCount       = 0;
}

void UpdateEntryThrottleWindow()
{
   if(InpUseEntryThrottle != ON)
      return;

   datetime now = TimeCurrent();

   if(gEntryThrottleWindowStart <= 0)
   {
      gEntryThrottleWindowStart = now;
      gEntryThrottleCount       = 0;
      return;
   }

   if(InpEntryThrottleWindowSec <= 0)
      return;

   if((now - gEntryThrottleWindowStart) >= InpEntryThrottleWindowSec)
   {
      gEntryThrottleWindowStart = now;
      gEntryThrottleCount       = 0;
   }
}

bool IsEntryThrottleActive()
{
   if(InpUseEntryThrottle != ON)
      return false;

   UpdateEntryThrottleWindow();

   if(InpMaxNewEntriesPerWindow <= 0)
      return false;

   return (gEntryThrottleCount >= InpMaxNewEntriesPerWindow);
}

void RegisterNewBasketEntry()
{
   if(InpUseEntryThrottle != ON)
      return;

   UpdateEntryThrottleWindow();
   gEntryThrottleCount++;
}

