#ifndef __TMD_PORTFOLIO_PRESSURE_MQH__
#define __TMD_PORTFOLIO_PRESSURE_MQH__

enum PortfolioPressureState
{
   PPS_NORMAL  = 0,
   PPS_CAUTION = 1,
   PPS_STRESS  = 2,
   PPS_BLOCK   = 3
};

input group "=== Portfolio Pressure Engine ===";
input ENUM_ONOFF InpUsePortfolioPressure                = OFF;

input double     InpPortPressureCautionDDPct            = 5;
input double     InpPortPressureStressDDPct             = 10;
input double     InpPortPressureBlockDDPct              = 15;

input int        InpPortPressureCautionLiveBaskets      = 8;
input int        InpPortPressureStressLiveBaskets       = 12;
input int        InpPortPressureBlockLiveBaskets        = 18;

input int        InpPortPressureCautionCurrencyCrowd    = 4;
input int        InpPortPressureStressCurrencyCrowd     = 6;
input int        InpPortPressureBlockCurrencyCrowd      = 8;

input int        InpPortPressureCautionDamagedBaskets   = 3;
input int        InpPortPressureStressDamagedBaskets    = 6;
input int        InpPortPressureBlockDamagedBaskets     = 10;

input ENUM_ONOFF InpPortPressureBlockNewAtStress        = OFF;
input ENUM_ONOFF InpPortPressureBlockExpansionAtCaution = OFF;
input ENUM_ONOFF InpPortPressureBlockExpansionAtStress  = OFF;

PortfolioPressureState gPortfolioPressureState = PPS_NORMAL;
string gPortfolioPressureText   = "NORMAL";
string gPortfolioPressureReason = "-";
color  gPortfolioPressureColor  = clrSilver;

//+------------------------------------------------------------------+
//| Helpers                                                          |
//+------------------------------------------------------------------+
double GetTotalGridFloatingPnL()
{
   double pnl = 0.0;

   for(int i = 0; i < PairSize; i++)
   {
      pnl += Pairs[i].buyGrid.GridPnL();
      pnl += Pairs[i].sellGrid.GridPnL();
   }

   return pnl;
}

double GetPortfolioGridDDPctBalance()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   double pnl = GetTotalGridFloatingPnL();
   if(pnl >= 0.0)
      return 0.0;

   return MathAbs(pnl) / balance * 100.0;
}

int CountLiveBaskets()
{
   int count = 0;

   for(int i = 0; i < PairSize; i++)
   {
      bool hasBuy  = (Pairs[i].buyGrid.CountPositions()  > 0);
      bool hasSell = (Pairs[i].sellGrid.CountPositions() > 0);

      if(hasBuy || hasSell)
         count++;
   }

   return count;
}

int CountDamagedLiveBaskets()
{
   int count = 0;

   for(int i = 0; i < PairSize; i++)
   {
      bool hasBuy  = (Pairs[i].buyGrid.CountPositions()  > 0);
      bool hasSell = (Pairs[i].sellGrid.CountPositions() > 0);

      if(!hasBuy && !hasSell)
         continue;

      bool damaged = false;

      if(hasBuy)
      {
         if(Pairs[i].buyDamageState >= BDS_DAMAGED ||
            Pairs[i].buySoftThrottle ||
            Pairs[i].buyExpansionFrozenByInvalidation)
         {
            damaged = true;
         }
      }

      if(hasSell)
      {
         if(Pairs[i].sellDamageState >= BDS_DAMAGED ||
            Pairs[i].sellSoftThrottle ||
            Pairs[i].sellExpansionFrozenByInvalidation)
         {
            damaged = true;
         }
      }

      if(damaged)
         count++;
   }

   return count;
}

int GetMaxCurrencyCrowdingAmongLiveBaskets()
{
   int counts[10];
   ArrayInitialize(counts, 0);

   for(int i = 0; i < PairSize; i++)
   {
      bool hasBuy  = (Pairs[i].buyGrid.CountPositions()  > 0);
      bool hasSell = (Pairs[i].sellGrid.CountPositions() > 0);

      if(!hasBuy && !hasSell)
         continue;

      int baseIdx, quoteIdx;
      GetPairCurrencies(Pairs[i].symbol, baseIdx, quoteIdx);

      if(baseIdx >= 0)
         counts[baseIdx]++;

      if(quoteIdx >= 0)
         counts[quoteIdx]++;
   }

   int maxCount = 0;
   for(int i = 0; i < 10; i++)
   {
      if(counts[i] > maxCount)
         maxCount = counts[i];
   }

   return maxCount;
}

color GetPortfolioPressureColor(const PortfolioPressureState st)
{
   if(st == PPS_NORMAL)  return tmdGreen;
   if(st == PPS_CAUTION) return tmdOrange;
   if(st == PPS_STRESS)  return C'255,120,0';
   if(st == PPS_BLOCK)   return tmdRed;
   return tmdSilver;
}

bool IsPortfolioPressureBlockingNewEntries()
{
   if(InpUsePortfolioPressure != ON)
      return false;

   if(gPortfolioPressureState == PPS_BLOCK)
      return true;

   if(gPortfolioPressureState == PPS_STRESS && InpPortPressureBlockNewAtStress == ON)
      return true;

   return false;
}

bool IsPortfolioPressureBlockingExpansion()
{
   if(InpUsePortfolioPressure != ON)
      return false;

   if(gPortfolioPressureState == PPS_BLOCK)
      return true;

   if(gPortfolioPressureState == PPS_STRESS && InpPortPressureBlockExpansionAtStress == ON)
      return true;

   if(gPortfolioPressureState == PPS_CAUTION && InpPortPressureBlockExpansionAtCaution == ON)
      return true;

   return false;
}

//+------------------------------------------------------------------+
//| State evaluation                                                 |
//+------------------------------------------------------------------+
void EvaluatePortfolioPressureState()
{
   gPortfolioPressureState  = PPS_NORMAL;
   gPortfolioPressureText   = "NORMAL";
   gPortfolioPressureReason = "-";
   gPortfolioPressureColor  = tmdGreen;

   if(InpUsePortfolioPressure != ON)
      return;

   double ddPct         = GetPortfolioGridDDPctBalance();
   int    liveBaskets   = CountLiveBaskets();
   int    crowding      = GetMaxCurrencyCrowdingAmongLiveBaskets();
   int    damaged       = CountDamagedLiveBaskets();

   // BLOCK
   if(ddPct >= InpPortPressureBlockDDPct)
   {
      gPortfolioPressureState  = PPS_BLOCK;
      gPortfolioPressureText   = "BLOCK";
      gPortfolioPressureReason = "PORT DD";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(liveBaskets >= InpPortPressureBlockLiveBaskets)
   {
      gPortfolioPressureState  = PPS_BLOCK;
      gPortfolioPressureText   = "BLOCK";
      gPortfolioPressureReason = "PORT LIVE";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(crowding >= InpPortPressureBlockCurrencyCrowd)
   {
      gPortfolioPressureState  = PPS_BLOCK;
      gPortfolioPressureText   = "BLOCK";
      gPortfolioPressureReason = "PORT CROWD";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(damaged >= InpPortPressureBlockDamagedBaskets)
   {
      gPortfolioPressureState  = PPS_BLOCK;
      gPortfolioPressureText   = "BLOCK";
      gPortfolioPressureReason = "PORT DMG";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   // STRESS
   if(ddPct >= InpPortPressureStressDDPct)
   {
      gPortfolioPressureState  = PPS_STRESS;
      gPortfolioPressureText   = "STRESS";
      gPortfolioPressureReason = "PORT DD";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(liveBaskets >= InpPortPressureStressLiveBaskets)
   {
      gPortfolioPressureState  = PPS_STRESS;
      gPortfolioPressureText   = "STRESS";
      gPortfolioPressureReason = "PORT LIVE";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(crowding >= InpPortPressureStressCurrencyCrowd)
   {
      gPortfolioPressureState  = PPS_STRESS;
      gPortfolioPressureText   = "STRESS";
      gPortfolioPressureReason = "PORT CROWD";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(damaged >= InpPortPressureStressDamagedBaskets)
   {
      gPortfolioPressureState  = PPS_STRESS;
      gPortfolioPressureText   = "STRESS";
      gPortfolioPressureReason = "PORT DMG";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   // CAUTION
   if(ddPct >= InpPortPressureCautionDDPct)
   {
      gPortfolioPressureState  = PPS_CAUTION;
      gPortfolioPressureText   = "CAUTION";
      gPortfolioPressureReason = "PORT DD";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(liveBaskets >= InpPortPressureCautionLiveBaskets)
   {
      gPortfolioPressureState  = PPS_CAUTION;
      gPortfolioPressureText   = "CAUTION";
      gPortfolioPressureReason = "PORT LIVE";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(crowding >= InpPortPressureCautionCurrencyCrowd)
   {
      gPortfolioPressureState  = PPS_CAUTION;
      gPortfolioPressureText   = "CAUTION";
      gPortfolioPressureReason = "PORT CROWD";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }

   if(damaged >= InpPortPressureCautionDamagedBaskets)
   {
      gPortfolioPressureState  = PPS_CAUTION;
      gPortfolioPressureText   = "CAUTION";
      gPortfolioPressureReason = "PORT DMG";
      gPortfolioPressureColor  = GetPortfolioPressureColor(gPortfolioPressureState);
      return;
   }
}

double GetPortfolioPressureRiskFactor()
{
   if(!InpUsePortfolioPressure)
      return 1.0;

   if(gPortfolioPressureState == PPS_NORMAL)
      return 1.0;

   if(gPortfolioPressureState == PPS_CAUTION)
      return 0.9;

   if(gPortfolioPressureState == PPS_STRESS)
      return 0.75;

   if(gPortfolioPressureState == PPS_BLOCK)
      return 0.50;

   return 1.0;
}

#endif