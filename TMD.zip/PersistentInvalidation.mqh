//+------------------------------------------------------------------+
//|                                       PersistentInvalidation.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
// Responsibility:
// - Detect persistent structural invalidation
// - Maintain invalid bar counters
// - Freeze grid expansion on persistent invalidation
// - Trigger direct invalidation exits
// This module owns HARD structural damage state.
#property copyright "MDV"
#property link      "https://www.mql5.com"

input group "=== Persistent Invalidation Exit ===";
input ENUM_ONOFF InpUsePersistentInvalidationExit   = OFF;
input int        InpInvalidBarsToFreezeExpansion    = 15;        
input double     InpInvalidExitMaxLossPctBalance    = 0.1;   
input bool       InpInvalidUseOppositeDirection     = true;
input bool       InpInvalidUseOppositeH4            = true;
input bool       InpInvalidUseCurrencyFlip          = true;
input bool       InpInvalidUseHighVol               = false;
input group "=== Persistent Invalidation Direct Exit ===";
input ENUM_ONOFF InpUsePersistentInvalidationDirectExit = ON;
input int        InpPIExitBars               = 10;     // InpPIExitBars - invalid bars needed for direct exit
input int        InpPIExitMinPositions       = 3;      // InpPIExitMinPositions - do not cut very small baskets
input double     InpPIExitMinAgeDays         = 0.25;   // InpPIExitMinAgeDays - about 6 hours
input double     InpPIExitMaxLossPctBalance  = 0.45;   // InpPIExitMaxLossPctBalance - only exit while loss remains manageable

int GetBuyBasketInvalidationScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   int score = 0;

   if(InpInvalidUseOppositeDirection && Pairs[idx].direction == ORDER_TYPE_SELL)
      score += 2;

   if(InpInvalidUseOppositeH4 && Pairs[idx].trendH4 == DOWNTREND)
      score += 1;

   if(InpInvalidUseCurrencyFlip && Pairs[idx].baseStrength <= Pairs[idx].quoteStrength)
      score += 1;

   if(InpInvalidUseHighVol && Pairs[idx].highVolatility)
      score += 1;

   return score;
}

int GetSellBasketInvalidationScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   int score = 0;

   if(InpInvalidUseOppositeDirection && Pairs[idx].direction == ORDER_TYPE_BUY)
      score += 2;

   if(InpInvalidUseOppositeH4 && Pairs[idx].trendH4 == UPTREND)
      score += 1;

   if(InpInvalidUseCurrencyFlip && Pairs[idx].quoteStrength <= Pairs[idx].baseStrength)
      score += 1;

   if(InpInvalidUseHighVol && Pairs[idx].highVolatility)
      score += 1;

   return score;
}

void UpdatePersistentInvalidationState()
{
   if(!InpUsePersistentInvalidationExit)
      return;

   int freezeBars = MathMax(1, InpInvalidBarsToFreezeExpansion);

   for(int i = 0; i < PairSize; i++)
   {
      // BUY basket
      if(Pairs[i].buyGrid.CountPositions() > 0)
      {
         int score = GetBuyBasketInvalidationScore(i);

         if(score >= 3)
            Pairs[i].buyInvalidBars++;
         else if(Pairs[i].buyInvalidBars > 0)
            Pairs[i].buyInvalidBars--;

         Pairs[i].buyExpansionFrozenByInvalidation = (Pairs[i].buyInvalidBars >= freezeBars);
      }
      else
      {
         Pairs[i].buyInvalidBars = 0;
         Pairs[i].buyExpansionFrozenByInvalidation = false;
      }

      // SELL basket
      if(Pairs[i].sellGrid.CountPositions() > 0)
      {
         int score = GetSellBasketInvalidationScore(i);

         if(score >= 3)
            Pairs[i].sellInvalidBars++;
         else if(Pairs[i].sellInvalidBars > 0)
            Pairs[i].sellInvalidBars--;

         Pairs[i].sellExpansionFrozenByInvalidation = (Pairs[i].sellInvalidBars >= freezeBars);
      }
      else
      {
         Pairs[i].sellInvalidBars = 0;
         Pairs[i].sellExpansionFrozenByInvalidation = false;
      }
   }
}




double GetPersistentInvalidationDirectExitMaxLossMoney()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   return balance * InpPIExitMaxLossPctBalance / 100.0;
}

bool ShouldExitBuyOnPersistentInvalidationDirect(const int idx,
                                                 const double pnl,
                                                 double &ageDays,
                                                 double &maxLossMoney,
                                                 int &invalidBars,
                                                 int &invalidScore,
                                                 string &reason)
{
   ageDays      = 0.0;
   maxLossMoney = 0.0;
   invalidBars  = 0;
   invalidScore = 0;
   reason       = "";

   if(InpUsePersistentInvalidationDirectExit != ON)
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].buyGrid.CountPositions() <= 0)
      return false;

   if(pnl >= 0.0)
      return false;

   if(Pairs[idx].buyGrid.CountPositions() < MathMax(1, InpPIExitMinPositions))
      return false;

   ageDays = GetGridAgeDays(idx, true);
   if(ageDays < InpPIExitMinAgeDays)
      return false;

   invalidBars = Pairs[idx].buyInvalidBars;
   if(invalidBars < MathMax(1, InpPIExitBars))
      return false;

   invalidScore = GetBuyBasketInvalidationScore(idx);

   // Require invalidation to still be structurally present now
   if(invalidScore < 2)
      return false;

   maxLossMoney = GetPersistentInvalidationDirectExitMaxLossMoney();
   if(maxLossMoney > 0.0 && MathAbs(pnl) > maxLossMoney)
      return false;

   reason = "PI DIRECT BUY";
   return true;
}

bool ShouldExitSellOnPersistentInvalidationDirect(const int idx,
                                                  const double pnl,
                                                  double &ageDays,
                                                  double &maxLossMoney,
                                                  int &invalidBars,
                                                  int &invalidScore,
                                                  string &reason)
{
   ageDays      = 0.0;
   maxLossMoney = 0.0;
   invalidBars  = 0;
   invalidScore = 0;
   reason       = "";

   if(InpUsePersistentInvalidationDirectExit != ON)
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].sellGrid.CountPositions() <= 0)
      return false;

   if(pnl >= 0.0)
      return false;

   if(Pairs[idx].sellGrid.CountPositions() < MathMax(1, InpPIExitMinPositions))
      return false;

   ageDays = GetGridAgeDays(idx, false);
   if(ageDays < InpPIExitMinAgeDays)
      return false;

   invalidBars = Pairs[idx].sellInvalidBars;
   if(invalidBars < MathMax(1, InpPIExitBars))
      return false;

   invalidScore = GetSellBasketInvalidationScore(idx);

   if(invalidScore < 2)
      return false;

   maxLossMoney = GetPersistentInvalidationDirectExitMaxLossMoney();
   if(maxLossMoney > 0.0 && MathAbs(pnl) > maxLossMoney)
      return false;

   reason = "PI DIRECT SELL";
   return true;
}


