﻿#ifndef __TMD_ENTRY_EXIT_MQH__
#define __TMD_ENTRY_EXIT_MQH__

input group "=== Filter Settings ===";
input double InpMinScore = 6.2;
input double InpBuyRsi = 35;
input double InpSellRsi = 65;
input ENUM_ONOFF InpUseBB = OFF;
input ENUM_ONOFF InpUseM15Filter = OFF;
input double InpM15FilterMin = 0.15;
input double InpMinAccel = 4.5;
input double InpMaxAccel = 9.95;
input double InpMinPB = 2.0;
input double InpMinSl = 5.5;
input double InpMinReg = 7.5;
input group "=== Trail Settings ===";
input bool   InpUseBasketTrailAfterTP      = true;
input double InpBasketTrailArmFactor       = 1.20;   // Arm when pnl >= TP * factor
input double InpBasketTrailRetracePctFX    = 35.0;   // Close if pnl retraces this % from peak
input double InpBasketTrailRetracePctXAU   = 45.0;
input double InpBasketTrailRetracePctXAG   = 50.0;
input double InpTrailMinSlope              = 5.3;
input double InpTrailMinAccel              = 5.1;
input bool   InpCloseTrailOnTrendFlip      = true;
input group "=== Early Kill Exit ===";
input ENUM_ONOFF InpUseEarlyKillExit        = ON;
input int        InpEarlyKillBars           = 8;      // Early Kill Min Bars
input int        InpEarlyKillMinPositions   = 3;      // Early Kill Min Positions
input double     InpEarlyKillMinAgeDays     = 0.20;   // Early Kill Min Age Days
input double     InpEarlyKillMaxLossPctBal  = 0.35;   // Early Kill Max Loss Pct
input double     InpEarlyKillMinLossPctBal  = 0.03;   // Early Kill Min Loss Pct
input double InpEarlyKillMaxCurrencyScore = 2.5;     // Early Kill Max Currency Score
input int    InpEarlyKillHardMinPositions = 4;      // Only for baskets that have grown enough
input double InpEarlyKillHardMaxLossPctBal = 0.60;  // Still only cut if loss remains manageable
input double InpEarlyKillRecoveryMinAgeDays   = 1;   
input int    InpEarlyKillRecoveryMinPositions = 4;      
input double InpEarlyKillMinRecoveryPct       = 0.20;   
input double InpEarlyKillRecoveryMaxLossPctBal = 0.60;  
input double InpEarlyKillWorstLossMinPctBal    = 0.15;
input group "=== Time-Based Grid Exit ===";
input ENUM_ONOFF InpUseTimeExit               = ON;
input double     InpGridTimeExitStartDays     = 7.0;   // Start monitoring aged grids after X days
input double     InpGridTimeExitProfitDays    = 7.0;   // For this many extra days: exit only if >= 0 profit
input double     InpGridTimeExitStepDays      = 4.0;   // After profit-only phase, increase accepted loss every X days
input double     InpGridTimeExitLossStepPct   = 0.25;  // Accepted loss step as % of balance
input double     InpGridTimeExitMaxLossPct    = 1.50;  // Max accepted loss cap as % of balance  

void CheckExit()
{
   ApplyRiskOffProtection();

   double minExitProfit = GetDynamicTrendExitMinProfit();

   for(int i = 0; i < PairSize; i++)
   {
      //==============================================================
      // BUY GRID
      //==============================================================
      if(Pairs[i].buyGrid.CountPositions() > 0)
      {
         double pnl           = Pairs[i].buyGrid.GridPnL();
         
         
         if(IsBasketHardStopHit(i, true))
         {
            Print("BASKET HARD STOP BUY: ", Pairs[i].symbol,
                  " | LossPctBal: ", DoubleToString(GetBasketLossPctBalance(i, true), 2),
                  " | Limit: ", DoubleToString(InpBasketHardStopPctBal, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | Orders: ", IntegerToString(Pairs[i].buyGrid.CountPositions()));

            Pairs[i].buyGrid.CloseGrid();
            continue;
         }
         double ageDays       = 0.0;
         double timeThreshold = 0.0;
         string timeReason    = "";

         bool trendInvalid    = IsBuyTrendInvalidated(i);
         bool trailValid      = IsTrailContinuationValid(i, true);
         double targetMoney   = GetGridProfitTargetMoney(i, true);

         //--- A) Basket trailing after TP
         if(InpUseBasketTrailAfterTP && targetMoney > 0.0)
         {
            if(!Pairs[i].buyGrid.IsBasketTrailActive())
            {
               // First time target is reached
               if(pnl >= targetMoney)
               {
                  // If continuation still looks strong, arm trailing
                  if(trailValid && pnl >= targetMoney * InpBasketTrailArmFactor)
                  {
                     Pairs[i].buyGrid.ArmBasketTrail(pnl);

                     Print("ARM BUY TRAIL: ", Pairs[i].symbol,
                           " | GridPnL: ", DoubleToString(pnl, 2),
                           " | Target: ", DoubleToString(targetMoney, 2),
                           " | Slope: ", DoubleToString(Pairs[i].slope, 2),
                           " | Acc: ", DoubleToString(Pairs[i].accel, 2));
                  }
                  else
                  {
                     // Trend no longer strong enough -> take profit now
                     Print("EXIT BUY GRID [TP HIT, NO TRAIL]: ", Pairs[i].symbol,
                           " | GridPnL: ", DoubleToString(pnl, 2),
                           " | Target: ", DoubleToString(targetMoney, 2),
                           " | TrailValid: ", (trailValid ? "YES" : "NO"),
                           " | Slope: ", DoubleToString(Pairs[i].slope, 2),
                           " | Acc: ", DoubleToString(Pairs[i].accel, 2));

                     Pairs[i].buyGrid.CloseGrid();
                     continue;
                  }
               }
            }
            else
            {
               // Trailing already active
               Pairs[i].buyGrid.UpdateBasketTrailPeak(pnl);

               double peak        = Pairs[i].buyGrid.BasketTrailPeakPnL();
               double retracePct  = GetBasketTrailRetracePct(Pairs[i].symbol);
               double retraceCash = peak * retracePct / 100.0;
               double trailFloor  = peak - retraceCash;

               bool trendFlip = (InpCloseTrailOnTrendFlip && !trailValid);

               if(trendFlip || pnl <= trailFloor)
               {
                  string exitWhy = trendFlip ? "TRAIL TREND FLIP" : "TRAIL RETRACE";

                  Print("EXIT BUY GRID [", exitWhy, "]: ", Pairs[i].symbol,
                        " | GridPnL: ", DoubleToString(pnl, 2),
                        " | Peak: ", DoubleToString(peak, 2),
                        " | Floor: ", DoubleToString(trailFloor, 2),
                        " | RetracePct: ", DoubleToString(retracePct, 1),
                        " | Slope: ", DoubleToString(Pairs[i].slope, 2),
                        " | Acc: ", DoubleToString(Pairs[i].accel, 2));

                  Pairs[i].buyGrid.CloseGrid();
                  continue;
               }
            }
         }
         else
         {
            //--- B) Normal TP handling when basket trailing is disabled
            if(targetMoney > 0.0 && pnl >= targetMoney)
            {
               Print("EXIT BUY GRID [TP]: ", Pairs[i].symbol,
                     " | GridPnL: ", DoubleToString(pnl, 2),
                     " | Target: ", DoubleToString(targetMoney, 2));

               Pairs[i].buyGrid.CloseGrid();
               continue;
            }
         }

         //--- C) Existing trend-based exit if invalidated and in profit
         if(trendInvalid && pnl > minExitProfit)
         {
            Print("EXIT BUY GRID [TREND INVALID + PROFIT]: ", Pairs[i].symbol,
                  " | Dir: ", DirectionToText(Pairs[i].direction),
                  " | Aligned: ", (Pairs[i].aligned ? "YES" : "NO"),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | Score: ", DoubleToString(Pairs[i].score, 2),
                  " | Cur: ", DoubleToString(Pairs[i].currencyScore, 2));

            Pairs[i].buyGrid.CloseGrid();
            continue;
         }
         
         double killAgeDays   = 0.0;
         double killMinLoss   = 0.0;
         double killMaxLoss   = 0.0;
         string killReason    = "";

         if(ShouldExitBuyEarlyKill(i, pnl, killAgeDays, killMinLoss, killMaxLoss, killReason))
         {
            Print("EXIT BUY GRID [", killReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(killAgeDays, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | InvalidBars: ", IntegerToString(Pairs[i].buyInvalidBars),
                  " | MinLoss: ", DoubleToString(killMinLoss, 2),
                  " | MaxLoss: ", DoubleToString(killMaxLoss, 2),
                  " | Orders: ", IntegerToString(Pairs[i].buyGrid.CountPositions()));

            Pairs[i].buyGrid.CloseGrid();
            continue;
         }
         double recAgeDays    = 0.0;
         double recWorstPnL   = 0.0;
         double recRatio      = 0.0;
         double recMaxLoss    = 0.0;
         string recReason     = "";

         if(ShouldExitBuyRecoveryKill(i, pnl, recAgeDays, recWorstPnL, recRatio, recMaxLoss, recReason))
         {
            Print("EXIT BUY GRID [", recReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(recAgeDays, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | WorstPnL: ", DoubleToString(recWorstPnL, 2),
                  " | RecoveryRatio: ", DoubleToString(recRatio, 2),
                  " | MaxLoss: ", DoubleToString(recMaxLoss, 2),
                  " | Orders: ", IntegerToString(Pairs[i].buyGrid.CountPositions()));

            Pairs[i].buyGrid.CloseGrid();
            continue;
         }
         
         double piAgeDays    = 0.0;
         double piMaxLoss    = 0.0;
         int    piInvalidBars = 0;
         int    piInvalidScore = 0;
         string piReason     = "";

         if(ShouldExitBuyOnPersistentInvalidationDirect(i, pnl, piAgeDays, piMaxLoss, piInvalidBars, piInvalidScore, piReason))
         {
            Print("EXIT BUY GRID [", piReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(piAgeDays, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | InvalidBars: ", IntegerToString(piInvalidBars),
                  " | InvalidScore: ", IntegerToString(piInvalidScore),
                  " | MaxLoss: ", DoubleToString(piMaxLoss, 2),
                  " | Orders: ", IntegerToString(Pairs[i].buyGrid.CountPositions()));

            Pairs[i].buyGrid.CloseGrid();
            continue;
         }
         
         //--- D) Time-based stale-grid exit
         if(ShouldExitGridByTime(i, true, pnl, ageDays, timeThreshold, timeReason))
         {
            Print("EXIT BUY GRID [", timeReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(ageDays, 1),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | Threshold: ", DoubleToString(timeThreshold, 2),
                  " | Orders: ", IntegerToString(Pairs[i].buyGrid.CountPositions()));

            Pairs[i].buyGrid.CloseGrid();
            continue;
         }
      }

      //==============================================================
      // SELL GRID
      //==============================================================
      if(Pairs[i].sellGrid.CountPositions() > 0)
      {
         double pnl           = Pairs[i].sellGrid.GridPnL();
         
         if(IsBasketHardStopHit(i, false))
         {
            Print("BASKET HARD STOP SELL: ", Pairs[i].symbol,
                  " | LossPctBal: ", DoubleToString(GetBasketLossPctBalance(i, false), 2),
                  " | Limit: ", DoubleToString(InpBasketHardStopPctBal, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | Orders: ", IntegerToString(Pairs[i].sellGrid.CountPositions()));

            Pairs[i].sellGrid.CloseGrid();
            continue;
         }
         double ageDays       = 0.0;
         double timeThreshold = 0.0;
         string timeReason    = "";

         bool trendInvalid    = IsSellTrendInvalidated(i);
         bool trailValid      = IsTrailContinuationValid(i, false);
         double targetMoney   = GetGridProfitTargetMoney(i, false);

         //--- A) Basket trailing after TP
         if(InpUseBasketTrailAfterTP && targetMoney > 0.0)
         {
            if(!Pairs[i].sellGrid.IsBasketTrailActive())
            {
               // First time target is reached
               if(pnl >= targetMoney)
               {
                  // If continuation still looks strong, arm trailing
                  if(trailValid && pnl >= targetMoney * InpBasketTrailArmFactor)
                  {
                     Pairs[i].sellGrid.ArmBasketTrail(pnl);

                     Print("ARM SELL TRAIL: ", Pairs[i].symbol,
                           " | GridPnL: ", DoubleToString(pnl, 2),
                           " | Target: ", DoubleToString(targetMoney, 2),
                           " | Slope: ", DoubleToString(Pairs[i].slope, 2),
                           " | Acc: ", DoubleToString(Pairs[i].accel, 2));
                  }
                  else
                  {
                     // Trend no longer strong enough -> take profit now
                     Print("EXIT SELL GRID [TP HIT, NO TRAIL]: ", Pairs[i].symbol,
                           " | GridPnL: ", DoubleToString(pnl, 2),
                           " | Target: ", DoubleToString(targetMoney, 2),
                           " | TrailValid: ", (trailValid ? "YES" : "NO"),
                           " | Slope: ", DoubleToString(Pairs[i].slope, 2),
                           " | Acc: ", DoubleToString(Pairs[i].accel, 2));

                     Pairs[i].sellGrid.CloseGrid();
                     continue;
                  }
               }
            }
            else
            {
               // Trailing already active
               Pairs[i].sellGrid.UpdateBasketTrailPeak(pnl);

               double peak        = Pairs[i].sellGrid.BasketTrailPeakPnL();
               double retracePct  = GetBasketTrailRetracePct(Pairs[i].symbol);
               double retraceCash = peak * retracePct / 100.0;
               double trailFloor  = peak - retraceCash;

               bool trendFlip = (InpCloseTrailOnTrendFlip && !trailValid);

               if(trendFlip || pnl <= trailFloor)
               {
                  string exitWhy = trendFlip ? "TRAIL TREND FLIP" : "TRAIL RETRACE";

                  Print("EXIT SELL GRID [", exitWhy, "]: ", Pairs[i].symbol,
                        " | GridPnL: ", DoubleToString(pnl, 2),
                        " | Peak: ", DoubleToString(peak, 2),
                        " | Floor: ", DoubleToString(trailFloor, 2),
                        " | RetracePct: ", DoubleToString(retracePct, 1),
                        " | Slope: ", DoubleToString(Pairs[i].slope, 2),
                        " | Acc: ", DoubleToString(Pairs[i].accel, 2));

                  Pairs[i].sellGrid.CloseGrid();
                  continue;
               }
            }
         }
         else
         {
            //--- B) Normal TP handling when basket trailing is disabled
            if(targetMoney > 0.0 && pnl >= targetMoney)
            {
               Print("EXIT SELL GRID [TP]: ", Pairs[i].symbol,
                     " | GridPnL: ", DoubleToString(pnl, 2),
                     " | Target: ", DoubleToString(targetMoney, 2));

               Pairs[i].sellGrid.CloseGrid();
               continue;
            }
         }

         //--- C) Existing trend-based exit if invalidated and in profit
         if(trendInvalid && pnl > minExitProfit)
         {
            Print("EXIT SELL GRID [TREND INVALID + PROFIT]: ", Pairs[i].symbol,
                  " | Dir: ", DirectionToText(Pairs[i].direction),
                  " | Aligned: ", (Pairs[i].aligned ? "YES" : "NO"),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | Score: ", DoubleToString(Pairs[i].score, 2),
                  " | Cur: ", DoubleToString(Pairs[i].currencyScore, 2));

            Pairs[i].sellGrid.CloseGrid();
            continue;
         }
         double killAgeDays   = 0.0;
         double killMinLoss   = 0.0;
         double killMaxLoss   = 0.0;
         string killReason    = "";

         if(ShouldExitSellEarlyKill(i, pnl, killAgeDays, killMinLoss, killMaxLoss, killReason))
         {
            Print("EXIT SELL GRID [", killReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(killAgeDays, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | InvalidBars: ", IntegerToString(Pairs[i].sellInvalidBars),
                  " | MinLoss: ", DoubleToString(killMinLoss, 2),
                  " | MaxLoss: ", DoubleToString(killMaxLoss, 2),
                  " | Orders: ", IntegerToString(Pairs[i].sellGrid.CountPositions()));

            Pairs[i].sellGrid.CloseGrid();
            continue;
         }
         double recAgeDays    = 0.0;
         double recWorstPnL   = 0.0;
         double recRatio      = 0.0;
         double recMaxLoss    = 0.0;
         string recReason     = "";

         if(ShouldExitSellRecoveryKill(i, pnl, recAgeDays, recWorstPnL, recRatio, recMaxLoss, recReason))
         {
            Print("EXIT SELL GRID [", recReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(recAgeDays, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | WorstPnL: ", DoubleToString(recWorstPnL, 2),
                  " | RecoveryRatio: ", DoubleToString(recRatio, 2),
                  " | MaxLoss: ", DoubleToString(recMaxLoss, 2),
                  " | Orders: ", IntegerToString(Pairs[i].sellGrid.CountPositions()));

            Pairs[i].sellGrid.CloseGrid();
            continue;
         }
         
         double piAgeDays    = 0.0;
         double piMaxLoss    = 0.0;
         int    piInvalidBars = 0;
         int    piInvalidScore = 0;
         string piReason     = "";

         if(ShouldExitSellOnPersistentInvalidationDirect(i, pnl, piAgeDays, piMaxLoss, piInvalidBars, piInvalidScore, piReason))
         {
            Print("EXIT SELL GRID [", piReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(piAgeDays, 2),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | InvalidBars: ", IntegerToString(piInvalidBars),
                  " | InvalidScore: ", IntegerToString(piInvalidScore),
                  " | MaxLoss: ", DoubleToString(piMaxLoss, 2),
                  " | Orders: ", IntegerToString(Pairs[i].sellGrid.CountPositions()));

            Pairs[i].sellGrid.CloseGrid();
            continue;
         }
         
         //--- D) Time-based stale-grid exit
         if(ShouldExitGridByTime(i, false, pnl, ageDays, timeThreshold, timeReason))
         {
            Print("EXIT SELL GRID [", timeReason, "]: ", Pairs[i].symbol,
                  " | AgeDays: ", DoubleToString(ageDays, 1),
                  " | GridPnL: ", DoubleToString(pnl, 2),
                  " | Threshold: ", DoubleToString(timeThreshold, 2),
                  " | Orders: ", IntegerToString(Pairs[i].sellGrid.CountPositions()));

            Pairs[i].sellGrid.CloseGrid();
            continue;
         }
         
                
      }
      

   }
}

void CheckEntry()
{


   if(gEmergencyClose)
      return;

   UpdateEntryThrottleWindow();
   int topPairs[];
   if(InpUseTopPairsFilter)
      GetTopPairs(topPairs);

   for(int i = 0; i < PairSize; i++)
   {
      if(InpUseTopPairsFilter && !IsTopPairSelected(i, topPairs))
      {
    
         if(Pairs[i].waitReason == "")
            Pairs[i].waitReason = "RANK";
         continue;
      }
      if(IsEntryThrottleActive())
      {
       
         if(Pairs[i].waitReason == "")
            Pairs[i].waitReason = "THRTL";
         continue;
      }
      
      string riskReason = "";
      if(!AllowNewRiskEntry(i, riskReason))
      {
       
         if(Pairs[i].waitReason == "")
            Pairs[i].waitReason = riskReason;
         continue;
      }
      
      if(!IsPairEligibleNow(i)) {
      
         continue;
      }
         
      if(IsBlockedByMondayGap(Pairs[i], Pairs[i].direction))
      {
    
         Pairs[i].waitReason = "MON GAP";
         continue;
      }
      if(!HasEntryTrigger(i))
      {
   
         if(Pairs[i].waitReason == "")
            Pairs[i].waitReason = PairFilterText(i);
         continue;
      }

      if(InpUseEdgeScoreEngine)
      {
         Pairs[i].edgeTrigger = GetEdgeTriggerScore(i);
         Pairs[i].edgeScore   = ComputeFinalEdgeScore(i);
      }

      if(!InpUseRankOnlySelection)
      {
         if(InpUseEdgeScoreEngine && Pairs[i].edgeScore < InpMinEdgeScore)
         {
            if(Pairs[i].waitReason == "")
               Pairs[i].waitReason = "EDGE";
            continue;
         }
      }


      if(!SpreadAcceptable(Pairs[i].symbol, InpMaxSpreadPoints))
         continue;

      if(InpUseVolatilityFilter &&
         InpBlockNewEntriesOnHighVol == ON &&
         Pairs[i].highVolatility)
      {
         Print("ENTRY BLOCKED [HIGH VOL]: ", Pairs[i].symbol,
               " | ATR pts: ", DoubleToString(Pairs[i].atrValuePoints, 0));
         continue;
      }

      double baseLot = InpUseAutoLot ? CalculateLotSize(Pairs[i].symbol, InpBalancePerLot) : InpInitialLot;
      double lotSignal = GetLotSizingSignal(i);
      double lotSize   = GetDynamicLotSize(baseLot, lotSignal);
      lotSize *= GetPortfolioPressureRiskFactor();
      lotSize = NormalizeLot(Pairs[i].symbol, lotSize);

      if(Pairs[i].direction == ORDER_TYPE_BUY)
      {
         string regimeReason = "";
         if(IsRegimeBlockingEntry(i, true, regimeReason))
         {
            Print("ENTRY BLOCK BUY ", Pairs[i].symbol, " : ", regimeReason);
            continue;
         }
         
         if(!CanAffordOrder(Pairs[i].symbol, ORDER_TYPE_BUY, lotSize))
            continue;

         Print("TRADE BUY: ", Pairs[i].symbol,
               " | Top: ", (Pairs[i].isTopPair ? "Y" : "N"),
               " | Edge: ", DoubleToString(Pairs[i].edgeScore,2),
               " | Comp: ", DoubleToString(Pairs[i].comp,2),
               " | Mom: ", DoubleToString(Pairs[i].edgeMomentum,2),
               " | PB: ", DoubleToString(Pairs[i].edgePullback,2),
               " | Tr: ", DoubleToString(Pairs[i].edgeTrend,2),
               " | Reg: ", DoubleToString(Pairs[i].edgeRegime,2),
               " | Score: ", DoubleToString(Pairs[i].score,2),
               " | Cur: ", DoubleToString(Pairs[i].currencyScore,2),
               " | Sl: ", DoubleToString(Pairs[i].slope,2),
               " | Ac: ", DoubleToString(Pairs[i].accel,2),
               " | RSI: ", DoubleToString(Pairs[i].rsiM5,1),
               " | Lot: ", DoubleToString(lotSize,2));

         Pairs[i].waitReason = "LIVE";
         Pairs[i].buyGrid.SetLotSize(lotSize);
         Pairs[i].buyGrid.Start();
         RegisterNewBasketEntry();
    
         continue;
      }

      if(Pairs[i].direction == ORDER_TYPE_SELL)
      {
         
         string regimeReason = "";
         if(IsRegimeBlockingEntry(i, false, regimeReason))
         {
            Print("ENTRY BLOCK SELL ", Pairs[i].symbol, " : ", regimeReason);
            continue;
         }
         
         if(!CanAffordOrder(Pairs[i].symbol, ORDER_TYPE_SELL, lotSize))
            continue;
            
         Print("TRADE SELL: ", Pairs[i].symbol,
               " | Top: ", (Pairs[i].isTopPair ? "Y" : "N"),
               " | Edge: ", DoubleToString(Pairs[i].edgeScore,2),
               " | Comp: ", DoubleToString(Pairs[i].comp,2),
               " | Mom: ", DoubleToString(Pairs[i].edgeMomentum,2),
               " | PB: ", DoubleToString(Pairs[i].edgePullback,2),
               " | Tr: ", DoubleToString(Pairs[i].edgeTrend,2),
               " | Reg: ", DoubleToString(Pairs[i].edgeRegime,2),
               " | Score: ", DoubleToString(Pairs[i].score,2),
               " | Cur: ", DoubleToString(Pairs[i].currencyScore,2),
               " | Sl: ", DoubleToString(Pairs[i].slope,2),
               " | Ac: ", DoubleToString(Pairs[i].accel,2),
               " | RSI: ", DoubleToString(Pairs[i].rsiM5,1),
               " | Lot: ", DoubleToString(lotSize,2));

         Pairs[i].waitReason = "LIVE";
         Pairs[i].sellGrid.SetLotSize(lotSize);
         Pairs[i].sellGrid.Start();
         RegisterNewBasketEntry();
    
      }
   }
}

double GetTotalOpenLots()
{
   double lots = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;

      lots += PositionGetDouble(POSITION_VOLUME);
   }

   return lots;
}

double GetDynamicMaxTotalLots()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);

   if(InpBaseBalanceForMaxLots <= 0.0)
      return InpBaseMaxTotalLots;

   double maxLots = (balance / InpBaseBalanceForMaxLots) * InpBaseMaxTotalLots;

   if(InpHardMaxTotalLots > 0.0)
      maxLots = Clamp(maxLots, InpMinMaxTotalLots, InpHardMaxTotalLots);
   else
      maxLots = MathMax(maxLots, InpMinMaxTotalLots);

   return maxLots;
}

double GetDynamicTrendExitMinProfit()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);

   if(InpBaseBalanceForTrendExitProfit <= 0.0)
      return InpBaseTrendExitMinProfit;

   double minProfit = (balance / InpBaseBalanceForTrendExitProfit) * InpBaseTrendExitMinProfit;

   if(InpMaxTrendExitProfit > 0.0)
      minProfit = Clamp(minProfit, InpMinTrendExitProfit, InpMaxTrendExitProfit);
   else
      minProfit = MathMax(minProfit, InpMinTrendExitProfit);

   return minProfit;
}


double GetAccountDDPercent()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);

   return MathMax(0.0, SafeDiv(balance - equity, balance, 0.0) * 100.0);
}

double GetEquityDDPercent()
{
   return GetAccountDDPercent();
}

double GetEffectiveAccountDDPercent()
{
   return GetAccountDDPercent();
}

double GetBasketLossPctBalance(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   double pnl = isBuyGrid ? Pairs[idx].buyGrid.GridPnL()
                          : Pairs[idx].sellGrid.GridPnL();

   if(pnl >= 0.0)
      return 0.0;

   return (-pnl / balance) * 100.0;
}

bool IsBasketHardStopHit(const int idx, const bool isBuyGrid)
{
   if(InpBasketHardStopPctBal <= 0.0)
      return false;

   return (GetBasketLossPctBalance(idx, isBuyGrid) >= InpBasketHardStopPctBal);
}

void UpdatePeakEquity()
{
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(eq > gPeakEquity)
      gPeakEquity = eq;
}

double GetFreeMarginPercent()
{
   double equity     = AccountInfoDouble(ACCOUNT_EQUITY);
   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);

   return SafeDiv(freeMargin, equity, 0.0) * 100.0;
}

double GetMarginLevelPercent()
{
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double margin = AccountInfoDouble(ACCOUNT_MARGIN);

   return SafeDiv(equity, margin, 0.0) * 100.0;
}


int GetGridMagicNumber(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return -1;

   return isBuyGrid ? (InpMagicBuy + idx) : (InpMagicSell + idx);
}

datetime GetOldestGridOpenTime(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   string symbol = Pairs[idx].symbol;
   int    magic  = GetGridMagicNumber(idx, isBuyGrid);

   if(symbol == "" || magic < 0)
      return 0;

   datetime oldest = 0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;

      string posSymbol = PositionGetString(POSITION_SYMBOL);
      long   posMagic  = PositionGetInteger(POSITION_MAGIC);
      long   posType   = PositionGetInteger(POSITION_TYPE);

      if(posSymbol != symbol)
         continue;

      if((int)posMagic != magic)
         continue;

      if(isBuyGrid && posType != POSITION_TYPE_BUY)
         continue;

      if(!isBuyGrid && posType != POSITION_TYPE_SELL)
         continue;

      datetime posTime = (datetime)PositionGetInteger(POSITION_TIME);

      if(oldest == 0 || posTime < oldest)
         oldest = posTime;
   }

   return oldest;
}

double GetGridAgeDays(const int idx, const bool isBuyGrid)
{
   datetime oldest = GetOldestGridOpenTime(idx, isBuyGrid);
   if(oldest <= 0)
      return 0.0;

   return (double)(TimeCurrent() - oldest) / 86400.0;
}

bool IsBuyTrendInvalidated(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].buyGrid.CountPositions() <= 0)
      return false;

   if(Pairs[idx].direction == ORDER_TYPE_SELL)
      return true;

   return false;
}

bool IsSellTrendInvalidated(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].sellGrid.CountPositions() <= 0)
      return false;

   if(Pairs[idx].direction == ORDER_TYPE_BUY)
      return true;

   return false;
}



double GetAllowedTimeExitThresholdMoney(const double ageDays)
{
   if(!InpUseTimeExit)
      return -DBL_MAX;

   if(InpGridTimeExitStartDays <= 0.0)
      return -DBL_MAX;

   if(ageDays < InpGridTimeExitStartDays)
      return -DBL_MAX;

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      balance = AccountInfoDouble(ACCOUNT_EQUITY);

   if(balance <= 0.0)
      return 0.0;

   // Phase 1:
   // Once grid age >= StartDays, begin looking for exit,
   // but for ProfitDays we only accept >= 0 money exit.
   double profitOnlyUntil = InpGridTimeExitStartDays + MathMax(0.0, InpGridTimeExitProfitDays);

   if(ageDays < profitOnlyUntil)
      return 0.0;

   // Phase 2:
   // After profit-only period, allow progressively larger loss.
   double stepDays = MathMax(0.1, InpGridTimeExitStepDays);
   double extraDays = ageDays - profitOnlyUntil;

   int steps = (int)MathFloor(extraDays / stepDays) + 1;
   if(steps < 1)
      steps = 1;

   double allowedLossPct = steps * MathMax(0.0, InpGridTimeExitLossStepPct);

   if(InpGridTimeExitMaxLossPct > 0.0)
      allowedLossPct = MathMin(allowedLossPct, InpGridTimeExitMaxLossPct);

   double allowedLossMoney = balance * allowedLossPct / 100.0;

   return -allowedLossMoney;
}

bool ShouldExitGridByTime(const int idx,
                          const bool isBuyGrid,
                          const double pnl,
                          double &ageDays,
                          double &thresholdMoney,
                          string &reason)
{
   ageDays        = 0.0;
   thresholdMoney = 0.0;
   reason         = "";

   if(!InpUseTimeExit)
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   int count = isBuyGrid ? Pairs[idx].buyGrid.CountPositions()
                         : Pairs[idx].sellGrid.CountPositions();

   if(count <= 0)
      return false;

   ageDays = GetGridAgeDays(idx, isBuyGrid);
   if(ageDays < InpGridTimeExitStartDays)
      return false;

   thresholdMoney = GetAllowedTimeExitThresholdMoney(ageDays);

   if(pnl >= thresholdMoney)
   {
      if(thresholdMoney >= 0.0)
         reason = "TIME EXIT PROFIT";
      else
         reason = "TIME EXIT LOSS";

      return true;
   }

   return false;
}


bool SpreadAcceptable(string symbol, double maxPoints)
{
   double ask   = SymbolInfoDouble(symbol, SYMBOL_ASK);
   double bid   = SymbolInfoDouble(symbol, SYMBOL_BID);
   double point = SymbolInfoDouble(symbol, SYMBOL_POINT);

   if(ask <= 0.0 || bid <= 0.0 || point <= 0.0)
      return false;

   double spreadPts = (ask - bid) / point;

   double maxAllowed = maxPoints;

   if(StringFind(symbol, "XAU") >= 0) maxAllowed = 80;
   if(StringFind(symbol, "XAG") >= 0) maxAllowed = 120;

   return (spreadPts <= maxAllowed);
}
double GetSpreadPoints(string symbol)
{
   double ask = SymbolInfoDouble(symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(symbol, SYMBOL_BID);

   if(ask <= 0.0 || bid <= 0.0)
      return -1.0;

   return PriceToPoints(symbol, ask - bid);
}
bool CanAffordOrder(string symbol, ENUM_ORDER_TYPE type, double lots)
{
   if(lots <= 0.0)
      return false;

   double price = (type == ORDER_TYPE_BUY)
      ? SymbolInfoDouble(symbol, SYMBOL_ASK)
      : SymbolInfoDouble(symbol, SYMBOL_BID);

   if(price <= 0.0)
      return false;

   double marginRequired = 0.0;
   if(!OrderCalcMargin(type, symbol, lots, price, marginRequired))
      return false;

   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(freeMargin <= 0.0)
      return false;

   if(marginRequired > freeMargin * (InpMaxFirstOrderMarginPct / 100.0))
      return false;

   return true;
}


bool IsExposureTooHigh()
{
   if(InpMaxTotalPositions > 0 && PositionsTotal() >= InpMaxTotalPositions)
      return true;

   double maxTotalLots = GetDynamicMaxTotalLots();
   if(maxTotalLots > 0.0 && GetTotalOpenLots() >= maxTotalLots)
      return true;

   return false;
}


void EmergencyCloseAllGrids(string reason)
{
   Print("===!!! [TMD] EMERGENCY CLOSE ALL: ", reason, " !!!===");

   for(int i = 0; i < PairSize; i++)
   {
      Pairs[i].buyGrid.CloseGrid();
      Pairs[i].sellGrid.CloseGrid();
   }
}


double GetPairProfitPercent(const int idx)
{
   double base = InpProfitPercent;

   if(idx < 0 || idx >= PairSize)
      return base;

   if(Pairs[idx].comp >= 8.5 && Pairs[idx].score >= 7.2)
      return base * 1.30;

   if(Pairs[idx].comp >= 7.8 && Pairs[idx].score >= 6.9)
      return base * 1.15;

   return base;
}


double GetDynamicLotSize(double baseLot, double signal)
{
   if(!InpUseDynamicLot)
      return baseLot;

   double minSignal = InpUseRankOnlySelection ? InpSoftMinEdgeForRanking : InpMinScore;
   double t = Normalize01(signal, minSignal, 10.0);
   double factor = InpMinLotFactor + (InpMaxLotFactor - InpMinLotFactor) * t;
   return baseLot * factor;
}

double GetGridProfitTargetMoney(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return 0.0;

   GridManager *grid = isBuyGrid ? Pairs[idx].buyGrid : Pairs[idx].sellGrid;

   double lots = grid.CountLots();
   if(lots <= 0.0)
      return 0.0;

   double avgPrice = GetAveragePrice(GetGridMagicNumber(idx, isBuyGrid), Pairs[idx].symbol);
   if(avgPrice <= 0.0)
      return 0.0;

   double pct = GetPairProfitPercent(idx);
   double normalTarget = ProfitTargetMoney(lots, avgPrice, pct, Pairs[idx].symbol);

   return GetReducedTpEscapeTargetMoney(idx, isBuyGrid, normalTarget);
}

bool IsTrailContinuationValid(const int idx, const bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(isBuyGrid)
   {
      if(Pairs[idx].direction != ORDER_TYPE_BUY)
         return false;
   }
   else
   {
      if(Pairs[idx].direction != ORDER_TYPE_SELL)
         return false;
   }

   if(!Pairs[idx].aligned)
      return false;



   if(Pairs[idx].slope < InpTrailMinSlope)
      return false;

   if(Pairs[idx].accel < InpTrailMinAccel)
      return false;

   return true;
}


double GetBasketTrailRetracePct(const string symbol)
{
   if(StringFind(symbol, "XAU") >= 0) return InpBasketTrailRetracePctXAU;
   if(StringFind(symbol, "XAG") >= 0) return InpBasketTrailRetracePctXAG;
   return InpBasketTrailRetracePctFX;
}


double GetEarlyKillMaxLossMoney()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   return balance * InpEarlyKillMaxLossPctBal / 100.0;
}

double GetEarlyKillMinLossMoney()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   return balance * InpEarlyKillMinLossPctBal / 100.0;
}


bool ShouldExitBuyEarlyKill(const int idx,
                            const double pnl,
                            double &ageDays,
                            double &minLossMoney,
                            double &maxLossMoney,
                            string &reason)
{
   ageDays      = 0.0;
   minLossMoney = 0.0;
   maxLossMoney = 0.0;
   reason       = "";
   
   

   if(InpUseEarlyKillExit != ON)
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].buyGrid.CountPositions() <= 0)
      return false;

   if(Pairs[idx].buyGrid.CountPositions() < MathMax(1, InpEarlyKillMinPositions))
      return false;

   if(pnl >= 0.0)
      return false;
      
   bool strongOpposition = false;
   double buyCurScore = GetBuyBasketCurrencyScore(idx);
   
   if(Pairs[idx].direction == ORDER_TYPE_SELL)
      strongOpposition = true;
   
   if(buyCurScore <= InpEarlyKillMaxCurrencyScore)   // tune later
      strongOpposition = true;
   
   if(!strongOpposition)
      return false;
      

   ageDays = GetGridAgeDays(idx, true);
   if(ageDays < InpEarlyKillMinAgeDays)
      return false;

   if(Pairs[idx].buyInvalidBars < MathMax(1, InpEarlyKillBars))
      return false;

   minLossMoney = GetEarlyKillMinLossMoney();
   maxLossMoney = GetEarlyKillMaxLossMoney();

   double lossMoney = MathAbs(pnl);

   if(lossMoney < minLossMoney)
      return false;

   if(maxLossMoney > 0.0 && lossMoney > maxLossMoney)
      return false;

   reason = "EARLY KILL BUY";
   return true;
}

bool ShouldExitSellEarlyKill(const int idx,
                             const double pnl,
                             double &ageDays,
                             double &minLossMoney,
                             double &maxLossMoney,
                             string &reason)
{
   ageDays      = 0.0;
   minLossMoney = 0.0;
   maxLossMoney = 0.0;
   reason       = "";

   if(InpUseEarlyKillExit != ON)
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].sellGrid.CountPositions() <= 0)
      return false;

   if(Pairs[idx].sellGrid.CountPositions() < MathMax(1, InpEarlyKillMinPositions))
      return false;

   if(pnl >= 0.0)
      return false;

   bool strongOpposition = false;
   double sellCurScore = GetSellBasketCurrencyScore(idx);
   
   if(Pairs[idx].direction == ORDER_TYPE_BUY)
      strongOpposition = true;
   
   if(sellCurScore <= InpEarlyKillMaxCurrencyScore)
      strongOpposition = true;
   
   if(!strongOpposition)
      return false;
      
   ageDays = GetGridAgeDays(idx, false);
   if(ageDays < InpEarlyKillMinAgeDays)
      return false;

   if(Pairs[idx].sellInvalidBars < MathMax(1, InpEarlyKillBars))
      return false;

   minLossMoney = GetEarlyKillMinLossMoney();
   maxLossMoney = GetEarlyKillMaxLossMoney();

   double lossMoney = MathAbs(pnl);

   if(lossMoney < minLossMoney)
      return false;

   if(maxLossMoney > 0.0 && lossMoney > maxLossMoney)
      return false;

   reason = "EARLY KILL SELL";
   return true;
}

double GetBuyBasketCurrencyScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 5.0;

   double dirSpread = Pairs[idx].baseStrength - Pairs[idx].quoteStrength;
   double curScore  = (MathTanh(dirSpread * 1.2) + 1.0) * 5.0;
   return Clamp(curScore, 0.0, 10.0);
}

double GetSellBasketCurrencyScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 5.0;

   double dirSpread = Pairs[idx].quoteStrength - Pairs[idx].baseStrength;
   double curScore  = (MathTanh(dirSpread * 1.2) + 1.0) * 5.0;
   return Clamp(curScore, 0.0, 10.0);
}



bool ShouldExitBuyRecoveryKill(const int idx,
                               const double pnl,
                               double &ageDays,
                               double &worstPnL,
                               double &recoveryRatio,
                               double &maxLossMoney,
                               string &reason)
{
   ageDays       = 0.0;
   worstPnL      = 0.0;
   recoveryRatio = 0.0;
   maxLossMoney  = 0.0;
   reason        = "";

   if(InpUseEarlyKillExit != ON)
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].buyGrid.CountPositions() <= 0)
      return false;

   if(pnl >= 0.0)
      return false;

   if(Pairs[idx].buyGrid.CountPositions() < MathMax(1, InpEarlyKillRecoveryMinPositions))
      return false;

   ageDays = GetGridAgeDays(idx, true);
   if(ageDays < InpEarlyKillRecoveryMinAgeDays)
      return false;

   worstPnL = Pairs[idx].buyWorstPnL;
   if(worstPnL >= 0.0)
      return false;

   double worstLossMinMoney = GetEarlyKillWorstLossMinMoney();
   if(MathAbs(worstPnL) < worstLossMinMoney)
      return false;

   maxLossMoney = GetEarlyKillRecoveryMaxLossMoney();
   if(maxLossMoney > 0.0 && MathAbs(pnl) > maxLossMoney)
      return false;

   recoveryRatio = MathAbs(pnl) / MathAbs(worstPnL);

   // recoveryRatio:
   // 1.00 = still near worst point (bad)
   // 0.70 = recovered 30%
   // 0.40 = recovered 60%
   double maxAllowedRatio = 1.0 - InpEarlyKillMinRecoveryPct;

   if(recoveryRatio > maxAllowedRatio)
   {
      reason = "NO RECOVERY BUY";
      return true;
   }

   return false;
}

bool ShouldExitSellRecoveryKill(const int idx,
                                const double pnl,
                                double &ageDays,
                                double &worstPnL,
                                double &recoveryRatio,
                                double &maxLossMoney,
                                string &reason)
{
   ageDays       = 0.0;
   worstPnL      = 0.0;
   recoveryRatio = 0.0;
   maxLossMoney  = 0.0;
   reason        = "";

   if(InpUseEarlyKillExit != ON)
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   if(Pairs[idx].sellGrid.CountPositions() <= 0)
      return false;

   if(pnl >= 0.0)
      return false;

   if(Pairs[idx].sellGrid.CountPositions() < MathMax(1, InpEarlyKillRecoveryMinPositions))
      return false;

   ageDays = GetGridAgeDays(idx, false);
   if(ageDays < InpEarlyKillRecoveryMinAgeDays)
      return false;

   worstPnL = Pairs[idx].sellWorstPnL;
   if(worstPnL >= 0.0)
      return false;

   double worstLossMinMoney = GetEarlyKillWorstLossMinMoney();
   if(MathAbs(worstPnL) < worstLossMinMoney)
      return false;

   maxLossMoney = GetEarlyKillRecoveryMaxLossMoney();
   if(maxLossMoney > 0.0 && MathAbs(pnl) > maxLossMoney)
      return false;

   recoveryRatio = MathAbs(pnl) / MathAbs(worstPnL);

   double maxAllowedRatio = 1.0 - InpEarlyKillMinRecoveryPct;

   if(recoveryRatio > maxAllowedRatio)
   {
      reason = "NO RECOVERY SELL";
      return true;
   }

   return false;
}
double GetEarlyKillRecoveryMaxLossMoney()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   return balance * InpEarlyKillRecoveryMaxLossPctBal / 100.0;
}

double GetEarlyKillWorstLossMinMoney()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance <= 0.0)
      return 0.0;

   return balance * InpEarlyKillWorstLossMinPctBal / 100.0;
}
#endif