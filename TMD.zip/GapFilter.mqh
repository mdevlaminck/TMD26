//+------------------------------------------------------------------+
//|                                                    GapFilter.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"
input group "=== Monday Gap Filter ===";
input bool   InpUseMondayGapFilter   = false;
input double InpMondayGapMinPoints   = 100;   // points, adapt per symbol

void UpdateMondayGapFilterForPair(PairData &p)
{
   if(!InpUseMondayGapFilter)
   {
      p.mondayGapBias = GAP_NONE;
      p.mondayGapDay  = -1;
      return;
   }

   MqlDateTime now;
   TimeToStruct(TimeCurrent(), now);

   // Only active on Monday. Reset on other days.
   if(now.day_of_week != 1)
   {
      if(p.mondayGapBias != GAP_NONE || p.mondayGapDay != -1)
      {
         p.mondayGapBias = GAP_NONE;
         p.mondayGapDay  = -1;
      }
      return;
   }

   // Only calculate once per Monday
   if(p.mondayGapDay == now.day)
      return;

   double minGap = InpMondayGapMinPoints;
   if(StringFind(p.symbol, "XAU") >= 0) minGap = 2500;
   if(StringFind(p.symbol, "XAG") >= 0) minGap = 1800;
   p.mondayGapBias = DetectMondayGapBias(p.symbol, minGap);
   p.mondayGapDay  = now.day;

   Print("MONDAY GAP UPDATE: ", p.symbol,
         " | Day=", IntegerToString(now.day),
         " | Bias=", IntegerToString((int)p.mondayGapBias));
}

GapBias DetectMondayGapBias(const string symbol, const double minPoints)
{
   MqlRates rates[];
   ArraySetAsSeries(rates, true);

   // Fetch enough H1 bars to safely cover Friday -> Monday transition
   int copied = CopyRates(symbol, PERIOD_H1, 0, 400, rates);
   if(copied < 30)
      return GAP_NONE;

   int mondayIdx = -1;
   int fridayIdx = -1;

   // ------------------------------------------------------------
   // Find the FIRST Monday bar after a non-Monday bar
   // With series array:
   // rates[0] = newest, larger index = older
   // So iterate old -> new to catch the weekend transition cleanly
   // ------------------------------------------------------------
   for(int i = copied - 2; i >= 0; i--)
   {
      MqlDateTime curDt, prevDt;
      TimeToStruct(rates[i].time,     curDt);
      TimeToStruct(rates[i + 1].time, prevDt);

      // Transition into Monday
      if(curDt.day_of_week == 1 && prevDt.day_of_week != 1)
      {
         mondayIdx = i;
         break;
      }
   }

   if(mondayIdx == -1)
      return GAP_NONE;

   // ------------------------------------------------------------
   // Walk backward in older history from that Monday bar
   // until we find the LAST Friday bar before the weekend
   // ------------------------------------------------------------
   for(int j = mondayIdx + 1; j < copied; j++)
   {
      MqlDateTime dt;
      TimeToStruct(rates[j].time, dt);

      if(dt.day_of_week == 5) // Friday
      {
         fridayIdx = j;
         break;
      }
   }

   if(fridayIdx == -1)
      return GAP_NONE;

   double mondayOpen  = rates[mondayIdx].open;
   double fridayClose = rates[fridayIdx].close;

   double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
   if(point <= 0.0)
      return GAP_NONE;

   double gapPoints = (mondayOpen - fridayClose) / point;

   Print("MONDAY GAP DETECT: ", symbol,
         " | MondayOpen=", DoubleToString(mondayOpen, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)),
         " | FridayClose=", DoubleToString(fridayClose, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)),
         " | GapPoints=", DoubleToString(gapPoints, 1),
         " | Threshold=", DoubleToString(minPoints, 1));

   if(gapPoints >= minPoints)
      return GAP_BULL;

   if(gapPoints <= -minPoints)
      return GAP_BEAR;

   return GAP_NONE;
}


bool IsBlockedByMondayGap(const PairData &p, const int direction)
{
   if(!InpUseMondayGapFilter)
      return false;

   MqlDateTime now;
   TimeToStruct(TimeCurrent(), now);

   // Monday only, no carry-over to Tuesday
   if(now.day_of_week != 1)
      return false;

   if(p.mondayGapBias == GAP_BULL && direction == ORDER_TYPE_SELL)
   {
      //Print("MONDAY GAP BLOCK SELL: ", p.symbol);
      return true;
   }

   if(p.mondayGapBias == GAP_BEAR && direction == ORDER_TYPE_BUY)
   {
      //Print("MONDAY GAP BLOCK BUY: ", p.symbol);
      return true;
   }

   return false;
}