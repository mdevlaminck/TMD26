//+------------------------------------------------------------------+
//|                                                      Structs.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"


enum ENUM_ONOFF
{
   OFF = 0,
   ON  = 1
};

enum AdaptiveGridState
{
   AGS_NORMAL  = 0,
   AGS_CAUTION = 1,
   AGS_STRESS  = 2,
   AGS_BLOCK   = 3
};
enum BasketDamageState
{
   BDS_NORMAL   = 0,
   BDS_DAMAGED  = 1,
   BDS_CRITICAL = 2,
   BDS_EXIT_ONLY = 3
};
// TYPES

enum GapBias
{
   GAP_NONE = 0,
   GAP_BULL = 1,
   GAP_BEAR = -1
};



struct GroupState
{
   int buyCount;
   int sellCount;
};

enum MarketRegime
{
   REGIME_RANGE = 0,
   REGIME_TREND = 1,
   REGIME_EXPANSION = 2,
   REGIME_RISK_OFF = 3
};