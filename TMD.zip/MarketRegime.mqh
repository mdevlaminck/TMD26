//+------------------------------------------------------------------+
//|                                                MarketRegime.mqh  |
//|                                                              MDV |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"

input group "=== Market Regime Engine ===";
input ENUM_ONOFF InpUseMarketRegimeEngine        = ON;
input bool       InpRegimeUseRiskOffOverride     = true;
input bool       InpRegimeUseHighVolExpansion    = true;
input double     InpRegimeMinTrendComp           = 6.8;
input double     InpRegimeMinTrendAccel          = 5.2;
input double     InpRegimeExpansionStretchM15    = 1.20;
input double     InpRegimeExpansionAccelExtreme  = 8.5;
input bool       InpBlockNewEntriesInExpansion   = true;
input bool       InpBlockCounterTrendEntries     = true;
input bool       InpFreezeExpansionInExpansion   = true;

int GetTrendRegimeScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   int score = 0;

   if(Pairs[idx].aligned)
      score++;

   if(Pairs[idx].comp >= InpRegimeMinTrendComp)
      score++;

   if(Pairs[idx].accel >= InpRegimeMinTrendAccel)
      score++;

   if(Pairs[idx].direction == ORDER_TYPE_BUY && Pairs[idx].trendH4 == UPTREND)
      score++;
   else if(Pairs[idx].direction == ORDER_TYPE_SELL && Pairs[idx].trendH4 == DOWNTREND)
      score++;

   return score;
}

int GetExpansionRegimeScore(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 0;

   int score = 0;

   if(InpRegimeUseHighVolExpansion && Pairs[idx].highVolatility)
      score += 2;

   if(MathAbs(Pairs[idx].entryStretchM15) >= InpRegimeExpansionStretchM15)
      score += 1;

   if(Pairs[idx].accel >= InpRegimeExpansionAccelExtreme)
      score += 1;

   return score;
}

MarketRegime DetectMarketRegime(const int idx)
{
   if(idx < 0 || idx >= PairSize)
      return REGIME_RANGE;

   if(!InpUseMarketRegimeEngine)
      return REGIME_RANGE;

   if(InpRegimeUseRiskOffOverride && (gRiskOffActive || gRiskOffCooldown))
      return REGIME_RISK_OFF;

   int trendScore     = GetTrendRegimeScore(idx);
   int expansionScore = GetExpansionRegimeScore(idx);

   if(expansionScore >= 3)
      return REGIME_EXPANSION;

   if(trendScore >= 3)
      return REGIME_TREND;

   return REGIME_RANGE;
}

void UpdateMarketRegimeState()
{
   for(int i = 0; i < PairSize; i++)
   {
      Pairs[i].regimeScoreTrend     = GetTrendRegimeScore(i);
      Pairs[i].regimeScoreExpansion = GetExpansionRegimeScore(i);
      Pairs[i].regime               = DetectMarketRegime(i);

      Pairs[i].regimeBlockBuy  = false;
      Pairs[i].regimeBlockSell = false;

      if(Pairs[i].regime == REGIME_EXPANSION && InpBlockNewEntriesInExpansion)
      {
         Pairs[i].regimeBlockBuy  = true;
         Pairs[i].regimeBlockSell = true;
         continue;
      }

      // Only block counter-trend in STRONG trend, not normal trend
      if(Pairs[i].regime == REGIME_TREND && InpBlockCounterTrendEntries)
      {
         bool strongTrend =
            (Pairs[i].regimeScoreTrend >= 5) &&
            (Pairs[i].accel >= 7.5);
      
         if(strongTrend)
         {
            if(Pairs[i].trendH4 == UPTREND)
               Pairs[i].regimeBlockSell = true;
            else if(Pairs[i].trendH4 == DOWNTREND)
               Pairs[i].regimeBlockBuy = true;
         }
      }

      if(Pairs[i].regime == REGIME_RISK_OFF)
      {
         // Leave directional filtering mostly to RiskOffEngine.
         // Regime here only tags the pair state.
      }
   }
}

bool IsRegimeBlockingEntry(const int idx, const bool isBuy, string &reason)
{
   reason = "";

   if(!InpUseMarketRegimeEngine)
      return false;

   if(idx < 0 || idx >= PairSize)
   {
      reason = "REG IDX";
      return true;
   }

   if(isBuy && Pairs[idx].regimeBlockBuy)
   {
      if(Pairs[idx].regime == REGIME_EXPANSION) reason = "REG EXP";
      else if(Pairs[idx].regime == REGIME_TREND) reason = "REG CTR";
      else reason = "REGIME";
      return true;
   }

   if(!isBuy && Pairs[idx].regimeBlockSell)
   {
      if(Pairs[idx].regime == REGIME_EXPANSION) reason = "REG EXP";
      else if(Pairs[idx].regime == REGIME_TREND) reason = "REG CTR";
      else reason = "REGIME";
      return true;
   }

   return false;
}

bool IsRegimeBlockingExpansion(const int idx, const bool isBuyGrid)
{
   if(!InpUseMarketRegimeEngine)
      return false;

   if(idx < 0 || idx >= PairSize)
      return true;

   if(Pairs[idx].regime == REGIME_EXPANSION && InpFreezeExpansionInExpansion)
      return true;

   if(Pairs[idx].regime == REGIME_TREND && InpBlockCounterTrendEntries)
   {
      if(isBuyGrid && Pairs[idx].trendH4 == DOWNTREND)
         return true;

      if(!isBuyGrid && Pairs[idx].trendH4 == UPTREND)
         return true;
   }

   return false;
}

