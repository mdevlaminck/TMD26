// CONFIG
input group "=== Visual Settings ===";
input ENUM_ONOFF InpStyleChart = ON;
input ENUM_ONOFF InpShowPanel  = OFF;
input group "=== Symbol Settings ===";
input string InpSuffix = "";
input string InpPrefix = "";
input group "=== Lot Settings ===";
input ENUM_ONOFF InpUseAutoLot = ON;
input double InpBalancePerLot = 400;
input double InpInitialLot = 0.01;
input ENUM_ONOFF InpUseDynamicLot = ON;
input double InpMinLotFactor = 0.7;
input double InpMaxLotFactor = 2.5;
input group "=== Location Filter ===";
input bool   InpUseLocationFilter      = true;
input int    InpLocationEmaPeriodM15   = 20;
input int    InpLocationEmaPeriodH1    = 20;
input double InpMaxEntryStretchM15ATR  = 1.20;   // max allowed stretch on M15 in ATR units
input double InpMaxEntryStretchH1ATR   = 1.00;   // max allowed stretch on H1 in ATR units
input group "=== Grid Settings ===";
input int InpMagicBuy = 2204;
input int InpMagicSell = 1981;
input int InpMaxOrders = 14;
input int InpGapPoints = 200;
input double InpProfitPercent = 0.09;
input double InpGridMultiplier = 1.09;
input group "=== DD Controls ===";
input double InpAccountFreezeDDPct    = 20.0;
input double InpAccountEmergencyDDPct = 45.0;
input double InpBasketHardStopPctBal  = 0.0;
input double     InpCriticalMarginLevel    = 120.0;
