//+------------------------------------------------------------------+
//|                                                     TopPairs.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"

input group "=== Top Pair Filter Settings ===";
input ENUM_ONOFF InpUseTopPairsFilter       = OFF;
input int        InpTopPairsCount           = 14;
input int        InpMaxCurrencyReuseInTop   = 3;
input double     InpOverlapPenaltyPerSide   = 0.2;

int CountCurrencyUsageInSelected(const string currency, const int &selected[])
{
   if(currency == "")
      return 0;

   int count = 0;

   for(int i = 0; i < ArraySize(selected); i++)
   {
      int idx = selected[i];
      if(idx < 0 || idx >= PairSize)
         continue;

      string base  = StringSubstr(Pairs[idx].symbol, 0, 3);
      string quote = StringSubstr(Pairs[idx].symbol, 3, 3);

      if(base == currency)
         count++;
      if(quote == currency)
         count++;
   }

   return count;
}

double GetOverlapPenaltyScore(const int idx, const int &selected[])
{
   if(idx < 0 || idx >= PairSize)
      return 999.0;

   string base  = StringSubstr(Pairs[idx].symbol, 0, 3);
   string quote = StringSubstr(Pairs[idx].symbol, 3, 3);

   int baseUse  = CountCurrencyUsageInSelected(base, selected);
   int quoteUse = CountCurrencyUsageInSelected(quote, selected);

   return (baseUse + quoteUse) * InpOverlapPenaltyPerSide;
}

bool PassesSoftOverlapLimit(const int idx, const int &selected[])
{
   if(idx < 0 || idx >= PairSize)
      return false;

   if(InpMaxCurrencyReuseInTop <= 0)
      return true;

   string base  = StringSubstr(Pairs[idx].symbol, 0, 3);
   string quote = StringSubstr(Pairs[idx].symbol, 3, 3);

   int baseUse  = CountCurrencyUsageInSelected(base, selected);
   int quoteUse = CountCurrencyUsageInSelected(quote, selected);

   if(baseUse >= InpMaxCurrencyReuseInTop)
      return false;

   if(quoteUse >= InpMaxCurrencyReuseInTop)
      return false;

   return true;
}

bool IsTopPairSelected(const int idx, const int &selected[])
{
   return IsIndexInArray(idx, selected);
}

void ClearTopPairFlags()
{
   for(int i = 0; i < PairSize; i++)
      Pairs[i].isTopPair = false;
}

int BuildTopPairCandidates(int &candidateIdx[])
{
   ArrayResize(candidateIdx, 0);

   for(int i = 0; i < PairSize; i++)
   {
      string reason = "";
      if(IsPairHardBlockedForRanking(i, reason))
         continue;

      if(InpUseRankOnlySelection)
      {
         if(!PassesSoftRankingFloor(i))
            continue;
      }
      else
      {
         if(!IsPairStructurallyValid(i))
            continue;
      }

      // Require current filter cache to exist
      if(!Pairs[i].filtersValid)
         continue;

      // Require current entry trigger
      if(!HasEntryTrigger(i))
         continue;

      // Require pair can actually open a new basket now
      if(Pairs[i].direction == ORDER_TYPE_BUY)
      {
         if(Pairs[i].buyGrid.CountPositions() > 0)
            continue;

         if(!CanOpenGrid(Pairs[i].symbol, true))
            continue;
      }
      else if(Pairs[i].direction == ORDER_TYPE_SELL)
      {
         if(Pairs[i].sellGrid.CountPositions() > 0)
            continue;

         if(!CanOpenGrid(Pairs[i].symbol, false))
            continue;
      }
      else
      {
         continue;
      }

      int n = ArraySize(candidateIdx);
      ArrayResize(candidateIdx, n + 1);
      candidateIdx[n] = i;
   }

   return ArraySize(candidateIdx);
}

void SortCandidatesByScoreDesc(int &candidateIdx[])
{
   int n = ArraySize(candidateIdx);
   if(n <= 1)
      return;

   for(int a = 0; a < n - 1; a++)
   {
      for(int b = a + 1; b < n; b++)
      {
         double sa = GetPairSelectionScore(candidateIdx[a]);
         double sb = GetPairSelectionScore(candidateIdx[b]);

         if(sb > sa)
         {
            int tmp = candidateIdx[a];
            candidateIdx[a] = candidateIdx[b];
            candidateIdx[b] = tmp;
         }
      }
   }
}

void CapCandidateList(int &candidateIdx[])
{
   if(InpMaxRankedCandidates <= 0)
      return;

   int n = ArraySize(candidateIdx);
   if(n <= InpMaxRankedCandidates)
      return;

   ArrayResize(candidateIdx, InpMaxRankedCandidates);
}

void GetTopPairs(int &selected[])
{
   ArrayResize(selected, 0);
   ClearTopPairFlags();

   int targetCount = InpTopPairsCount;
   if(targetCount <= 0)
      return;

   int candidates[];
   BuildTopPairCandidates(candidates);

   if(ArraySize(candidates) <= 0)
      return;

   SortCandidatesByScoreDesc(candidates);
   CapCandidateList(candidates);

   for(int pick = 0; pick < targetCount; pick++)
   {
      int    bestIdx   = -1;
      double bestScore = -999999.0;

      for(int c = 0; c < ArraySize(candidates); c++)
      {
         int i = candidates[c];

         if(IsIndexInArray(i, selected))
            continue;

         if(!PassesSoftOverlapLimit(i, selected))
            continue;

         double rawRank   = GetPairSelectionScore(i);
         if(rawRank < 0.0)
            continue;

         double penalty   = GetOverlapPenaltyScore(i, selected);
         double finalRank = rawRank - penalty;

         if(bestIdx == -1 || finalRank > bestScore)
         {
            bestIdx   = i;
            bestScore = finalRank;
         }
      }

      if(bestIdx == -1)
         break;

      int n = ArraySize(selected);
      ArrayResize(selected, n + 1);
      selected[n] = bestIdx;
      Pairs[bestIdx].isTopPair = true;
   }
}