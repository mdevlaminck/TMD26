﻿//+------------------------------------------------------------------+
//|                                                        Panel.mqh |
//|                                                              MDV |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "MDV"
#property link      "https://www.mql5.com"

void CreateTMDInfoPanel()
{
   if(!InpShowPanel)
      return;

   ArrayResize(gPanelObjects, 0);

   int bgW = 900;

   CreatePanelRect("BG", 20, 30, 900, 790, C'10,16,28', C'10,16,28');
   CreatePanelRect("TB", 23, 33, bgW - 6, 28, C'10,16,28', C'10,16,28');

   CreatePanelRect("S1", 30, 65, 880, 1, C'25,40,55', tmdBg);
   CreatePanelRect("S2", 30, 130, 880, 1, C'25,40,55', tmdBg);
   CreatePanelRect("S3", 30, 316, 880, 1, C'25,40,55', tmdBg);

   CreatePanelRect("SV1", 280, 150, 1, 158, C'25,40,55', tmdBg);
   CreatePanelRect("SV2", 470, 150, 1, 158, C'25,40,55', tmdBg);
   CreatePanelRect("SV3", 640, 150, 1, 158, C'25,40,55', tmdBg);

   CreatePanelLabel("ONLINE_DOT", 30, 40, 9, C'0,230,120', "●");
   CreatePanelLabel("ONLINE_TXT", 42, 41, 9, C'0,180,180', "ONLINE");
   CreatePanelLabel("SERVER_TXT", 100, 41, 9, tmdSilver, "--:--:--");
   CreatePanelLabel("TITLE", 470, 38, 11, C'0,230,230', "◆ T M D ◆", ANCHOR_UPPER);

   CreatePanelLabel("L1", 30, 72, 9, C'70,90,110', "BALANCE");
   CreatePanelLabel("V1", 185, 72, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L2", 30, 90, 9, C'70,90,110', "EQUITY");
   CreatePanelLabel("V2", 185, 90, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L3", 30, 108, 9, C'70,90,110', "P / L");
   CreatePanelLabel("V3", 185, 108, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("L4", 230, 72, 9, C'70,90,110', "ACCOUNT");
   CreatePanelLabel("V4", 515, 72, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L5", 230, 90, 9, C'70,90,110', "BROKER");
   CreatePanelLabel("V5", 515, 90, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L6", 230, 108, 9, C'70,90,110', "LEVERAGE");
   CreatePanelLabel("V6", 515, 108, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("L7", 560, 72, 9, C'70,90,110', "DD");
   CreatePanelLabel("V7", 760, 72, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L8", 560, 90, 9, C'70,90,110', "FREE MARGIN");
   CreatePanelLabel("V8", 760, 90, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("L9", 560, 108, 9, C'70,90,110', "MARGIN %");
   CreatePanelLabel("V9", 760, 108, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("CUR_HDR", 30, 138, 9, C'180,40,220', "CURRENCIES");
   CreatePanelLabel("CUR_HDR2", 210, 138, 8, C'70,90,110', "STRENGTH", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("CURM_L1", 300, 138, 8, C'70,90,110', "WINS");
   CreatePanelLabel("CURM_V1", 455, 138, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("CURM_L2", 300, 153, 8, C'70,90,110', "LOSSES");
   CreatePanelLabel("CURM_V2", 455, 153, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("CURM_L3", 300, 168, 8, C'70,90,110', "WIN RATE");
   CreatePanelLabel("CURM_V3", 455, 168, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("CURM_L4", 300, 183, 8, C'70,90,110', "PROFIT FACTOR");
   CreatePanelLabel("CURM_V4", 455, 183, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("CURM_L5", 300, 198, 8, C'70,90,110', "AVG HOLD");
   CreatePanelLabel("CURM_V5", 455, 198, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L6", 300, 213, 8, C'70,90,110', "OPEN ORDERS");
   CreatePanelLabel("CURM_V6", 455, 213, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L7", 300, 228, 8, C'70,90,110', "MAX TOTAL ORDERS");
   CreatePanelLabel("CURM_V7", 455, 228, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L8", 300, 243, 8, C'70,90,110', "OPEN LOTS");
   CreatePanelLabel("CURM_V8", 455, 243, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CURM_L9", 300, 258, 8, C'70,90,110', "MAX LOTS DYN");
   CreatePanelLabel("CURM_V9", 455, 258, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("CFG_L1", 490, 138, 8, C'70,90,110', "MIN COMP");
   CreatePanelLabel("CFG_V1", 620, 138, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L2", 490, 153, 8, C'70,90,110', "BUY RSI");
   CreatePanelLabel("CFG_V2", 620, 153, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L3", 490, 168, 8, C'70,90,110', "SELL RSI");
   CreatePanelLabel("CFG_V3", 620, 168, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L4", 490, 183, 8, C'70,90,110', "PROFIT %");
   CreatePanelLabel("CFG_V4", 620, 183, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L5", 490, 198, 8, C'70,90,110', "MAX DD");
   CreatePanelLabel("CFG_V5", 620, 198, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L6", 490, 213, 8, C'70,90,110', "MAX GRID ORDERS");
   CreatePanelLabel("CFG_V6", 620, 213, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L7", 490, 228, 8, C'70,90,110', "LOT MODE");
   CreatePanelLabel("CFG_V7", 620, 228, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("CFG_L8", 490, 243, 8, C'70,90,110', "LOT BALANCE");
   CreatePanelLabel("CFG_V8", 620, 243, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   CreatePanelLabel("RISK_L1", 660, 213, 8, C'70,90,110', "RISK STATE");
   CreatePanelLabel("RISK_V1", 840, 213, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("RISK_L2", 660, 228, 8, C'70,90,110', "NEW ENTRIES");
   CreatePanelLabel("RISK_V2", 840, 228, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("RISK_L3", 660, 243, 8, C'70,90,110', "GRID EXPAND");
   CreatePanelLabel("RISK_V3", 840, 243, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("RISK_L4", 660, 258, 8, C'70,90,110', "RISK REASON");
   CreatePanelLabel("RISK_V4", 840, 258, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);

   for(int i = 0; i < PANEL_CUR_ROWS; i++)
   {
      int y = 158 + i * 15;
      CreatePanelLabel("CUR_L_" + IntegerToString(i), 30, y, 9, tmdSilver, "-");
      CreatePanelLabel("CUR_V_" + IntegerToString(i), 210, y, 9, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   }

   CreatePanelLabel("SYM_HDR",   30, 324, 9, C'0,230,230', "Symbols");
   CreatePanelLabel("SYM_COL1", 255, 324, 8, C'70,90,110', "COMP",  ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL2", 315, 324, 8, C'70,90,110', "SCORE", ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL3", 375, 324, 8, C'70,90,110', "ACC",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL8", 435, 324, 8, C'70,90,110', "RSI",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL10",490, 324, 8, C'70,90,110', "SPR",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL6", 530, 324, 8, C'70,90,110', "FLT");
   CreatePanelLabel("SYM_COL11",585, 324, 8, C'70,90,110', "H1/H4");
   CreatePanelLabel("SYM_COL9", 650, 324, 8, C'70,90,110', "STATE");
   CreatePanelLabel("SYM_COL4", 725, 324, 8, C'70,90,110', "ORD",   ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL7", 790, 324, 8, C'70,90,110', "LOTS",  ANCHOR_RIGHT_UPPER);
   CreatePanelLabel("SYM_COL5", 865, 324, 8, C'70,90,110', "P/L",   ANCHOR_RIGHT_UPPER);

   for(int i = 0; i < PANEL_SYM_ROWS; i++)
   {
      int y = 344 + i * 14;

      CreatePanelLabel("SYM_DOT_" + IntegerToString(i), 30,  y, 8, tmdSilver, "●");
      CreatePanelLabel("SYM_A_"   + IntegerToString(i), 42,  y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_B_"   + IntegerToString(i), 255, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_C_"   + IntegerToString(i), 315, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_D_"   + IntegerToString(i), 375, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_I_"   + IntegerToString(i), 435, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_K_"   + IntegerToString(i), 490, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_G_"   + IntegerToString(i), 530, y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_L_"   + IntegerToString(i), 585, y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_J_"   + IntegerToString(i), 650, y, 8, tmdSilver, "-");
      CreatePanelLabel("SYM_E_"   + IntegerToString(i), 725, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_H_"   + IntegerToString(i), 790, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
      CreatePanelLabel("SYM_F_"   + IntegerToString(i), 865, y, 8, tmdSilver, "-", ANCHOR_RIGHT_UPPER);
   }

   ChartRedraw();
}

void UpdateTMDInfoPanel()
{
   if(!InpShowPanel)
      return;

   bool eaOnline = IsEAOnline();

   SetPanelText("ONLINE_DOT", "●", eaOnline ? C'0,230,120' : tmdRed);
   SetPanelText("ONLINE_TXT", eaOnline ? "ONLINE" : "OFFLINE",
                eaOnline ? C'0,180,180' : tmdRed);
   SetPanelText("SERVER_TXT", GetServerTimeText(), tmdSilver);

   double balance    = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity     = AccountInfoDouble(ACCOUNT_EQUITY);
   double profit     = AccountInfoDouble(ACCOUNT_PROFIT);
   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double ddPct      = GetAccountDDPercent();
   double marginPct  = GetMarginLevelPercent();

   SetPanelText("V1", FormatMoney(balance), tmdSilver);
   SetPanelText("V2", FormatMoney(equity), tmdSilver);

   color pnlColor = tmdSilver;
   if(profit > 0.0) pnlColor = tmdGreen;
   else if(profit < 0.0) pnlColor = tmdRed;
   SetPanelText("V3", FormatMoney(profit), pnlColor);

   SetPanelText("V4", GetAccountNameText(), tmdSilver);
   SetPanelText("V5", GetBrokerText(), tmdSilver);
   SetPanelText("V6", GetLeverageText(), C'0,190,190');

   color ddClr = tmdGreen;
   if(ddPct >= 10.0) ddClr = tmdOrange;
   if(ddPct >= 20.0) ddClr = tmdRed;
   SetPanelText("V7", FormatPercent(ddPct, 2), ddClr);

   SetPanelText("V8", FormatMoney(freeMargin), tmdSilver);
   SetPanelText("V9", FormatPercent(marginPct, 2), GetFreeMarginColor(marginPct));

   int wins = 0;
   int losses = 0;
   double winRate = 0.0;
   double profitFactor = 0.0;
   string avgHoldText = "-";
   
   GetTradeStats(wins, losses, winRate, profitFactor, avgHoldText);

   int totalOpenOrders = PositionsTotal();
   double totalOpenLots = GetTotalOpenLots();

   color wrClr = tmdSilver;
   if(winRate >= 55.0) wrClr = tmdGreen;
   else if(winRate < 45.0) wrClr = tmdOrange;

   color pfClr = tmdSilver;
   if(profitFactor >= 1.5) pfClr = tmdGreen;
   else if(profitFactor < 1.0) pfClr = tmdRed;
   else pfClr = tmdOrange;

   color ordUsageClr = GetPositionUsageColor(totalOpenOrders);
   color lotUsageClr = GetLotUsageColor(totalOpenLots);

   SetPanelText("CURM_V1", IntegerToString(wins), tmdGreen);
   SetPanelText("CURM_V2", IntegerToString(losses), tmdRed);
   SetPanelText("CURM_V3", DoubleToString(winRate, 1) + "%", wrClr);
   SetPanelText("CURM_V4", DoubleToString(profitFactor, 2), pfClr);
   SetPanelText("CURM_V5", avgHoldText, C'0,190,190');
   SetPanelText("CURM_V6", IntegerToString(totalOpenOrders), ordUsageClr);
   SetPanelText("CURM_V7", IntegerToString(InpMaxTotalPositions), ordUsageClr);
   SetPanelText("CURM_V8", FormatLots(totalOpenLots), lotUsageClr);
   SetPanelText("CURM_V9", FormatLots(GetDynamicMaxTotalLots()), lotUsageClr);

   SetPanelText("CFG_V1", FormatDouble(InpMinScore, 1), tmdSilver);
   SetPanelText("CFG_V2", FormatDouble(InpBuyRsi, 1), tmdSilver);
   SetPanelText("CFG_V3", FormatDouble(InpSellRsi, 1), tmdSilver);
   SetPanelText("CFG_V4", FormatPercent(InpProfitPercent, 2), tmdSilver);
   SetPanelText("CFG_V5", FormatPercent(InpAccountEmergencyDDPct, 1), tmdSilver);
   SetPanelText("CFG_V6", IntegerToString(InpMaxOrders), tmdSilver);

   string lotMode = "FIXED";
   if(InpUseAutoLot && InpUseDynamicLot) lotMode = "AUTO+DYN";
   else if(InpUseAutoLot)                lotMode = "AUTO";
   else if(InpUseDynamicLot)             lotMode = "FIXED+DYN";

   SetPanelText("CFG_V7", lotMode, tmdSilver);
   SetPanelText("CFG_V8", FormatDouble(InpBalancePerLot, 0), tmdSilver);

   SetPanelText("RISK_V1", gRiskStateText,   gRiskStateColor);
   SetPanelText("RISK_V2", gEntryStateText,  gEntryStateColor);
   SetPanelText("RISK_V3", gExpandStateText, gExpandStateColor);
   SetPanelText("RISK_V4", gRiskReasonText,  gRiskReasonColor);

   for(int i = 0; i < PairSize; i++)
      RefreshPairVisualState(i);

   int curIdx[];
   GetSortedCurrencyIndices(currencyStrength, curIdx);

   for(int i = 0; i < PANEL_CUR_ROWS; i++)
   {
      if(i < ArraySize(curIdx))
      {
         int idx = curIdx[i];
         double val = currencyStrength[idx];

         color c = tmdSilver;
         if(val > 0.5) c = tmdGreen;
         else if(val < -0.5) c = tmdRed;
         else c = tmdOrange;

         SetPanelText("CUR_L_" + IntegerToString(i), IntegerToString(i + 1) + ". " + Currencies[idx], c);
         SetPanelText("CUR_V_" + IntegerToString(i), FormatDouble(val, 2), c);
      }
      else
      {
         SetPanelText("CUR_L_" + IntegerToString(i), "-", tmdSilver);
         SetPanelText("CUR_V_" + IntegerToString(i), "-", tmdSilver);
      }
   }

   int sortedIdx[];
   GetSortedPairIndicesForPanel(sortedIdx);
   
   for(int i = 0; i < PANEL_SYM_ROWS; i++)
   {
      if(i < ArraySize(sortedIdx))
      {
         int p = sortedIdx[i];
   
         string dirTxt = DirectionToText(Pairs[p].direction);
         color  dirClr = DirectionToColor(Pairs[p].direction);
   
         string stateTxt = Pairs[p].stateText;
         color  stateClr = Pairs[p].stateColor;
         color  dotClr   = Pairs[p].dotColor;
   
         int    openOrders = Pairs[p].openCount;
         double openLots   = Pairs[p].openLots;
         double gridPnl    = GetPairGridPnL(Pairs[p]);
         
         double spreadPts = GetSpreadPoints(Pairs[p].symbol);
   
         color pnlClr = tmdSilver;
         if(gridPnl > 0.0) pnlClr = tmdGreen;
         else if(gridPnl < 0.0) pnlClr = tmdRed;
         
         color spreadClr = tmdSilver;

         if(spreadPts < 0.0)
         {
            spreadClr = tmdSilver;
         }
         else if(InpMaxSpreadPoints > 0.0)
         {
            if(spreadPts <= InpMaxSpreadPoints * 0.75)
               spreadClr = tmdGreen;
            else if(spreadPts <= InpMaxSpreadPoints)
               spreadClr = tmdOrange;
            else
               spreadClr = tmdRed;
         }
   
   
         string pairText  = Pairs[p].symbol + " " + dirTxt;
         if(IsMetal(Pairs[p].symbol))
            pairText = "★ " + pairText;
         
         color filterClr = PairFilterColor(p);
         if(IsMetal(Pairs[p].symbol) && filterClr == tmdSilver)
            filterClr = C'255,215,0';
         string filterTxt = PairFilterText(p);

         
         string trendTxt = TrendComboText(p);
         color  trendClr = TrendComboColor(p);
   
         if(Pairs[p].buyGrid.CountPositions() > 0 && IsPairExpansionFrozen(p, true))
         {
            filterTxt = "EXP OFF";
            filterClr = tmdOrange;
         }
         else if(Pairs[p].sellGrid.CountPositions() > 0 && IsPairExpansionFrozen(p, false))
         {
            filterTxt = "EXP OFF";
            filterClr = tmdOrange;
         }
   
         color rsiClr = tmdSilver;
         if(Pairs[p].filtersValid)
         {
            if(Pairs[p].direction == ORDER_TYPE_BUY)
               rsiClr = Pairs[p].rsiBuyOk ? tmdGreen : tmdOrange;
            else if(Pairs[p].direction == ORDER_TYPE_SELL)
               rsiClr = Pairs[p].rsiSellOk ? tmdGreen : tmdOrange;
         }
   
SetPanelText("SYM_DOT_" + IntegerToString(i), "●", dotClr);
color pairClr = dirClr;
if(IsMetal(Pairs[p].symbol) && Pairs[p].direction == -1)
   pairClr = C'255,215,0';

SetPanelText("SYM_A_"   + IntegerToString(i), pairText, pairClr);
SetPanelText("SYM_B_"   + IntegerToString(i), FormatDouble(Pairs[p].comp, 1),
             (Pairs[p].comp >= InpMinScore ? tmdGreen : tmdOrange));
SetPanelText("SYM_C_"   + IntegerToString(i), FormatDouble(Pairs[p].score, 1),
             (Pairs[p].score >= 6.0 ? C'0,190,190' : tmdSilver));
SetPanelText("SYM_D_"   + IntegerToString(i), FormatDouble(Pairs[p].accel, 1),
             (Pairs[p].accel >= 5.5 ? tmdGreen : (Pairs[p].accel <= 4.5 ? tmdOrange : tmdSilver)));
SetPanelText("SYM_I_"   + IntegerToString(i),
             (Pairs[p].filtersValid ? FormatDouble(Pairs[p].rsiM5, 1) : "-"),
             rsiClr);

SetPanelText("SYM_K_"   + IntegerToString(i),
             (spreadPts >= 0.0 ? FormatDouble(spreadPts, 1) : "-"),
             spreadClr);

SetPanelText("SYM_G_"   + IntegerToString(i), filterTxt, filterClr);
SetPanelText("SYM_L_"   + IntegerToString(i), trendTxt, trendClr);
SetPanelText("SYM_J_"   + IntegerToString(i), stateTxt, stateClr);
SetPanelText("SYM_E_"   + IntegerToString(i), IntegerToString(openOrders),
             (openOrders > 0 ? C'0,230,230' : tmdSilver));
SetPanelText("SYM_H_"   + IntegerToString(i), FormatLots(openLots),
             (openLots > 0.0 ? C'0,230,230' : tmdSilver));
SetPanelText("SYM_F_"   + IntegerToString(i), FormatMoney(gridPnl), pnlClr);
      }
      else
      {
SetPanelText("SYM_DOT_" + IntegerToString(i), "●", tmdSilver);
SetPanelText("SYM_A_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_B_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_C_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_D_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_I_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_K_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_G_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_L_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_J_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_E_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_H_"   + IntegerToString(i), "-", tmdSilver);
SetPanelText("SYM_F_"   + IntegerToString(i), "-", tmdSilver);
      }
   }

   ChartRedraw();
}

void DeleteTMDInfoPanel()
{
   for(int i = 0; i < ArraySize(gPanelObjects); i++)
      ObjectDelete(0, gPanelObjects[i]);

   ArrayResize(gPanelObjects, 0);
   ChartRedraw();
}

bool IsEAOnline()
{
   bool terminalTrade = (bool)TerminalInfoInteger(TERMINAL_TRADE_ALLOWED);
   bool programTrade  = (bool)MQLInfoInteger(MQL_TRADE_ALLOWED);

   return (terminalTrade && programTrade);
}

string GetServerTimeText()
{
   return FormatTime(TimeCurrent());
}




double GetPairGridPnL(PairData &p)
{
   return p.buyGrid.GridPnL() + p.sellGrid.GridPnL();
}

int GetPanelSortRank(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return 99;

   if(HasActiveGrid(Pairs[idx]))
      return 0;

   if(IsPairEligibleNow(idx))
      return 1;

   return 2;
}

void GetSortedPairIndicesForPanel(int &indices[])
{
   int total = ArraySize(Pairs);
   ArrayResize(indices, total);

   for(int i = 0; i < total; i++)
      indices[i] = i;

   for(int i = 0; i < total - 1; i++)
   {
      for(int j = i + 1; j < total; j++)
      {
         int ia = indices[i];
         int ib = indices[j];

         int rankA = GetPanelSortRank(ia);
         int rankB = GetPanelSortRank(ib);

         bool doSwap = false;

         // 1) Primary sort: LIVE -> READY -> WAIT
         if(rankB < rankA)
         {
            doSwap = true;
         }
         // 2) Inside same bucket
         else if(rankA == rankB)
         {
            // LIVE bucket: sort by PnL descending, then alphabetically
            if(rankA == 0)
            {
               double pnlA = GetPairGridPnL(Pairs[ia]);
               double pnlB = GetPairGridPnL(Pairs[ib]);

               if(pnlB > pnlA)
               {
                  doSwap = true;
               }
               else if(pnlA == pnlB)
               {
                  string symA = Pairs[ia].symbol;
                  string symB = Pairs[ib].symbol;

                  if(StringCompare(symA, symB) > 0)
                     doSwap = true;
               }
            }
            // READY / WAIT: alphabetical
            else
            {
               string symA = Pairs[ia].symbol;
               string symB = Pairs[ib].symbol;

               if(StringCompare(symA, symB) > 0)
                  doSwap = true;
            }
         }

         if(doSwap)
         {
            int tmp = indices[i];
            indices[i] = indices[j];
            indices[j] = tmp;
         }
      }
   }
}

void RefreshPairVisualState(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return;

   bool hasLive  = HasActiveGrid(Pairs[idx]);
   bool eligible = false;

   if(!hasLive)
      eligible = IsPairEligibleNow(idx);

   Pairs[idx].eligibleNow = eligible;

   if(hasLive)
   {
      Pairs[idx].stateText  = "LIVE";
      Pairs[idx].stateColor = C'0,230,230';
      Pairs[idx].dotColor   = C'0,230,230';

      if(Pairs[idx].buyGrid.CountPositions() > 0)
         Pairs[idx].stateText = "BUY";

      if(Pairs[idx].sellGrid.CountPositions() > 0)
      {
         Pairs[idx].stateText  = "SELL";
         Pairs[idx].stateColor = C'180,40,220';
         Pairs[idx].dotColor   = C'180,40,220';
      }
      if((Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buyExpansionFrozenByInvalidation) ||
         (Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellExpansionFrozenByInvalidation))
      {
         Pairs[idx].dotColor = tmdOrange;
      }
      if((Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buySoftThrottle) ||
         (Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellSoftThrottle))
      {
         Pairs[idx].dotColor = tmdOrange;
      }

      if((Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buyDamageState == BDS_CRITICAL) ||
         (Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellDamageState == BDS_CRITICAL))
      {
         Pairs[idx].dotColor = tmdRed;
      }

      if((Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buyDamageState == BDS_EXIT_ONLY) ||
         (Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellDamageState == BDS_EXIT_ONLY))
      {
         Pairs[idx].dotColor = C'255,0,255';
      }
      return;
   }

   if(eligible)
   {
      Pairs[idx].stateText  = "READY";
      Pairs[idx].stateColor = tmdGreen;
      Pairs[idx].dotColor   = tmdGreen;
      return;
   }

   Pairs[idx].stateText = "WAIT";

   if(Pairs[idx].waitReason == "RO DIR" ||
      Pairs[idx].waitReason == "RO ACC" ||
      Pairs[idx].waitReason == "RO CMP" ||
      Pairs[idx].waitReason == "RISKOFF" ||
      Pairs[idx].waitReason == "RO CD")
   {
      Pairs[idx].stateText  = "RO";
      Pairs[idx].stateColor = (Pairs[idx].waitReason == "RO DIR" || Pairs[idx].waitReason == "RISKOFF") ? tmdRed : tmdOrange;
      Pairs[idx].dotColor   = Pairs[idx].stateColor;
      return;
   }
if(Pairs[idx].waitReason == "MON GAP")
{
   if(Pairs[idx].mondayGapBias == GAP_BULL)
      Pairs[idx].stateText = "GAP↑";
   else if(Pairs[idx].mondayGapBias == GAP_BEAR)
      Pairs[idx].stateText = "GAP↓";
   else
      Pairs[idx].stateText = "GAP";

   Pairs[idx].stateColor = tmdOrange;
   Pairs[idx].dotColor   = tmdOrange;
   return;
}


   if(Pairs[idx].highVolatility)
   {
      Pairs[idx].stateText  = "VOL";
      Pairs[idx].stateColor = tmdOrange;
      Pairs[idx].dotColor   = tmdOrange;
      return;
   }

   if(Pairs[idx].direction == -1 || !Pairs[idx].aligned)
   {
      Pairs[idx].stateColor = tmdOrange;
      Pairs[idx].dotColor   = (Pairs[idx].direction == -1 ? tmdSilver : tmdOrange);
   }
   else
   {
      Pairs[idx].stateColor = tmdSilver;
      Pairs[idx].dotColor   = tmdRed;
   }
}

string PairFilterText(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return "-";

   if(!brokerWindowOpen)
      return "BROKER";
      
   if(!Pairs[idx].marketOpen)
      return "CLOSED";
      
   if(Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buyDamageState == BDS_EXIT_ONLY)
      return "EXIT BUY";

   if(Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellDamageState == BDS_EXIT_ONLY)
      return "EXIT SELL";

   if(Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buyDamageState == BDS_CRITICAL)
      return "CRT BUY";

   if(Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellDamageState == BDS_CRITICAL)
      return "CRT SELL";

   if(Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buyExpansionFrozenByInvalidation)
      return "INV BUY";

   if(Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellExpansionFrozenByInvalidation)
      return "INV SELL";
      
   if(Pairs[idx].direction == -1)
      return "NO DIR";

   if(!Pairs[idx].aligned)
      return "CUR MIS";



   if(Pairs[idx].comp < InpMinScore)
      return "COMP";

   if(Pairs[idx].accel < InpMinAccel)
      return "ACC";
   if(Pairs[idx].accel > InpMaxAccel)
      return "ACC";   
   if(Pairs[idx].edgePullback < InpMinPB)
      return "PB";       
   if(InpUseLocationFilter && !Pairs[idx].locationOk)
      return "LOC";
   if(Pairs[idx].slope < InpMinSl) 
      return "SLP";
  if(Pairs[idx].edgeRegime < InpMinReg) 
      return "REG";
  if (Pairs[idx].edgeScore < InpMinEdgeScore) { 
      return "EDGE";
      
  }              
   if(InpUseRiskProtection)
   {
      if(gEmergencyClose)
         return "EMERG";
      if(gFreezeNewEntries)
         return "FROZEN";
      if(IsExposureTooHigh())
         return "EXPOS";
      if(!SpreadAcceptable(Pairs[idx].symbol, InpMaxSpreadPoints))
         return "SPREAD";
   }
      if(Pairs[idx].adaptiveState == AGS_BLOCK)
      return "AD BLOCK";

   if(Pairs[idx].adaptiveState == AGS_STRESS)
      return "AD STR";

   if(Pairs[idx].adaptiveState == AGS_CAUTION)
      return "AD CAUT";
   if(Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buyDamageState == BDS_DAMAGED)
      return "DMG BUY";

   if(Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellDamageState == BDS_DAMAGED)
      return "DMG SELL";

   if(Pairs[idx].buyGrid.CountPositions() > 0 && Pairs[idx].buySoftThrottle)
      return "THR BUY";

   if(Pairs[idx].sellGrid.CountPositions() > 0 && Pairs[idx].sellSoftThrottle)
      return "THR SELL";
      
   if(!Pairs[idx].filtersValid)
      return "LOAD";

   if(Pairs[idx].waitReason == "RO DIR" ||
      Pairs[idx].waitReason == "RO ACC" ||
      Pairs[idx].waitReason == "RO CMP" ||
      Pairs[idx].waitReason == "RISKOFF" ||
      Pairs[idx].waitReason == "RO CD" ||
      Pairs[idx].waitReason == "THRTL")
      return Pairs[idx].waitReason;

   if(Pairs[idx].waitReason == "MON GAP")
   {
      if(Pairs[idx].mondayGapBias == GAP_BULL)
         return "GAP BULL";
      if(Pairs[idx].mondayGapBias == GAP_BEAR)
         return "GAP BEAR";
      return "MON GAP";
   }

   if(HasEntryTrigger(idx))
      return "TRIG";

   if(Pairs[idx].direction == ORDER_TYPE_BUY)
   {
      if(Pairs[idx].rsiBuyOk && Pairs[idx].bbBuyOk) return "SET";
      if(!Pairs[idx].rsiBuyOk) return "RSI";
      if(!Pairs[idx].bbBuyOk)  return "BB";
      return "WAIT";
   }

   if(Pairs[idx].direction == ORDER_TYPE_SELL)
   {
      if(Pairs[idx].rsiSellOk && Pairs[idx].bbSellOk) return "SET";
      if(!Pairs[idx].rsiSellOk) return "RSI";
      if(!Pairs[idx].bbSellOk)  return "BB";
      return "WAIT";
   }

   return "-";
}

color PairFilterColor(int idx)
{
   if(idx < 0 || idx >= PairSize)
      return tmdSilver;

   string txt = PairFilterText(idx);

   if(txt == "TRIG")    return tmdGreen;
   if(txt == "SET")     return C'0,190,190';
   if(txt == "RSI")     return tmdOrange;
   if(txt == "BB")      return tmdOrange;

   if(txt == "TREND")   return tmdRed;
   if(txt == "CUR MIS") return tmdOrange;
   if(txt == "ACC")     return tmdOrange;
   if(txt == "COMP")    return tmdOrange;
   if(txt == "LOC")     return tmdOrange;
   if(txt == "SPREAD")  return tmdOrange;
   if(txt == "WAIT")    return tmdOrange;

   if(txt == "RO DIR")  return tmdRed;
   if(txt == "RO ACC")  return tmdOrange;
   if(txt == "RO CMP")  return tmdOrange;
   if(txt == "RISKOFF") return tmdRed;
   if(txt == "RO CD")   return tmdOrange;

   if(txt == "EMERG")   return tmdRed;
   if(txt == "FROZEN")  return tmdOrange;
   if(txt == "EXPOS")   return tmdOrange;
   if(txt == "MON GAP") return tmdOrange;
   if(txt == "GAP BULL") return tmdOrange;
   if(txt == "GAP BEAR") return tmdOrange;

   if(txt == "BROKER")  return tmdSilver;
   if(txt == "CLOSED")  return tmdSilver;
   if(txt == "NO DIR")  return tmdSilver;
   if(txt == "LOAD")    return tmdOrange;
   if(txt == "N/A")     return tmdSilver;
   
   if(txt == "THR BUY")  return tmdOrange;
   if(txt == "THR SELL") return tmdOrange;
   if(txt == "THRTL")   return tmdOrange;
   
      if(txt == "AD CAUT")  return tmdOrange;
   if(txt == "AD STR")   return C'255,120,0';
   if(txt == "AD BLOCK") return tmdRed;
   
   if(txt == "INV BUY")  return tmdOrange;
   if(txt == "INV SELL") return tmdOrange;
   return tmdSilver;
}

void HandleTMDPanelChartClick(int x, int y)
{
   if(!InpShowPanel)
      return;

   int tableX1   = 28;
   int tableX2   = 830;
   int firstRowY = 343;
   int rowH      = 14;

   if(x < tableX1 || x > tableX2)
      return;

   if(y < firstRowY)
      return;

   int row = (y - firstRowY) / rowH;

   if(row < 0 || row >= PANEL_SYM_ROWS)
      return;

   int sortedIdx[];
   GetSortedPairIndicesForPanel(sortedIdx);

   if(row >= ArraySize(sortedIdx))
      return;

   int p = sortedIdx[row];
   string sym = Pairs[p].symbol;

   if(sym == "")
      return;

   if(Symbol() != sym)
      ChartSetSymbolPeriod(0, sym, (ENUM_TIMEFRAMES)Period());
}

void GetTradeStats(int &wins, int &losses,
                   double &winRate,
                   double &profitFactor,
                   string &avgHoldText)
{
   winRate = 0.0;
   profitFactor = 0.0;
   avgHoldText = "-";

   if(!HistorySelect(0, TimeCurrent()))
      return;

   int deals = (int)HistoryDealsTotal();
   if(deals <= 0)
      return;

   double grossProfit = 0.0;
   double grossLoss   = 0.0;
   wins = 0;
   losses = 0;
   int closedTrades = 0;

   long posIds[];
   datetime entryTimes[];
   ArrayResize(posIds, 0);
   ArrayResize(entryTimes, 0);

   long closePosIds[];
   datetime closeTimes[];
   ArrayResize(closePosIds, 0);
   ArrayResize(closeTimes, 0);

   for(int i = 0; i < deals; i++)
   {
      ulong dealTicket = HistoryDealGetTicket(i);
      if(dealTicket == 0)
         continue;

      long entryType = HistoryDealGetInteger(dealTicket, DEAL_ENTRY);
      long dealType  = HistoryDealGetInteger(dealTicket, DEAL_TYPE);
      long posId     = HistoryDealGetInteger(dealTicket, DEAL_POSITION_ID);
      datetime dt    = (datetime)HistoryDealGetInteger(dealTicket, DEAL_TIME);

      double profit     = HistoryDealGetDouble(dealTicket, DEAL_PROFIT);
      double commission = HistoryDealGetDouble(dealTicket, DEAL_COMMISSION);
      double swap       = HistoryDealGetDouble(dealTicket, DEAL_SWAP);
      double net        = profit + commission + swap;

      bool isTradeDeal = (dealType == DEAL_TYPE_BUY || dealType == DEAL_TYPE_SELL);
      if(!isTradeDeal)
         continue;

      if(entryType == DEAL_ENTRY_IN)
      {
         int n = ArraySize(posIds);
         ArrayResize(posIds, n + 1);
         ArrayResize(entryTimes, n + 1);
         posIds[n] = posId;
         entryTimes[n] = dt;
      }
      else if(entryType == DEAL_ENTRY_OUT || entryType == DEAL_ENTRY_OUT_BY)
      {
         closedTrades++;

         if(net > 0.0)
         {
            wins++;
            grossProfit += net;
         }
         else if(net < 0.0)
         {
            losses++;
            grossLoss += MathAbs(net);
         }

         int n = ArraySize(closePosIds);
         ArrayResize(closePosIds, n + 1);
         ArrayResize(closeTimes, n + 1);
         closePosIds[n] = posId;
         closeTimes[n] = dt;
      }
   }

   if(closedTrades > 0)
      winRate = 100.0 * (double)wins / (double)closedTrades;

   if(grossLoss > 0.0)
      profitFactor = grossProfit / grossLoss;
   else if(grossProfit > 0.0)
      profitFactor = 999.0;
   else
      profitFactor = 0.0;

   long totalHoldSec = 0;
   int holdCount = 0;

   for(int i = 0; i < ArraySize(closePosIds); i++)
   {
      long pid = closePosIds[i];
      datetime closeT = closeTimes[i];

      for(int j = ArraySize(posIds) - 1; j >= 0; j--)
      {
         if(posIds[j] == pid)
         {
            if(closeT >= entryTimes[j])
            {
               totalHoldSec += (long)(closeT - entryTimes[j]);
               holdCount++;
            }
            break;
         }
      }
   }

   if(holdCount > 0)
   {
      long avgSec = totalHoldSec / holdCount;
      int hrs = (int)(avgSec / 3600);
      int mins = (int)((avgSec % 3600) / 60);

      if(hrs > 0)
         avgHoldText = IntegerToString(hrs) + "h " + IntegerToString(mins) + "m";
      else
         avgHoldText = IntegerToString(mins) + "m";
   }
}

color GetFreeMarginColor(double freeMarginPct)
{
   int stopoutMode = (int)AccountInfoInteger(ACCOUNT_MARGIN_SO_MODE);
   double stopoutCall = AccountInfoDouble(ACCOUNT_MARGIN_SO_CALL);
   double stopoutSo   = AccountInfoDouble(ACCOUNT_MARGIN_SO_SO);

   if (freeMarginPct == 0) return tmdSilver;
   if(stopoutCall <= 0.0 && stopoutSo <= 0.0)
   {
      if(freeMarginPct < 25.0) return tmdRed;
      if(freeMarginPct < 50.0) return tmdOrange;
      return tmdGreen;
   }

   if(stopoutMode == ACCOUNT_STOPOUT_MODE_PERCENT)
   {
      double danger = stopoutSo;
      double warn   = MathMax(stopoutCall, danger * 1.5);

      if(freeMarginPct <= warn) return tmdRed;
      if(freeMarginPct <= warn * 1.5) return tmdOrange;
      return tmdGreen;
   }

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(equity <= 0.0)
      return tmdRed;

   double dangerPct = SafeDiv(stopoutSo, equity, 0.0) * 100.0;
   double warnPct   = SafeDiv(stopoutCall, equity, 0.0) * 100.0;

   if(warnPct <= 0.0)
      warnPct = dangerPct * 1.5;

   if(freeMarginPct <= warnPct) return tmdRed;
   if(freeMarginPct <= warnPct * 1.5) return tmdOrange;
   return tmdGreen;
}

color GetLotUsageColor(double lots)
{
   double maxLots = GetDynamicMaxTotalLots();

   if(maxLots <= 0.0)
      return tmdSilver;

   double ratio = SafeDiv(lots, maxLots, 0.0);

   if(ratio >= 1.0) return tmdRed;
   if(ratio >= 0.75) return tmdOrange;
   return tmdGreen;
}

color GetPositionUsageColor(int positions)
{
   if(InpMaxOrders <= 0)
      return tmdSilver;

   double ratio = SafeDiv((double)positions, (double)InpMaxTotalPositions, 0.0);

   if(ratio >= 1.0) return tmdRed;
   if(ratio >= 0.75) return tmdOrange;
   return tmdGreen;
}

void UpdateRiskPanelState()
{
   gRiskStateText    = "NORMAL";
   gRiskStateColor   = tmdGreen;
   gEntryStateText   = "ALLOWED";
   gEntryStateColor  = tmdGreen;
   gExpandStateText  = "ALLOWED";
   gExpandStateColor = tmdGreen;
   gRiskReasonText   = "-";
   gRiskReasonColor  = tmdSilver;

   if(!InpUseRiskProtection)
   {
      gRiskStateText    = "OFF";
      gRiskStateColor   = tmdSilver;
      gEntryStateText   = "UNLIMITED";
      gEntryStateColor  = tmdSilver;
      gExpandStateText  = "UNLIMITED";
      gExpandStateColor = tmdSilver;
      gRiskReasonText   = "PROTECTION DISABLED";
      gRiskReasonColor  = tmdSilver;
      return;
   }

   double ddPct         = GetAccountDDPercent();
   double marginLevel   = GetMarginLevelPercent();
   double freeMarginPct = GetFreeMarginPercent();
   bool exposureHigh    = IsExposureTooHigh();
   bool allowExpand     = AllowGridExpansion();

   if(gEmergencyClose)
   {
      gRiskStateText    = "EMERGENCY";
      gRiskStateColor   = tmdRed;
      gEntryStateText   = "BLOCKED";
      gEntryStateColor  = tmdRed;
      gExpandStateText  = "BLOCKED";
      gExpandStateColor = tmdRed;

      if(InpAccountEmergencyDDPct > 0.0 && ddPct >= InpAccountEmergencyDDPct)
         gRiskReasonText = "ACC DD";
      else if(InpCriticalMarginLevel > 0.0 && marginLevel > 0.0 && marginLevel < InpCriticalMarginLevel)
         gRiskReasonText = "CRIT MARGIN";
      else
         gRiskReasonText = "FORCED CLOSE";

      gRiskReasonColor = tmdRed;
      return;
   }

   if(gFreezeNewEntries)
   {
      gRiskStateText   = "FROZEN";
      gRiskStateColor  = tmdOrange;
      gEntryStateText  = "BLOCKED";
      gEntryStateColor = tmdOrange;

      if(InpAccountFreezeDDPct > 0.0 && ddPct >= InpAccountFreezeDDPct)
               gRiskReasonText = "DD FREEZE";
      else if(InpFreezeMarginLevel > 0.0 && marginLevel > 0.0 && marginLevel < InpFreezeMarginLevel)
         gRiskReasonText = "MARGIN LOW";
      else if(InpFreezeFreeMarginPct > 0.0 && freeMarginPct < InpFreezeFreeMarginPct)
         gRiskReasonText = "FREE MGN LOW";
      else if(exposureHigh)
         gRiskReasonText = "EXPOSURE CAP";
      else
         gRiskReasonText = "RISK FILTER";

      gRiskReasonColor = tmdOrange;
   }

   if(!allowExpand)
   {
      gExpandStateText  = "FROZEN";
      gExpandStateColor = tmdOrange;

      if(gRiskReasonText == "-")
      {
         if(InpFreezeExpansionDD > 0.0 && ddPct >= InpFreezeExpansionDD)
            gRiskReasonText = "NO EXPAND DD";
         else if(InpFreezeExpansionMargin > 0.0 && marginLevel > 0.0 && marginLevel < InpFreezeExpansionMargin)
            gRiskReasonText = "NO EXPAND MGN";
         else if(InpUseVolatilityFilter && InpBlockExpansionOnHighVol == ON)
            gRiskReasonText = "NO EXPAND VOL";
         else
            gRiskReasonText = "EXPANSION OFF";

         gRiskReasonColor = tmdOrange;
      }
   }

   if(gRiskStateText == "NORMAL" && !allowExpand)
   {
      gRiskStateText  = "CAUTION";
      gRiskStateColor = tmdOrange;
   }

   if(gRiskOffActive)
   {
      gRiskStateText  = "RISK OFF";
      gRiskStateColor = tmdRed;

      if(IsSelectiveRiskOffEntryModeActive())
      {
         gEntryStateText  = "SAFE ONLY";
         gEntryStateColor = tmdOrange;
         gRiskReasonText  = "JPY/CHF ONLY";
         gRiskReasonColor = tmdOrange;
      }
      else
      {
         gEntryStateText  = "BLOCKED";
         gEntryStateColor = tmdRed;
         gRiskReasonText  = "MARKET SHOCK";
         gRiskReasonColor = tmdRed;
      }

      if(IsRiskOffBlockingExpansion())
      {
         gExpandStateText  = "BLOCKED";
         gExpandStateColor = tmdRed;
      }
   }
   else if(gRiskOffCooldown)
   {
      gRiskStateText  = "RISK OFF";
      gRiskStateColor = tmdOrange;

      if(IsSelectiveRiskOffEntryModeActive())
      {
         gEntryStateText  = "SAFE ONLY";
         gEntryStateColor = tmdOrange;
         gRiskReasonText  = "COOLDOWN JPY/CHF";
         gRiskReasonColor = tmdOrange;
      }
      else
      {
         gEntryStateText  = "BLOCKED";
         gEntryStateColor = tmdOrange;
         gRiskReasonText  = "COOLDOWN";
         gRiskReasonColor = tmdOrange;
      }

      if(IsRiskOffBlockingExpansion())
      {
         gExpandStateText  = "BLOCKED";
         gExpandStateColor = tmdOrange;
      }
   }
    if(!gEmergencyClose &&
      !gFreezeNewEntries &&
      !gRiskOffActive &&
      !gRiskOffCooldown &&
      InpUsePortfolioPressure == ON &&
      gPortfolioPressureState != PPS_NORMAL)
   {
      gRiskStateText   = "PORTF";
      gRiskStateColor  = gPortfolioPressureColor;
      gRiskReasonText  = gPortfolioPressureReason;
      gRiskReasonColor = gPortfolioPressureColor;

      if(IsPortfolioPressureBlockingNewEntries())
      {
         gEntryStateText  = "BLOCKED";
         gEntryStateColor = gPortfolioPressureColor;
      }
      else
      {
         gEntryStateText  = "ALLOWED";
         gEntryStateColor = tmdGreen;
      }

      if(IsPortfolioPressureBlockingExpansion())
      {
         gExpandStateText  = "BLOCKED";
         gExpandStateColor = gPortfolioPressureColor;
      }
      else
      {
         gExpandStateText  = "ALLOWED";
         gExpandStateColor = tmdGreen;
      }
   }
}

string PanelName(string suffix)
{
   return PANEL_PREFIX + suffix;
}

void RegisterPanelObject(string name)
{
   int sz = ArraySize(gPanelObjects);
   ArrayResize(gPanelObjects, sz + 1);
   gPanelObjects[sz] = name;
}

bool CreatePanelRect(string name, int x, int y, int w, int h, color bg, color border)
{
   string obj = PanelName(name);
   if(!ObjectCreate(0, obj, OBJ_RECTANGLE_LABEL, 0, 0, 0))
      return false;

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, obj, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, obj, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, bg);
   ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, border);
   ObjectSetInteger(0, obj, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, obj, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, obj, OBJPROP_BACK, false);
   ObjectSetInteger(0, obj, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, false);

   RegisterPanelObject(obj);
   return true;
}

bool CreatePanelLabel(string name, int x, int y, int fontSize, color clr,
                      string text, ENUM_ANCHOR_POINT anchor = ANCHOR_LEFT_UPPER)
{
   string obj = PanelName(name);
   if(!ObjectCreate(0, obj, OBJ_LABEL, 0, 0, 0))
      return false;

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, fontSize);
   ObjectSetString(0, obj, OBJPROP_FONT, "Consolas");
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetString(0, obj, OBJPROP_TEXT, text);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, false);

   RegisterPanelObject(obj);
   return true;
}

void SetPanelText(string name, string text, color clr = clrNONE)
{
   string obj = PanelName(name);
   if(ObjectFind(0, obj) < 0)
      return;

   string oldText = ObjectGetString(0, obj, OBJPROP_TEXT);
   if(oldText != text)
      ObjectSetString(0, obj, OBJPROP_TEXT, text);

   if(clr != clrNONE)
   {
      color oldClr = (color)ObjectGetInteger(0, obj, OBJPROP_COLOR);
      if(oldClr != clr)
         ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   }
}

string DirectionToText(int dir)
{
   if(dir == ORDER_TYPE_BUY)  return "BUY ";
   if(dir == ORDER_TYPE_SELL) return "SELL";
   return "----";
}

color DirectionToColor(int dir)
{
   if(dir == ORDER_TYPE_BUY)  return tmdGreen;
   if(dir == ORDER_TYPE_SELL) return tmdRed;
   return tmdSilver;
}


void GetSortedCurrencyIndices(double &strengths[], int &idx[])
{
   ArrayResize(idx, 10);
   for(int i = 0; i < 10; i++)
      idx[i] = i;

   for(int i = 0; i < 9; i++)
   {
      for(int j = i + 1; j < 10; j++)
      {
         if(strengths[idx[j]] > strengths[idx[i]])
         {
            int tmp = idx[i];
            idx[i] = idx[j];
            idx[j] = tmp;
         }
      }
   }
}