﻿input group "=== Risk Protection ===";
input ENUM_ONOFF InpUseRiskProtection      = OFF;

input double     InpFreezeMarginLevel      = 180.0;
input double     InpFreezeFreeMarginPct    = 80.0;
input int        InpMaxTotalPositions      = 50;
input double     InpBaseBalanceForMaxLots  = 1000.0;
input double     InpBaseMaxTotalLots       = 0.25;
input double     InpMinMaxTotalLots        = 0.10;
input double     InpHardMaxTotalLots       = 10.00;
input double     InpMaxFirstOrderMarginPct = 20.0;
input ENUM_ONOFF InpBlockGridExpansion     = ON;
input double     InpFreezeExpansionDD      = 15.0;
input double     InpFreezeExpansionMargin  = 240.0;
input double     InpMaxSpreadPoints        = 12.0;
input double     InpBaseBalanceForTrendExitProfit = 1000.0;
input double     InpBaseTrendExitMinProfit        = 1.50;
input double     InpMinTrendExitProfit            = 0.30;
input double     InpMaxTrendExitProfit            = 100.00;
input group "=== Expansion Control ===";
input bool   InpUseExpansionControl = false;
input double InpMinAccelForExpansion = 5.01;
input double InpMaxStretchM15ForExpansion  = 1.80;
input bool   InpBlockExpansionOnWeakTrend  = false;
input group "=== Volatility Filter ===";
input bool            InpUseVolatilityFilter      = false;          // Enable volatility filter
input ENUM_TIMEFRAMES InpVolatilityTF             = PERIOD_M15;    // ATR timeframe
input int             InpATRPeriod                = 14;            // ATR period
input double          InpMaxATRPoints             = 250.0;         // Max ATR in points
input ENUM_ONOFF      InpBlockNewEntriesOnHighVol = ON;            // Block new entries
input ENUM_ONOFF      InpBlockExpansionOnHighVol  = ON;            // Block grid expansion


bool AllowGridExpansion()
{
   if(IsRiskOffBlockingExpansion())
      return false;
      
   if(IsPortfolioPressureBlockingExpansion())
      return false;
      
   double ddPct       = GetAccountDDPercent();
   double marginLevel = GetMarginLevelPercent();

   if(InpFreezeExpansionDD > 0.0 && ddPct >= InpFreezeExpansionDD)
      return false;

   if(marginLevel > 0.0 && marginLevel < InpFreezeExpansionMargin)
      return false;     

   if(!InpUseRiskProtection)
      return true;

   if(!InpBlockGridExpansion)
      return true;

   return true;
}

bool AllowGridExpansion(int idx, bool isBuyGrid)
{
   if(!AllowGridExpansion())
      return false;

   if(idx < 0 || idx >= PairSize)
      return false;

   BasketDamageState damageState = isBuyGrid ? Pairs[idx].buyDamageState
                                             : Pairs[idx].sellDamageState;

   if(damageState == BDS_EXIT_ONLY && InpFreezeExpansionAtExitOnly)
      return false;

   if(damageState == BDS_CRITICAL && InpFreezeExpansionAtCritical)
      return false;

   if(InpUsePersistentInvalidationExit)
   {
      if(isBuyGrid && Pairs[idx].buyExpansionFrozenByInvalidation)
         return false;

      if(!isBuyGrid && Pairs[idx].sellExpansionFrozenByInvalidation)
         return false;
   }

   if(IsRegimeBlockingExpansion(idx, isBuyGrid))
      return false;

   if(InpUseVolatilityFilter &&
      InpBlockExpansionOnHighVol == ON &&
      Pairs[idx].highVolatility &&
      damageState >= BDS_DAMAGED)
      return false;
      
   int gridDirection = isBuyGrid ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(IsBlockedByMondayGap(Pairs[idx], gridDirection))
      return false;

   // -------------------------------------------------
   // COMMIT 3: expansion-quality gate
   // -------------------------------------------------
   if(InpUseExpansionControl)
   {
      double minAccelNeeded = InpMinAccelForExpansion;
      double maxStretchAllowed = InpMaxStretchM15ForExpansion;

      if(damageState == BDS_DAMAGED)
      {
         minAccelNeeded += 0.20;
         maxStretchAllowed -= 0.15;
      }
      else if(damageState >= BDS_CRITICAL)
      {
         minAccelNeeded += 0.40;
         maxStretchAllowed -= 0.30;
      }

      if(maxStretchAllowed < 0.50)
         maxStretchAllowed = 0.50;

      // 1) Do not expand when current momentum quality is weak
      if(Pairs[idx].accel < minAccelNeeded)
         return false;

      // 2) Do not expand into already-stretched adverse location
      if(isBuyGrid)
      {
         if(Pairs[idx].entryStretchM15 > maxStretchAllowed)
            return false;

         if(InpBlockExpansionOnWeakTrend && Pairs[idx].direction != ORDER_TYPE_BUY)
            return false;
      }
      else
      {
         if(Pairs[idx].entryStretchM15 < -maxStretchAllowed)
            return false;

         if(InpBlockExpansionOnWeakTrend && Pairs[idx].direction != ORDER_TYPE_SELL)
            return false;
      }
   }

   // Soft throttle / damaged-basket cadence: skip every other add when damaged
   if(isBuyGrid)
   {
      int cnt = Pairs[idx].buyGrid.CountPositions();

      if((InpUseSoftAdverseRegime && Pairs[idx].buySoftThrottle) ||
         damageState >= BDS_DAMAGED)
      {
         if(cnt >= 2 && (cnt % 2 == 0))
            return false;
      }
   }
   else
   {
      int cnt = Pairs[idx].sellGrid.CountPositions();

      if((InpUseSoftAdverseRegime && Pairs[idx].sellSoftThrottle) ||
         damageState >= BDS_DAMAGED)
      {
         if(cnt >= 2 && (cnt % 2 == 0))
            return false;
      }
   }

   return true;
}

bool IsPairExpansionFrozen(int idx, bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return true;

   if(isBuyGrid)
   {
      if(Pairs[idx].buyGrid.CountPositions() <= 0)
         return false;

      return !AllowGridExpansion(idx, true);
   }

   if(Pairs[idx].sellGrid.CountPositions() <= 0)
      return false;

   return !AllowGridExpansion(idx, false);
}



bool AllowNewRisk()
{
   if(!InpUseRiskProtection)
   {
      if(IsRiskOffBlockingNewEntries() && !IsSelectiveRiskOffEntryModeActive())
         return false;

      if(IsPortfolioPressureBlockingNewEntries())
         return false;
         
      return true;
   }

   if(gEmergencyClose)
      return false;
   if(gFreezeNewEntries)
      return false;
   if(IsExposureTooHigh())
      return false;

   if(IsRiskOffBlockingNewEntries() && !IsSelectiveRiskOffEntryModeActive())
      return false;
   if(IsPortfolioPressureBlockingNewEntries())
      return false;
   return true;
}

bool AllowNewRiskEntry(const int idx, string &reason)
{
   reason = "";

   if(idx < 0 || idx >= PairSize)
   {
      reason = "IDX";
      return false;
   }

   if(!AllowNewRisk())
   {
      if(gEmergencyClose)
         reason = "EMERG";
      else if(gFreezeNewEntries)
         reason = "FROZEN";
      else if(IsExposureTooHigh())
         reason = "EXPOS";
      else if(gRiskOffActive)
         reason = "RISKOFF";
      else if(gRiskOffCooldown)
         reason = "RO CD";
      else if(IsPortfolioPressureBlockingNewEntries())
         reason = "PORT";
      else
         reason = "RISK";

      return false;
   }

   if(!IsSelectiveRiskOffEntryModeActive())
      return true;

   string roReason = "";
   if(!RP_PassRiskOffDirectionalEntryFilter(Pairs[idx],
                                            true,
                                            InpUseRiskOffDirectionalEntryFilter,
                                            InpRiskOffMinAccel,
                                            InpRiskOffMinComp,
                                            InpBlockSafeHavenVsSafeHaven,
                                            roReason))
   {
      if(roReason == "RiskOff dir blocked") reason = "RO DIR";
      else if(roReason == "RiskOff accel low") reason = "RO ACC";
      else if(roReason == "RiskOff comp low") reason = "RO CMP";
      else reason = "RISKOFF";
      return false;
   }
   string expReason = "";
   if(!PassesCurrencyExposureCaps(Pairs[idx].symbol, expReason))
   {
      reason = expReason;
      return false;
   }
   string adaptiveReason = "";
   if(IsAdaptiveEntryBlocked(idx, adaptiveReason))
   {
      reason = adaptiveReason;
      return false;
   }
   return true;
}

void EvaluateRiskState()
{
   gFreezeNewEntries = false;
   gEmergencyClose   = false;

   if(!InpUseRiskProtection)
      return;

   double ddPct         = GetAccountDDPercent();
   double marginLevel   = GetMarginLevelPercent();
   double freeMarginPct = GetFreeMarginPercent();

   if(InpAccountEmergencyDDPct > 0.0 && ddPct >= InpAccountEmergencyDDPct)
   {
      gEmergencyClose = true;
      return;
   }

   if(InpCriticalMarginLevel > 0.0 &&
      marginLevel > 0.0 &&
      marginLevel < InpCriticalMarginLevel)
   {
      gEmergencyClose = true;
      return;
   }

   if(InpAccountFreezeDDPct > 0.0 &&
      ddPct >= InpAccountFreezeDDPct)
   {
      gFreezeNewEntries = true;
   }

   if(InpFreezeMarginLevel > 0.0 &&
      marginLevel > 0.0 &&
      marginLevel < InpFreezeMarginLevel)
   {
      gFreezeNewEntries = true;
   }

   if(InpFreezeFreeMarginPct > 0.0 &&
      freeMarginPct < InpFreezeFreeMarginPct)
   {
      gFreezeNewEntries = true;
   }

   if(IsExposureTooHigh())
      gFreezeNewEntries = true;
}

bool IsHighVolatility(string symbol, double atrPrice)
{
   if(!InpUseVolatilityFilter)
      return false;

   double atrPoints = ATRToPoints(symbol, atrPrice);

   double maxPts = InpMaxATRPoints;

   if(StringFind(symbol, "XAU") >= 0) maxPts = 3500;
   if(StringFind(symbol, "XAG") >= 0) maxPts = 2200;

   if(maxPts > 0.0 && atrPoints > maxPts)
      return true;

   return false;
}


bool PassesCurrencyExposureCaps(const string symbol, string &reason)
{
   reason = "";

   if(InpUseCurrencyExposureCaps != ON)
      return true;

   string base  = StringSubstr(symbol, 0, 3);
   string quote = StringSubstr(symbol, 3, 3);

   if(InpMaxLivePairsPerCurrency > 0)
   {
      int baseCount  = CountLiveBasketsForCurrency(base);
      int quoteCount = CountLiveBasketsForCurrency(quote);

      if(baseCount >= InpMaxLivePairsPerCurrency)
      {
         reason = base + " CAP";
         return false;
      }

      if(quoteCount >= InpMaxLivePairsPerCurrency)
      {
         reason = quote + " CAP";
         return false;
      }
   }

   if(InpMaxLotsPerCurrency > 0.0)
   {
      double baseLots  = GetLiveLotsForCurrency(base);
      double quoteLots = GetLiveLotsForCurrency(quote);

      if(baseLots >= InpMaxLotsPerCurrency)
      {
         reason = base + " LOT";
         return false;
      }

      if(quoteLots >= InpMaxLotsPerCurrency)
      {
         reason = quote + " LOT";
         return false;
      }
   }

   return true;
}

bool IsPairTrendInvalidatedForExpansion(int idx, bool isBuyGrid)
{
   if(idx < 0 || idx >= PairSize)
      return true;

   if(isBuyGrid && Pairs[idx].direction == ORDER_TYPE_SELL)
      return true;
   if(!isBuyGrid && Pairs[idx].direction == ORDER_TYPE_BUY)
      return true;

   return false;
}
