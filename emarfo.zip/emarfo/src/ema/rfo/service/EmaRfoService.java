package ema.rfo.service;

import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.server.BasePluginService;
import sailpoint.tools.GeneralException;

import javax.validation.constraints.Email;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EmaRfoService extends BasePluginService {

    private Logger log = Logger.getLogger("ema.rfo.EmaRfoService");

    @Override
    public String getPluginName() {
        return "emarfo";
    }

    @Override
    public void execute(SailPointContext context) throws GeneralException {
        log.trace("Entering EmaRfo Service");

        // Go through open change requests in custom object
        Custom custom = context.getObjectByName(Custom.class,"EMA Pending Organization Change Requests");
        if (custom != null) {
            List<String> keysToRemove = new ArrayList<>();
            Attributes<String, Object> atts = custom.getAttributes();
            if (atts != null && !atts.isEmpty()){
                List<String> crs = atts.getKeys();
                if (crs != null && !crs.isEmpty()) {
                    for (String cr:crs) {
                        // Retrieve status of change request
                        log.debug("Checking CR "+cr);
                        // Call OMS API
                        // Get Config
                        Configuration config = context.getConfiguration();
                        CredentialsProvider provider = new BasicCredentialsProvider();
                        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(config.getString("emaOrgRoleSyncUsername"),config.getString("emaOrgRoleSyncPassword"));
                        provider.setCredentials(AuthScope.ANY,credentials);

                        int timeout = 15;
                        RequestConfig requestConfig = RequestConfig.custom()
                                .setConnectTimeout(timeout * 1000)
                                .setConnectionRequestTimeout(timeout * 1000)
                                .setSocketTimeout(timeout * 1000).build();
                        HttpClient httpClient = null;
                        try {
                            httpClient = HttpClientBuilder.create()
                                    .setDefaultCredentialsProvider(provider)
                                    .setDefaultRequestConfig(requestConfig)
                                    .setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build())
                                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                                    .build();
                        } catch (Exception e) {
                            log.error(e.getMessage());
                        }
                        HttpGet httpGet = new HttpGet(cr);
                        httpGet.setHeader("Accept", "application/json");
                        httpGet.setHeader("Content-type", "application/json");
                        log.debug("Executing api: "+ httpGet);
                        HttpResponse httpResponse = null;
                        try {
                            httpResponse = httpClient.execute(httpGet);
                            int statusCode = httpResponse.getStatusLine().getStatusCode();
                            log.debug("Status code: "+statusCode);
                            log.debug("Response: "+httpResponse.getEntity().toString());
                            String responseBody = EntityUtils.toString(httpResponse.getEntity(), StandardCharsets.UTF_8);
                            log.debug("Response body: "+ responseBody);
                            JSONObject responseJson = new JSONObject(responseBody);
                            log.debug("Response json: "+responseJson);
                            JSONObject changeRequestJson = (JSONObject) responseJson.get("change-request-oms");
                            String status = changeRequestJson.getString("status");
                            log.debug("Status: "+status);

                            if ("APPROVED".equals(status)) {
                                Map<String,String> crData = (Map<String, String>) atts.get(cr);
                                if (crData != null) {
                                    String requester = crData.get("requester");
                                    String country = crData.get("country");
                                    String requestId = crData.get("requestId");
                                    // Extra call to get ORG ID
                                    String url = config.getString("emaOrgRoleSyncRESTEndpoint");
                                    if (url != null) {
                                        url = url + "/" + requestId;
                                    }
                                    log.debug("Url: "+url);
                                    HttpGet httGetOrg = new HttpGet(url);
                                    httGetOrg.setHeader("Accept", "application/json");
                                    httGetOrg.setHeader("Content-type", "application/json");
                                    log.debug("Executing api to get org: "+ httGetOrg);
                                    HttpResponse httpResponseOrg = httpClient.execute(httGetOrg);
                                    String responseBodyOrg = EntityUtils.toString(httpResponseOrg.getEntity(), StandardCharsets.UTF_8);
                                    log.debug("Response body org: "+ responseBodyOrg);
                                    JSONObject responseJsonOrg = new JSONObject(responseBodyOrg);
                                    log.debug("Response json org: "+responseJsonOrg);
                                    if (responseJsonOrg.has("organisation")) {
                                        JSONObject orgJson = (JSONObject) responseJsonOrg.get("organisation");
                                        if (orgJson != null) {
                                            if (orgJson.has("organisation-id")) {
                                                JSONObject orgIdJson = (JSONObject) orgJson.get("organisation-id");
                                                if (orgIdJson != null && orgIdJson.has("id")) {
                                                    log.debug("Org ID: "+orgIdJson);
                                                    String orgId = orgIdJson.getString("id");
                                                    if (orgId != null) {
                                                        log.debug("orgid: "+orgId);
                                                        // Check if already synced
                                                        Bundle org = context.getObjectByName(Bundle.class,orgId);
                                                        if (org != null) {
                                                            EmailTemplate template = context.getObjectByName(EmailTemplate.class,"EMA - Organisation Create Request");
                                                            if (template != null) {
                                                                if (requester != null) {
                                                                    Identity requesterIdentity = context.getObjectByName(Identity.class,requester);
                                                                    if (requesterIdentity != null) {
                                                                        String email = requesterIdentity.getEmail();
                                                                        if (email != null) {
                                                                            EmailOptions emailOptions = new EmailOptions();
                                                                            emailOptions.setTo(email);
                                                                            emailOptions.setVariable("username", requesterIdentity.getDisplayableName());
                                                                            emailOptions.setVariable("country",country);
                                                                            emailOptions.setVariable("requestId",requestId);
                                                                            emailOptions.setVariable("organisationId",orgId);
                                                                            Configuration configuration = context.getConfiguration();
                                                                            String serverRootPath = configuration.getString("serverRootPath");
                                                                            String link = serverRootPath + "/plugins/pluginPage.jsf?pn=emarfo&org="+ orgId +"&country="+country;
                                                                            emailOptions.setVariable("link",link);
                                                                            context.sendEmailNotification(template,emailOptions);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            keysToRemove.add(cr);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                }

                            }
                            // If status is APPROVED or REJECTED
                            // if approved send mail with link to plugin with parameter the org id
                            // if rejected do nothing
                            if ( "REJECTED".equals(status) ) {
                                keysToRemove.add(cr);
                            }


                        } catch (Exception e) {
                            log.error(e.getMessage());
                        }
                    }
                }
            }
            if (!keysToRemove.isEmpty()) {
                for (String keyToRemove:keysToRemove) {
                    log.debug("Removing "+keyToRemove);
                    custom.remove(keyToRemove);
                }
                context.saveObject(custom);
                context.commitTransaction();
            }
        }
        log.trace("Exiting EmaRfo Service");
    }
}
