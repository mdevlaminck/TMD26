package ema.rfo.rest;

import org.apache.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.plugin.PluginBaseHelper;
import sailpoint.plugin.PluginContext;
import sailpoint.rest.BaseResource;
import sailpoint.rest.plugin.AllowAll;
import sailpoint.service.AttachmentDTO;
import sailpoint.service.AttachmentService;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import java.io.File;
import java.nio.file.Files;
import java.sql.Connection;



@Path("emarfo")
public class AttachmentResource extends BaseResource implements PluginContext {

    private SailPointContext context;
    private Logger log = Logger.getLogger("ema.fro.EmaRfoAttachmentResource");
    public AttachmentResource() throws GeneralException {
        this.context = SailPointFactory.getCurrentContext();
    }



    @Override
    public String getPluginName() {
        return "emarfo";
    }

    @Override
    public Connection getConnection() throws GeneralException {
        return PluginBaseHelper.getConnection();
    }


    @AllowAll
    @POST
    @Path("attachment")
    @Consumes({"multipart/form-data"})
    public Response saveAttachment(@FormDataParam("file") File file,@FormDataParam("file") FormDataContentDisposition fileInfo ) throws Exception {

        byte[] fileContent = Files.readAllBytes(file.toPath());
        String fileName = fileInfo.getFileName();
        long fileSize = file.length();

        Response response = null;
        AttachmentService svc = new AttachmentService(this);
        int maxFileSizeConfig = svc.getMaxFileSize();
        int maxFileSize = maxFileSizeConfig * 1000 * 1000;

        // Check Size
        if (fileSize > maxFileSize) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("File too big")
                    .build();
        }

        //fileName = svc.sanitizeFileName(fileName);
        
        fileName = svc.truncateFileName(fileName);
        String errs = svc.validateFile(fileName);

        if (Util.isNullOrEmpty(errs)) {
            AttachmentDTO att = svc.createAttachment(fileName, this.getLoggedInUser(), fileContent);
            response = Response.ok(att).build();
        }

        return response;
    }

}
