package ema.rfo.rest;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import sailpoint.api.*;
import sailpoint.integration.ApacheHttpClient;
import sailpoint.integration.ListResult;

import sailpoint.object.*;
import sailpoint.plugin.PluginBaseHelper;
import sailpoint.rest.plugin.AllowAll;
import sailpoint.service.AttachmentDTO;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;
import sailpoint.tools.Util;
import sailpoint.api.ObjectUtil;
import sailpoint.object.Bundle;
import sailpoint.object.Identity;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Path("emarfo")
@AllowAll
public class RolesResource extends EmaRfoBaseResource {

    private Logger log = Logger.getLogger("ema.rfo.RolesResource");
    private final SailPointContext context;

    public RolesResource() throws GeneralException {
        this.context = SailPointFactory.getCurrentContext();
    }



    @AllowAll
    @POST
    @Path("roles")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ListResult getRoles(Map<String, Object> parameters) throws GeneralException, CloneNotSupportedException {
        log.trace("Entering getRoles");
        ListResult listResult = null;

        List<String> selection = (List<String>) parameters.get("selectedOrgs");

        List resultFilters = new ArrayList();
        // 1. Requestable roles

        ObjectConfig bundleConfig = context.getObjectByName(ObjectConfig.class,"Bundle");
        List <String> allowedTypes = new ArrayList();
        if (bundleConfig != null) {
            List <RoleTypeDefinition> roleTypes = bundleConfig.getRoleTypesList();
            if (roleTypes != null && !roleTypes.isEmpty()) {
                for (RoleTypeDefinition roleTypeDefinition:roleTypes) {
                    if (roleTypeDefinition.isManuallyAssignable()) {
                        allowedTypes.add(roleTypeDefinition.getName());
                    }
                }
            }
        }

        resultFilters.add(Filter.in("type",allowedTypes));
        // Only MDM Template
        resultFilters.add(Filter.eq("type","MDM Template"));
        
        // Not disabled
        resultFilters.add(Filter.ne("disabled",true));

        Identity user = context.getObjectByName(Identity.class,context.getUserName());
        if (user != null) {
            log.debug("Identity: "+context.getUserName());

            // 2. Scope
            ScopeService scopeService = new ScopeService(context);
            QueryInfo qi = scopeService.getControlledScopesQueryInfo(user);
            if (qi != null) {
                log.error(qi.toString());
                Filter f = qi.getFilter();
                if (f != null) {
                    log.debug(f.toString());
                    resultFilters.add(f);
                }
            }
        }

        // 3. Classification
        List <Filter> classificationFilters = new ArrayList<>();
        if (selection != null && !selection.isEmpty()) {
            for (String selectedOrg:selection) {
                List <String> allowedClassifications = new ArrayList<>();
                List<Filter> classificationFiltersPerOrg = new ArrayList<>();
                Bundle orgRole = context.getObjectByName(Bundle.class,selectedOrg);
                if (orgRole != null) {
                    String classificationString = (String) orgRole.getAttribute("classification");
                    if (classificationString != null) {
                        allowedClassifications.addAll(Util.csvToList(classificationString));
                    }
                }
                if (!allowedClassifications.isEmpty()) {
                    // org role has classifications - only roles that match
                    // Also roles without classification
                    for (String allowedClassification:allowedClassifications) {
                        classificationFiltersPerOrg.add(Filter.or(Filter.like("classification",allowedClassification, Filter.MatchMode.ANYWHERE),Filter.isnull("classification"), Filter.eq("classification","")));
                    }
                }
                if (!classificationFiltersPerOrg.isEmpty()) {
                    classificationFilters.add(Filter.or(classificationFiltersPerOrg));
                }
            }
        }
        if (!classificationFilters.isEmpty()) {
            Filter classificationFilter = Filter.and(classificationFilters);
            resultFilters.add(classificationFilter);
        }

        Filter resultFilter = Filter.and(resultFilters);
        log.debug(resultFilter.toString());

        QueryOptions qo = new QueryOptions();
        qo.addFilter(resultFilter);
        qo.addOrdering("name",true);

        Set returnSet = new HashSet();

        List <Bundle> roles = context.getObjects(Bundle.class,qo);

        if (roles != null && !roles.isEmpty()) {
            for (Bundle role:roles) {

                // Check if is admin role
                boolean isAdmin = false;
                if (isExternalApproverTemplate(role)){
                    isAdmin = true;
                }



                Map record = new HashMap();
                record.put("roleName",role.getName());
                record.put("roleDisplayName",role.getDisplayableName());

                if (role.getDescription("en_US") != null) {
                    record.put("roleDescription",role.getDescription("en_US"));
                } else {
                    record.put("roleDescription","");
                }

                String app = getRoleApplicationFromName(role.getName());
                String appDisplay = "";
                if (app != null) {
                    Bundle appRole = context.getObjectByName(Bundle.class,app);
                    if (appRole != null) {
                        appDisplay = appRole.getDisplayableName();
                    }
                }
                record.put("isAdmin",isAdmin);
                record.put("app",appDisplay);
                record.put("appliedFilter",resultFilter.getExpression(true));
                returnSet.add(record);
            }
        }
        List returnList = new ArrayList(returnSet);

        listResult = new ListResult(returnList,returnList.size());
        log.trace("Exiting getRoles");
        return listResult;

    }

    @AllowAll
    @POST
    @Path("roles/validate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response validateRoles(Map<String, Object> parameters) throws GeneralException, CloneNotSupportedException, InterruptedException {
        log.trace("Entering validateRoles");
        List<String> selectedRoles = (List<String>) parameters.get("selectedRoles");
        List<String> selectedOrgs = (List<String>) parameters.get("selectedOrgs");
        List<String> attachmentIds = (List<String>) parameters.get("attachmentIds");
        String password = (String) parameters.get("password");
        String Lang = (String) parameters.get("language");

        Map <String,Object> responseMap = new HashMap<>();
        ProvisioningProject project = null;

        List <String> rolesWithLang = new ArrayList<>();
        boolean langMissing = false;
        // First check if language is required
        if (selectedRoles != null) {
            for (String selectedRole:selectedRoles) {
                Bundle role = context.getObjectByName(Bundle.class,selectedRole);
                if (role != null) {
                    Set contexts = getRoleContexts(role);
                    if (contexts != null && contexts.contains("Lang")) {
                        if (Lang == null) {
                            langMissing = true;
                            rolesWithLang.add(role.getDisplayableName());
                        }
                    }
                }
            }
        }

        ProvisioningPlan plan = new ProvisioningPlan();
        if (selectedRoles != null && !selectedRoles.isEmpty()) {
            Identity requesterIdentity = context.getObjectByName(Identity.class,context.getUserName());
            if (requesterIdentity != null) {

                plan.setIdentity(requesterIdentity);

                ProvisioningPlan.AccountRequest accountRequest = new ProvisioningPlan.AccountRequest();
                accountRequest.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                accountRequest.setNativeIdentity(context.getUserName());
                accountRequest.setApplication(ProvisioningPlan.APP_IIQ);

                for (String selectedRole:selectedRoles) {
                    ProvisioningPlan.AttributeRequest attributeRequest = new ProvisioningPlan.AttributeRequest();
                    attributeRequest.setName("assignedRoles");
                    attributeRequest.setValue(selectedRole);
                    attributeRequest.setOp(ProvisioningPlan.Operation.Add);
                    accountRequest.add(attributeRequest);
                }

                plan.add(accountRequest);

            }

        }
        if (!plan.isEmpty()) {
            log.debug("Master Plan: "+plan.toXml());

            // Validate Plan
            // needed ?

            String validationError = validatePlanEuj(plan);
            if (validationError != null) {
                responseMap.put("status",validationError);
                return Response
                        .status(Response.Status.OK)
                        .entity(responseMap)
                        .build();
            }

            // Compile Plan

            Attributes attributes = new Attributes();
            attributes.put("requester",context.getUserName());
            attributes.put("identityName",context.getUserName());
            attributes.put("source","LCM");
            attributes.put("flow","AccessRequest");
            Provisioner provisioner = new Provisioner(context,attributes);
            project = provisioner.compile(plan,attributes);
            project.put("emaSource","EMA_UJ");
            project.put("Org",selectedOrgs);
            if (Lang != null && !"".equals(Lang)) {
                project.put("Lang",Lang);
            }
            if (password != null && !"".equals(password)) {
                project.put("Pw",context.encrypt(password));
            }

            log.debug("Project: "+project.toXml());
            // Add selected orgs and Lang to MDMPermission
            ProvisioningPlan mdmPlan = project.getPlan("MDMPermissionDB");
            if (mdmPlan != null) {
                List<ProvisioningPlan.AccountRequest> mdmRequests = mdmPlan.getAccountRequests();
                if (mdmRequests != null && !mdmRequests.isEmpty()) {
                    for (ProvisioningPlan.AccountRequest mdmRequest:mdmRequests) {
                        ProvisioningPlan.AttributeRequest orgRequest = new ProvisioningPlan.AttributeRequest("Org",ProvisioningPlan.Operation.Add,selectedOrgs);
                        mdmRequest.add(orgRequest);
                        if (Lang != null) {
                            ProvisioningPlan.AttributeRequest langRequest = new ProvisioningPlan.AttributeRequest("Lang",ProvisioningPlan.Operation.Add,Lang);
                            mdmRequest.add(langRequest);
                        }


                    }
                }
            }
            log.error("Added Org: "+project.toXml());

            // Add passwords
            // Add to expansion items
            // Check if there is a question for a password
            List<String> appsWithPassword = new ArrayList<>();
            List<Question> questions = project.getQuestions();
            // todo True for testing - change to false for PRD
            boolean missingPassword = false;
            boolean invalidPassword = false;

            //appsWithPassword.add("Active Directory");

            boolean needPassword = false;

            if (questions != null && !questions.isEmpty()){
                for (Question question:questions) {
                    if("password".equals(question.getAttributeName()) && Question.Type.Application.equals((question.getType()))){
                        needPassword = true;
                        appsWithPassword.add(question.getSource());
                    }
                }
            }

            // Alter project

            project = alterProject(project);

            // Validate altered project
            // check IIQ Assigned roles -> check that for non admin roles there is already an admin

            // isExternalApprover(roleBeingApproved)

            List <String> issues = new ArrayList<>();
            List <String> orgsWithAdminInRequest = new ArrayList<>();
            List <String> rolesAlreadyAssigned = new ArrayList<>();
            Identity identity = context.getObject(Identity.class,context.getUserName());

            ProvisioningPlan masterPlan = project.getMasterPlan();
            if (masterPlan != null) {
                List <ProvisioningPlan.AccountRequest> iiqRequests = masterPlan.getAccountRequests(ProvisioningPlan.APP_IIQ);
                if (iiqRequests != null && !iiqRequests.isEmpty()) {
                    for (ProvisioningPlan.AccountRequest iiqRequest:iiqRequests) {
                        List <ProvisioningPlan.AttributeRequest> attRequests = iiqRequest.getAttributeRequests("assignedRoles");
                        if (attRequests != null && !attRequests.isEmpty()) {
                            for (ProvisioningPlan.AttributeRequest attributeRequest:attRequests){
                                if (ProvisioningPlan.Operation.Add.equals(attributeRequest.getOperation())) {
                                    Bundle newRole = context.getObjectByName(Bundle.class, (String) attributeRequest.getValue());
                                    if (newRole != null) {
                                        if (identity != null && identity.getActiveRoleAssignments(newRole.getName()) != null && !identity.getActiveRoleAssignments(newRole.getName()).isEmpty() ) {
                                            rolesAlreadyAssigned.add(newRole.getDisplayableName());
                                        }
                                        if (!isExternalApprover(newRole)){
                                            // Check members of owner workgroup
                                            Identity roleOwner = newRole.getOwner();
                                            if (roleOwner != null && roleOwner.isWorkgroup()) {
                                                // refresh workgroup
                                                getApprovalWorkgroupRequirements(roleOwner);
                                                List properties = new ArrayList();
                                                properties.add("name");
                                                Iterator members = ObjectUtil.getWorkgroupMembers(context,roleOwner,properties);
                                                if (!members.hasNext()) {
                                                    // Check if org role workgroup has members
                                                    Bundle orgRole = context.getObjectByName(Bundle.class, getOrgFromRoleName(newRole.getName()));
                                                    if (orgRole != null) {
                                                        Identity orgOwner = orgRole.getOwner();
                                                        if (orgOwner != null && orgOwner.isWorkgroup()) {
                                                            Iterator orgMembers = ObjectUtil.getWorkgroupMembers(context,orgOwner,properties);
                                                            if (!orgMembers.hasNext()) {
                                                                issues.add(newRole.getName());
                                                            }
                                                        }
                                                    }
                                                }
                                            }


                                        } else {
                                            orgsWithAdminInRequest.add(getRoleApplicationFromName(newRole.getName())+getOrgFromRoleName(newRole.getName()));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (!rolesAlreadyAssigned.isEmpty()){
                String message = "The following roles are already assigned: "+Util.listToCsv(rolesAlreadyAssigned);
                responseMap.put("status",message);
                return Response
                        .status(Response.Status.OK)
                        .entity(responseMap)
                        .build();
            }

            if (!issues.isEmpty()) {
                for(String roleName:issues) {
                    if(!orgsWithAdminInRequest.contains(getRoleApplicationFromName(roleName)+getOrgFromRoleName(roleName))) {
                        String message = "There is no "+getRoleApplicationFromName(roleName)+" user administrator assigned to "+getOrgFromRoleName(roleName)+". Your organisation must have one or more users who have been granted user admin role to approve such requests. Please select "+getRoleApplicationFromName(roleName)+" user admin role.";
                        responseMap.put("status",message);
                        return Response
                                .status(Response.Status.OK)
                                .entity(responseMap)
                                .build();
                    }
                }
            }
            List<String> status = new ArrayList<>();
            String passwordError = "";

            if (needPassword) {
                if(Util.isNullOrEmpty(password)){
                    missingPassword = true;
                } else {
                    // Check password valid
                    List <Message> errors = new ArrayList<>();
                    try {
                        PasswordPolicy oidPolicy=context.getObjectByName(PasswordPolicy.class, "OID Password Policy");
                        if (oidPolicy != null) {
                            PasswordPolice pp = new PasswordPolice(context, oidPolicy);
                            pp.checkPassword(null,password,false);
                        }

                    }
                    catch (PasswordPolicyException ppe) {
                        errors.addAll(ppe.getAllMessages());
                    }
                    if (!errors.isEmpty()) {
                        invalidPassword = true;
                        for (Message error:errors){
                            passwordError = passwordError + error.getMessage() + ". ";
                        }
                    }
                }


            }




            // Check attachments needed - if needed return response to go to step 4

            Map attachmentsNeeded = checkAttachmentsNeeded(project);
            boolean needAttachment = false;
            //Todo - for testing to be commented
            //  attachmentsNeeded.put("MDM Template 1","org1");
            //  attachmentsNeeded.put("role2","org2");
            if (!attachmentsNeeded.isEmpty() && attachmentIds.isEmpty()) {
                needAttachment = true;
            }

            if (needAttachment || missingPassword || invalidPassword || langMissing) {

                if (needAttachment) {
                    status.add("AttachmentNeeded");
                    responseMap.put("attachmentsNeeded",attachmentsNeeded);

                }
                if (missingPassword) {
                    status.add("PasswordNeeded");
                    responseMap.put("passwordNeeded",appsWithPassword);
                    responseMap.put("passwordError","Password is required");
                }
                if (invalidPassword) {
                    status.add("PasswordNeeded");
                    responseMap.put("passwordNeeded",appsWithPassword);
                    responseMap.put("passwordError",passwordError);
                }

                if (langMissing) {
                    status.add("LangMissing");
                    responseMap.put("langNeeded",rolesWithLang);
                }
                responseMap.put("status",Util.listToCsv(status));
                return Response
                        .status(Response.Status.OK)
                        .entity(responseMap)
                        .build();
            }


            // Create Identity Request - launch workflow and wait until we have identityRequestId ?
            // https://community.sailpoint.com/t5/IdentityIQ-Wiki/Launching-a-Workflow-using-Code/ta-p/81276

            HashMap<String,Object> launchArgsMap = new HashMap<>();
            if (project != null) {

                masterPlan = project.getMasterPlan();

                // Add attachments
                List attachmentDTOS = new ArrayList();
                for (String attIds:attachmentIds) {
                    Attachment attachment = context.getObjectById(Attachment.class, attIds);
                    if (attachment != null) {
                        attachmentDTOS.add(new AttachmentDTO(attachment));
                    }
                }
                if (masterPlan != null && !attachmentDTOS.isEmpty()) {
                    ProvisioningPlan.AccountRequest iiqRequest = masterPlan.getIIQAccountRequest();
                    List <ProvisioningPlan.AttributeRequest> assignedRolesRequests = iiqRequest.getAttributeRequests("assignedRoles");
                    if (assignedRolesRequests != null && !assignedRolesRequests.isEmpty()) {
                        for (ProvisioningPlan.AttributeRequest assignedRolesRequest:assignedRolesRequests){
                            Object assignedRoleObject = assignedRolesRequest.getValue();
                            if (assignedRoleObject instanceof String) {
                                String assignedRoleName = (String) assignedRoleObject;
                                if (attachmentsNeeded.containsKey(assignedRoleName)) {
                                    iiqRequest.addArgument("attachments",attachmentDTOS);
                                    break;
                                }
                            } else if (assignedRoleObject instanceof List){
                                List <String> assignedRoleList = (List) assignedRoleObject;
                                for (String assignedRoleName:assignedRoleList) {
                                    if (attachmentsNeeded.containsKey(assignedRoleName)) {
                                        iiqRequest.addArgument("attachments",attachmentDTOS);
                                        break;
                                    }
                                }

                            }
                        }
                    }

                }

                launchArgsMap.put("plan",project.getMasterPlan());
            }
            launchArgsMap.put("flow","AccessRequest");
            launchArgsMap.put("identityName",context.getUserName());
            launchArgsMap.put("source","LCM");
            launchArgsMap.put("project",project);
            launchArgsMap.put("attachmentIds",attachmentIds);
            launchArgsMap.put("attachmentsNeeded",attachmentsNeeded);

            Workflow wf = (Workflow)context.getObjectByName(Workflow.class,"LCM Provisioning - Request Access For Organisation");
            WorkflowLaunch wflaunch = new WorkflowLaunch();
            wflaunch.setWorkflowName(wf.getName());
            wflaunch.setWorkflowRef(wf.getName());
            wflaunch.setCaseName("Request Access For Organisation by "+context.getUserName()+" - "+new Date());
            wflaunch.setVariables(launchArgsMap);
            Workflower workflower = new Workflower(context);
            WorkflowLaunch launch = workflower.launch(wflaunch);

            TimeUnit.MILLISECONDS.sleep(60);
            // Try to get identityrequest id
            WorkflowCase workflowCase = launch.getWorkflowCase();
            if (workflowCase != null) {
                String identityRequestId = (String) workflowCase.get("identityRequestId");
                if (identityRequestId == null) {
                    // Try a second time
                    TimeUnit.MILLISECONDS.sleep(100);
                    workflowCase = launch.getWorkflowCase();
                    identityRequestId = (String) workflowCase.get("identityRequestId");
                }
                responseMap.put("status","OK");
                responseMap.put("identityRequestId",identityRequestId);
            }

        }

        return Response
                .status(Response.Status.OK)
                .entity(responseMap)
                .build();

    }

    public void processAssignedEntitlements(ProvisioningPlan masterPlan, Map contextMap) throws GeneralException {

        if(masterPlan != null) { // There should always be a master plan
            List  <ProvisioningPlan.AccountRequest> mdmAcctReqs = masterPlan.getAccountRequests("MDMPermissionDB");
            // track any AttributeRequests to remove (as it's tricky to remove them while iterating)
            List toRemove = new ArrayList();
            for (ProvisioningPlan.AccountRequest mdmAcctReq : mdmAcctReqs){
                List <ProvisioningPlan.AttributeRequest> attrReqs = mdmAcctReq.getAttributeRequests("APPLICATION_PERMISSION");
                for(ProvisioningPlan.AttributeRequest attrReq : attrReqs) {
                    toRemove.add(attrReq);
                    Object value = attrReq.getValue();
                    if(value instanceof String){
                        value = Util.otol(value);
                    }
                    if (value instanceof List){
                        value = addEntitlementContext((List) value, contextMap);
                    }

                    attrReq.setName("CONTEXT_PERMISSION");
                    attrReq.setValue(value);
                }
            }
            log.trace("END processAssignedEntitlements"+masterPlan.toXml());
        }
    }

    public  void addContextToAccountRequest(ProvisioningPlan plan, Map contextMap) throws GeneralException {

        Logger LOG = Logger.getLogger("ema.addcontexttoaccountrequest");
        if(LOG.isDebugEnabled()) LOG.debug("Adding context to EV Account Request");

        List <String> orgs = Util.otol(contextMap.get("Org"));

        List <ProvisioningPlan.AccountRequest> requests = plan.getAccountRequests();
        List <ProvisioningPlan.AccountRequest> requestsToRemove = new ArrayList<>();
        List <ProvisioningPlan.AccountRequest> requestsToAdd = new ArrayList<>();

        if(LOG.isDebugEnabled()) LOG.debug("Found "+requests.size()+" requests.");

        for(ProvisioningPlan.AccountRequest req : requests){

            // Only add context to create requests (updates/disables/deletes will have the correct nativeId already)

            if(req.getOperation() == ProvisioningPlan.AccountRequest.Operation.Create){

                for (String org:orgs) {
                    ProvisioningPlan.AccountRequest newRequest = (ProvisioningPlan.AccountRequest) req.deepCopy(context);
                    String nativeIdentity = newRequest.getNativeIdentity();
                    if (!nativeIdentity.contains("@"+org)) {
                        nativeIdentity = nativeIdentity + "@" + org;
                    }

                    if(LOG.isDebugEnabled()) LOG.debug("Setting native identity: "+nativeIdentity);

                    newRequest.setNativeIdentity(nativeIdentity);

                    ProvisioningPlan.AttributeRequest organisation = new ProvisioningPlan.AttributeRequest("OMS_ORG", ProvisioningPlan.Operation.Set, org);

                    if(LOG.isDebugEnabled()) LOG.debug("Adding AttributeRequest:");
                    if(LOG.isDebugEnabled()) LOG.debug(organisation.toXml());

                    newRequest.add(organisation);

                    if(LOG.isDebugEnabled()) LOG.debug("Finished adding context to this request.");

                    requestsToAdd.add(newRequest);
                    requestsToRemove.add(req);

                }

            }else{

                if(LOG.isDebugEnabled()) LOG.debug(req.getNativeIdentity()+" request is not a create - ignoring.");

            }
        }

        if (requestsToRemove != null && !requestsToRemove.isEmpty()) {
            for (ProvisioningPlan.AccountRequest requestToRemove:requestsToRemove) {
                plan.remove(requestToRemove);
            }
        }
        if (requestsToAdd != null && !requestsToAdd.isEmpty()) {
            for (ProvisioningPlan.AccountRequest requestToAdd:requestsToAdd) {
                plan.add(requestToAdd);
            }
        }


        if(LOG.isDebugEnabled()) LOG.debug("Done addContextToAccountRequest!"+plan.toXml());
    }
    public ProvisioningProject alterProjectAfterApproval(ProvisioningProject project) throws GeneralException, CloneNotSupportedException {

        Logger LOG = Logger.getLogger("ema.alterproject");

        // Get the master plan (i.e what was originally requested)
        ProvisioningPlan masterPlan = project.getMasterPlan();

        // Get the compiled MDMPermissionDB plan in order to extract the requested contexts.
        ProvisioningPlan mdmPlan = project.getPlan("MDMPermissionDB");
        Map <String,Object> contextMap = new HashMap();
        /*
        contextMap.put("Org",project.get("Org"));
        if(project.get("Lang") != null) {
            contextMap.put("Lang",project.get("Lang"));
        }
        */

        if(mdmPlan != null){ // Only need to alter the project if it contains MDM permissions


            contextMap = getRequestedContexts(mdmPlan);


            // Process the master plan to identify MDM
            // roles that need to be converted to shadow roles.
            //replaceAssignedRoles(project,masterPlan, contextMap);
            // Substitute any exceptions
            //processAssignedEntitlements(mdmPlan, contextMap);

            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - MDMPermissionDB:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());

        }

        // Add password
        List<String> appsWithPassword = new ArrayList<>();
        List<Question> questions = project.getQuestions();

        if (questions != null && !questions.isEmpty()){
            for (Question question:questions) {
                if("password".equals(question.getAttributeName()) && Question.Type.Application.equals((question.getType()))){
                    appsWithPassword.add(question.getSource());
                }
            }
        }
        for (String appName:appsWithPassword) {
            ProvisioningPlan appPlan = project.getPlan(appName);
            if (appPlan != null) {
                List <ProvisioningPlan.AccountRequest> appAccountRequests = appPlan.getAccountRequests();
                if (appAccountRequests != null && !appAccountRequests.isEmpty()) {
                    for (ProvisioningPlan.AccountRequest appAccountRequest:appAccountRequests) {
                        if (ProvisioningPlan.AccountRequest.Operation.Create.equals(appAccountRequest.getOperation())) {
                            ProvisioningPlan.AttributeRequest attributeRequest = new ProvisioningPlan.AttributeRequest("password", ProvisioningPlan.Operation.Set,project.get("Pw"));
                            Attributes atts = new Attributes();
                            atts.put("secret",true);
                            attributeRequest.setArgs(atts);
                            appAccountRequest.add(attributeRequest);
                            ExpansionItem newItem = new ExpansionItem();
                            newItem.setApplication(appName);
                            newItem.setCause(ExpansionItem.Cause.ProvisioningPolicy);
                            newItem.setName("password");
                            newItem.setNativeIdentity(appAccountRequest.getNativeIdentity());
                            newItem.setOperation(ProvisioningPlan.Operation.Set);
                            newItem.setSourceInfo(appName);
                            newItem.setValue(project.get("Pw"));
                            project.addExpansionItem(newItem);
                        }
                    }
                }
            }
        }

        // Add context to an EV HD account requests
        ProvisioningPlan evHdPlan = project.getPlan("EV HD");
        if(null != contextMap && null != evHdPlan){
            addContextToAccountRequest(evHdPlan, contextMap);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV HD:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }

        ProvisioningPlan evHdVetPlan = project.getPlan("EV HD VET");
        if(null != contextMap && null != evHdVetPlan){
            addContextToAccountRequest(evHdVetPlan, contextMap);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV HD VET:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }
        ProvisioningPlan evXcompPlan = project.getPlan("EV XCOMP");
        if(null != contextMap && null != evXcompPlan){
            Map contextMapx = contextMap;
            if ("EVHUMAN".equals(contextMapx.get("Org"))) contextMapx.put("Org", "EVTEST");
            if ("EVHUMANWT".equals(contextMapx.get("Org"))) contextMapx.put("Org", "EVTESTWT");
            addContextToAccountRequest(evXcompPlan, contextMapx);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV XCOMP:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }

        ProvisioningPlan evYcompPlan = project.getPlan("EV VET XCOMP");
        if(null != contextMap && null != evYcompPlan){
            Map contextMapy = contextMap;
            if ("EVVETPROD".equals(contextMapy.get("Org"))) contextMapy.put("Org", "EVVETT");
            if ("EVVETPRODBL".equals(contextMapy.get("Org"))) contextMapy.put("Org", "EVVETTBL");
            addContextToAccountRequest(evYcompPlan, contextMapy);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV VET XCOMP:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }
        // Unfilter QPPV/L2B remove operations

        List filteredRequests = project.getFiltered();

        if(filteredRequests != null){

            if(LOG.isDebugEnabled()) LOG.debug("Filtered Requests: "+filteredRequests.size());

            Iterator it = filteredRequests.iterator();

            while(it.hasNext()){

                ProvisioningPlan.AbstractRequest request = (ProvisioningPlan.AbstractRequest) it.next();

                if(LOG.isDebugEnabled()) LOG.debug(request.toXml());

                if("EV HD".equals(request.getApplication())){

                    if(LOG.isDebugEnabled()) LOG.debug("EV HD Request");


                    List <ProvisioningPlan.AttributeRequest> attrReqs = request.getAttributeRequests();
                    List <ExpansionItem> expansionItems = project.getExpansionItems();

                    String orgId = getOrgFromRoleName(request.getSourceRole());
                    String nativeId = project.getIdentity()+"@"+orgId;

                    boolean unfilter = false;

                    for(ProvisioningPlan.AttributeRequest attr : attrReqs){

                        if("EU_QPPV".equals(attr.getName()) || "ENABLE_L2B".equals(attr.getName())){

                            unfilter = true;

                            if(LOG.isDebugEnabled()) LOG.debug(attr.getName()+" - add expansion item for attribute");

                            ExpansionItem item = new ExpansionItem("EV HD", null, nativeId, attr.getName(), attr.getValue(), ProvisioningPlan.Operation.Remove, ExpansionItem.Cause.Role, request.getSourceRole());
                            expansionItems.add(item);

                        }

                    }

                    if(unfilter){

                        if(LOG.isDebugEnabled()) LOG.debug("EU_QPPV - unfiltering account request");

                        if(evHdPlan == null){

                            if(LOG.isDebugEnabled()) LOG.debug("Create EV HD Plan");

                            evHdPlan = new ProvisioningPlan();
                            evHdPlan.setTargetIntegration("EV HD");
                            project.add(evHdPlan);

                        }

                        if(LOG.isDebugEnabled()) LOG.debug("Adding to EV HD plan");
                        if (request instanceof ProvisioningPlan.AccountRequest) {
                            ProvisioningPlan.AccountRequest myRequest = (ProvisioningPlan.AccountRequest) request;
                            myRequest.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                            myRequest.setNativeIdentity(nativeId);
                            evHdPlan.add((ProvisioningPlan.AccountRequest) request);
                        }

                        it.remove();

                    }

                }

            }
        }



        // If a new external EV AD account is being created, extract the password and set it in
        // ECD.

        String identityName = project.getIdentity();
        Identity identity = context.getObjectByName(Identity.class, identityName);

        syncNewAdPassToECD(project, identity);


        /*
         * EV HD Account Disable Logic
         * When the last EV role for a given organisation is removed the corresponding EV
         * account should be disabled. This code identifies the scenario and adds an account
         * request to the plan to disable the appropriate EV account.
         */

        // Get a map of org to EV role removals
        Map <String,Object> evRoleRemovals = getEVRoleOperations(masterPlan, ProvisioningPlan.Operation.Remove);
        Map <String,Object> evVETRoleRemovals = getEVVETRoleOperations(masterPlan, ProvisioningPlan.Operation.Remove);

        boolean allEVRolesRemoved = true;
        boolean allEVVETRolesRemoved = true;

        for(Map.Entry entry : evRoleRemovals.entrySet()){

            String org = (String) entry.getKey();
            List roles = (List) entry.getValue();
            if(LOG.isDebugEnabled()) LOG.debug("Project has "+roles.size()+" role(s) for "+org+" to remove");


            // See if any of the number of assigned roles for this org is equal to the number being removed.
            List userRoles = getEVAssignedRoles(identity, org);
            if(LOG.isDebugEnabled()) LOG.debug(identity.getName()+" has "+userRoles.size()+" assigned role(s) for "+org);

            if(userRoles.size() == roles.size()){

                if(LOG.isDebugEnabled()) LOG.debug("Number of assignedRoles for "+org+" equals number being removed");

                Map <String,List> evRoleAdds = getEVRoleOperations(masterPlan, ProvisioningPlan.Operation.Add);

                if(evRoleAdds.get(org) == null || evRoleAdds.get(org).size() == 0){

                    if(LOG.isDebugEnabled()) LOG.debug("No roles being added for "+org+" so accounts for this org should be disabled");

                    IdentityService idSvc = new IdentityService(context);
                    Application evHd = context.getObjectByName(Application.class, "EV HD");

                    List <Link> evLinks = idSvc.getLinks(identity, evHd);

                    for(Link link : evLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV HD");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }
                    Application evHdx = context.getObjectByName(Application.class, "EV XCOMP");

                    List <Link> evxLinks = idSvc.getLinks(identity, evHdx);

                    for(Link link : evxLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV XCOMP");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }
                }else{
                    if(LOG.isDebugEnabled()) LOG.debug("Roles being added for "+org+" so account should not be disabled");
                    allEVRolesRemoved = false;
                }
            }else{
                if(LOG.isDebugEnabled()) LOG.debug("Some roles remain for "+org+" so account should not be disabled");
                allEVRolesRemoved = false;
            }

        }

        for(Map.Entry entry : evVETRoleRemovals.entrySet()){

            String org = (String) entry.getKey();
            List roles = (List) entry.getValue();
            if(LOG.isDebugEnabled()) LOG.debug("Project has "+roles.size()+" role(s) for "+org+" to remove");

            // See if any of the number of assigned roles for this org is equal to the number being removed.
            List userRoles = getEVVETAssignedRoles(identity, org);
            if(LOG.isDebugEnabled()) LOG.debug(identity.getName()+" has "+userRoles.size()+" assigned role(s) for "+org);

            if(userRoles.size() == roles.size()){

                if(LOG.isDebugEnabled()) LOG.debug("Number of assignedRoles for "+org+" equals number being removed");

                Map<String,List> evRoleAdds = getEVVETRoleOperations(masterPlan, ProvisioningPlan.Operation.Add);

                if(evRoleAdds.get(org) == null || evRoleAdds.get(org).size() == 0){

                    if(LOG.isDebugEnabled()) LOG.debug("No roles being added for "+org+" so accounts for this org should be disabled");

                    IdentityService idSvc = new IdentityService(context);
                    Application evHd = context.getObjectByName(Application.class, "EV HD VET");

                    List <Link> evLinks = idSvc.getLinks(identity, evHd);

                    for(Link link : evLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV HD VET");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }

                    Application evHdx = context.getObjectByName(Application.class, "EV VET XCOMP");

                    List <Link> evxLinks = idSvc.getLinks(identity, evHdx);

                    for(Link link : evxLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV VET XCOMP");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }
                }else{

                    allEVVETRolesRemoved = false;
                }
            }else{

                allEVVETRolesRemoved = false;
            }

        }
        // Remove questions
        project.setQuestions(new ArrayList());

        log.debug("Altered Project: "+project.toXml());
        return project;
    }

    public ProvisioningProject alterProject(ProvisioningProject project) throws GeneralException, CloneNotSupportedException {

        Logger LOG = Logger.getLogger("ema.alterproject");

        // Get the master plan (i.e what was originally requested)
        ProvisioningPlan masterPlan = project.getMasterPlan();

        // Get the compiled MDMPermissionDB plan in order to extract the requested contexts.
        ProvisioningPlan mdmPlan = project.getPlan("MDMPermissionDB");
        Map <String,Object> contextMap = new HashMap();
        /*
        contextMap.put("Org",project.get("Org"));
        if(project.get("Lang") != null) {
            contextMap.put("Lang",project.get("Lang"));
        }
        */

        if(mdmPlan != null){ // Only need to alter the project if it contains MDM permissions


            contextMap = getRequestedContexts(mdmPlan);


            // Process the master plan to identify MDM
            // roles that need to be converted to shadow roles.
            replaceAssignedRoles(project,masterPlan, contextMap);
            // Substitute any exceptions
            processAssignedEntitlements(mdmPlan, contextMap);

            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - MDMPermissionDB:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());

        }

        // Add password
        List<String> appsWithPassword = new ArrayList<>();
        List<Question> questions = project.getQuestions();

        if (questions != null && !questions.isEmpty()){
            for (Question question:questions) {
                if("password".equals(question.getAttributeName()) && Question.Type.Application.equals((question.getType()))){
                    appsWithPassword.add(question.getSource());
                }
            }
        }
        for (String appName:appsWithPassword) {
            ProvisioningPlan appPlan = project.getPlan(appName);
            if (appPlan != null) {
                List <ProvisioningPlan.AccountRequest> appAccountRequests = appPlan.getAccountRequests();
                if (appAccountRequests != null && !appAccountRequests.isEmpty()) {
                    for (ProvisioningPlan.AccountRequest appAccountRequest:appAccountRequests) {
                        if (ProvisioningPlan.AccountRequest.Operation.Create.equals(appAccountRequest.getOperation())) {
                            ProvisioningPlan.AttributeRequest attributeRequest = new ProvisioningPlan.AttributeRequest("password", ProvisioningPlan.Operation.Set,project.get("Pw"));
                            Attributes atts = new Attributes();
                            atts.put("secret",true);
                            attributeRequest.setArgs(atts);
                            appAccountRequest.add(attributeRequest);
                            ExpansionItem newItem = new ExpansionItem();
                            newItem.setApplication(appName);
                            newItem.setCause(ExpansionItem.Cause.ProvisioningPolicy);
                            newItem.setName("password");
                            newItem.setNativeIdentity(appAccountRequest.getNativeIdentity());
                            newItem.setOperation(ProvisioningPlan.Operation.Set);
                            newItem.setSourceInfo(appName);
                            newItem.setValue(project.get("Pw"));
                            project.addExpansionItem(newItem);
                        }
                    }
                }
            }
        }

        // Add context to an EV HD account requests
        ProvisioningPlan evHdPlan = project.getPlan("EV HD");
        if(null != contextMap && null != evHdPlan){
            addContextToAccountRequest(evHdPlan, contextMap);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV HD:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }

        ProvisioningPlan evHdVetPlan = project.getPlan("EV HD VET");
        if(null != contextMap && null != evHdVetPlan){
            addContextToAccountRequest(evHdVetPlan, contextMap);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV HD VET:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }
        ProvisioningPlan evXcompPlan = project.getPlan("EV XCOMP");
        if(null != contextMap && null != evXcompPlan){
            Map contextMapx = contextMap;
            if ("EVHUMAN".equals(contextMapx.get("Org"))) contextMapx.put("Org", "EVTEST");
            if ("EVHUMANWT".equals(contextMapx.get("Org"))) contextMapx.put("Org", "EVTESTWT");
            addContextToAccountRequest(evXcompPlan, contextMapx);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV XCOMP:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }

        ProvisioningPlan evYcompPlan = project.getPlan("EV VET XCOMP");
        if(null != contextMap && null != evYcompPlan){
            Map contextMapy = contextMap;
            if ("EVVETPROD".equals(contextMapy.get("Org"))) contextMapy.put("Org", "EVVETT");
            if ("EVVETPRODBL".equals(contextMapy.get("Org"))) contextMapy.put("Org", "EVVETTBL");
            addContextToAccountRequest(evYcompPlan, contextMapy);
            if(LOG.isDebugEnabled()) LOG.debug("Modified Plan - EV VET XCOMP:");
            if(LOG.isDebugEnabled()) LOG.debug(project.toXml());
        }
        // Unfilter QPPV/L2B remove operations

        List filteredRequests = project.getFiltered();

        if(filteredRequests != null){

            if(LOG.isDebugEnabled()) LOG.debug("Filtered Requests: "+filteredRequests.size());

            Iterator it = filteredRequests.iterator();

            while(it.hasNext()){

                ProvisioningPlan.AbstractRequest request = (ProvisioningPlan.AbstractRequest) it.next();

                if(LOG.isDebugEnabled()) LOG.debug(request.toXml());

                if("EV HD".equals(request.getApplication())){

                    if(LOG.isDebugEnabled()) LOG.debug("EV HD Request");


                    List <ProvisioningPlan.AttributeRequest> attrReqs = request.getAttributeRequests();
                    List <ExpansionItem> expansionItems = project.getExpansionItems();

                    String orgId = getOrgFromRoleName(request.getSourceRole());
                    String nativeId = project.getIdentity()+"@"+orgId;

                    boolean unfilter = false;

                    for(ProvisioningPlan.AttributeRequest attr : attrReqs){

                        if("EU_QPPV".equals(attr.getName()) || "ENABLE_L2B".equals(attr.getName())){

                            unfilter = true;

                            if(LOG.isDebugEnabled()) LOG.debug(attr.getName()+" - add expansion item for attribute");

                            ExpansionItem item = new ExpansionItem("EV HD", null, nativeId, attr.getName(), attr.getValue(), ProvisioningPlan.Operation.Remove, ExpansionItem.Cause.Role, request.getSourceRole());
                            expansionItems.add(item);

                        }

                    }

                    if(unfilter){

                        if(LOG.isDebugEnabled()) LOG.debug("EU_QPPV - unfiltering account request");

                        if(evHdPlan == null){

                            if(LOG.isDebugEnabled()) LOG.debug("Create EV HD Plan");

                            evHdPlan = new ProvisioningPlan();
                            evHdPlan.setTargetIntegration("EV HD");
                            project.add(evHdPlan);

                        }

                        if(LOG.isDebugEnabled()) LOG.debug("Adding to EV HD plan");
                        if (request instanceof ProvisioningPlan.AccountRequest) {
                            ProvisioningPlan.AccountRequest myRequest = (ProvisioningPlan.AccountRequest) request;
                            myRequest.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                            myRequest.setNativeIdentity(nativeId);
                            evHdPlan.add((ProvisioningPlan.AccountRequest) request);
                        }

                        it.remove();

                    }

                }

            }
        }



        // If a new external EV AD account is being created, extract the password and set it in
        // ECD.

        String identityName = project.getIdentity();
        Identity identity = context.getObjectByName(Identity.class, identityName);

        syncNewAdPassToECD(project, identity);


        /*
         * EV HD Account Disable Logic
         * When the last EV role for a given organisation is removed the corresponding EV
         * account should be disabled. This code identifies the scenario and adds an account
         * request to the plan to disable the appropriate EV account.
         */

        // Get a map of org to EV role removals
        Map <String,Object> evRoleRemovals = getEVRoleOperations(masterPlan, ProvisioningPlan.Operation.Remove);
        Map <String,Object> evVETRoleRemovals = getEVVETRoleOperations(masterPlan, ProvisioningPlan.Operation.Remove);

        boolean allEVRolesRemoved = true;
        boolean allEVVETRolesRemoved = true;

        for(Map.Entry entry : evRoleRemovals.entrySet()){

            String org = (String) entry.getKey();
            List roles = (List) entry.getValue();
            if(LOG.isDebugEnabled()) LOG.debug("Project has "+roles.size()+" role(s) for "+org+" to remove");


            // See if any of the number of assigned roles for this org is equal to the number being removed.
            List userRoles = getEVAssignedRoles(identity, org);
            if(LOG.isDebugEnabled()) LOG.debug(identity.getName()+" has "+userRoles.size()+" assigned role(s) for "+org);

            if(userRoles.size() == roles.size()){

                if(LOG.isDebugEnabled()) LOG.debug("Number of assignedRoles for "+org+" equals number being removed");

                Map <String,List> evRoleAdds = getEVRoleOperations(masterPlan, ProvisioningPlan.Operation.Add);

                if(evRoleAdds.get(org) == null || evRoleAdds.get(org).size() == 0){

                    if(LOG.isDebugEnabled()) LOG.debug("No roles being added for "+org+" so accounts for this org should be disabled");

                    IdentityService idSvc = new IdentityService(context);
                    Application evHd = context.getObjectByName(Application.class, "EV HD");

                    List <Link> evLinks = idSvc.getLinks(identity, evHd);

                    for(Link link : evLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV HD");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }
                    Application evHdx = context.getObjectByName(Application.class, "EV XCOMP");

                    List <Link> evxLinks = idSvc.getLinks(identity, evHdx);

                    for(Link link : evxLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV XCOMP");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }
                }else{
                    if(LOG.isDebugEnabled()) LOG.debug("Roles being added for "+org+" so account should not be disabled");
                    allEVRolesRemoved = false;
                }
            }else{
                if(LOG.isDebugEnabled()) LOG.debug("Some roles remain for "+org+" so account should not be disabled");
                allEVRolesRemoved = false;
            }

        }

        for(Map.Entry entry : evVETRoleRemovals.entrySet()){

            String org = (String) entry.getKey();
            List roles = (List) entry.getValue();
            if(LOG.isDebugEnabled()) LOG.debug("Project has "+roles.size()+" role(s) for "+org+" to remove");

            // See if any of the number of assigned roles for this org is equal to the number being removed.
            List userRoles = getEVVETAssignedRoles(identity, org);
            if(LOG.isDebugEnabled()) LOG.debug(identity.getName()+" has "+userRoles.size()+" assigned role(s) for "+org);

            if(userRoles.size() == roles.size()){

                if(LOG.isDebugEnabled()) LOG.debug("Number of assignedRoles for "+org+" equals number being removed");

                Map<String,List> evRoleAdds = getEVVETRoleOperations(masterPlan, ProvisioningPlan.Operation.Add);

                if(evRoleAdds.get(org) == null || evRoleAdds.get(org).size() == 0){

                    if(LOG.isDebugEnabled()) LOG.debug("No roles being added for "+org+" so accounts for this org should be disabled");

                    IdentityService idSvc = new IdentityService(context);
                    Application evHd = context.getObjectByName(Application.class, "EV HD VET");

                    List <Link> evLinks = idSvc.getLinks(identity, evHd);

                    for(Link link : evLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV HD VET");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }

                    Application evHdx = context.getObjectByName(Application.class, "EV VET XCOMP");

                    List <Link> evxLinks = idSvc.getLinks(identity, evHdx);

                    for(Link link : evxLinks){

                        if(org.equals(link.getAttribute("OMS_ORG"))){

                            // This link should be disabled.
                            if(LOG.isDebugEnabled()) LOG.debug(link.getNativeIdentity()+" belongs to this org so should be disabled");

                            ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                            req.setNativeIdentity(link.getNativeIdentity());
                            req.setApplication("EV VET XCOMP");
                            req.setOperation(ProvisioningPlan.AccountRequest.Operation.Disable);

                            masterPlan.add(req);

                        }
                    }
                }else{

                    allEVVETRolesRemoved = false;
                }
            }else{

                allEVVETRolesRemoved = false;
            }

        }
        // Remove questions
        project.setQuestions(new ArrayList());

        log.debug("Altered Project: "+project.toXml());
        return project;
    }

    public void syncNewAdPassToECD(ProvisioningProject proj, Identity id) throws GeneralException {
        Logger LOG = Logger.getLogger("ema.syncEVADPasswords");
        if(LOG.isDebugEnabled()) LOG.debug("Syncing EV AD Passwords");

        if(LOG.isDebugEnabled()) LOG.debug(proj.toXml());

        String password = null;

        // 1. Check if there is a new EV AD account being created as part of the project
        ProvisioningPlan evAd = proj.getPlan("New External EV AD");

        if(evAd != null){

            if(LOG.isDebugEnabled()) LOG.debug("Got EV AD provisioning plan");

            List <ProvisioningPlan.AccountRequest> accountReqs = evAd.getAccountRequests();

            for(ProvisioningPlan.AccountRequest req : accountReqs){

                if(req.getOperation() == ProvisioningPlan.AccountRequest.Operation.Create){

                    if(LOG.isDebugEnabled()) LOG.debug("Create operation found");

                    ProvisioningPlan.AttributeRequest passAttr = req.getAttributeRequest("password");
                    if(passAttr != null){

                        if(LOG.isDebugEnabled()) LOG.debug("Password Attribute Found");

                        password = (String) passAttr.getValue();

                        break;
                    }
                }

            }

            if(password != null){

                ProvisioningPlan masterPlan = proj.getMasterPlan();

                // 2. Set the ECD account password to match the EV AD password specified.
                if(LOG.isDebugEnabled()) LOG.debug("New External EV AD Account Password found");

                ProvisioningPlan ecdPlan = proj.getPlan("EMA Account");

                if(ecdPlan != null){

                    if(LOG.isDebugEnabled()) LOG.debug("ECD Plan Exists");

                    List <ProvisioningPlan.AccountRequest> accountRequests = ecdPlan.getAccountRequests();

                    for(ProvisioningPlan.AccountRequest req : accountRequests){

                        if(LOG.isDebugEnabled()) LOG.debug("Checking account request");

                        ProvisioningPlan.AttributeRequest passwordReq = req.getAttributeRequest("password");

                        if(passwordReq != null){

                            if(LOG.isDebugEnabled()) LOG.debug("Overwritting password value with EV AD value");

                            passwordReq.setValue(password);

                        }else{

                            if(LOG.isDebugEnabled()) LOG.debug("Adding password attribute to master plan.");
                            req.add(new ProvisioningPlan.AttributeRequest("password", ProvisioningPlan.Operation.Set, password));
                            /*
                            ProvisioningPlan.AccountRequest masterReq = new ProvisioningPlan.AccountRequest();
                            masterReq.setNativeIdentity(req.getNativeIdentity());
                            masterReq.setApplication("EMA Account");
                            masterReq.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                            masterReq.add(new ProvisioningPlan.AttributeRequest("password", ProvisioningPlan.Operation.Set, password));
                            masterPlan.add(masterReq);
                            */


                        }

                    }

                }else{

                    if(LOG.isDebugEnabled()) LOG.debug("No ECD account request found on plan. Creating");

                    IdentityService idSvc = new IdentityService(context);
                    Application ecd = context.getObjectByName(Application.class, "EMA Account");

                    if(LOG.isDebugEnabled()) LOG.debug("Identity: "+id.getName());

                    List<Link> links = idSvc.getLinks(id, ecd);

                    if(LOG.isDebugEnabled()) LOG.debug("Links: "+links.size());

                    for(Link link : links){


                        if(LOG.isDebugEnabled()) LOG.debug("Setting password of: "+link.getNativeIdentity());
                        ProvisioningPlan targetPlan = new ProvisioningPlan();
                        targetPlan.setTargetIntegration(link.getApplicationName());
                        ProvisioningPlan.AccountRequest req = new ProvisioningPlan.AccountRequest();
                        req.setNativeIdentity(link.getNativeIdentity());
                        req.setApplication("EMA Account");
                        req.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                        req.add(new ProvisioningPlan.AttributeRequest("password", ProvisioningPlan.Operation.Set, password));

                        targetPlan.add(req);
                        proj.add(targetPlan);
                    }
                }
            }else{

                if(LOG.isDebugEnabled()) LOG.debug("None to sync.");

            }
        }
    }
    public boolean isSupplementaryRole(String roleName){

        List <String> supplementaryRoleNames = Arrays.asList("EV MAH Additional QPPV","EV L2B Access","EVDAS NCA Administrator","EVDAS NCA Scientific","EVDAS MAH Scientific","EV DDTool","EV Re-coding","EV Outsourced Re-coding","EV EMA Training Management XCOMP","EV PVS-PVR NCA Advanced User","EV PVS-PVR NCA User");
        List <String> supplementaryRoleNamesEVVET = Arrays.asList("EV VET EMA AER Duplicate Detection","EV VET EMA AER Recoding");
        String roleApp = getRoleApplicationFromName(roleName);

        if ("EV".equals(roleApp)){
            for(String suppRole : supplementaryRoleNames){

                if(roleName.contains(suppRole)) return true;

            }
        }
        if ("EVVET".equals(roleApp)){
            for(String suppRole : supplementaryRoleNamesEVVET){

                if(roleName.contains(suppRole)) return true;

            }
        }

        return false;

    }

    private String getRoleApplicationFromName(String roleName) {
        String[] tokens = roleName.split(" ");

        String app = null;

        if(tokens.length > 1){

            app = tokens[0];

        }

        // Catch special case where EVDAS roles do not have EV prefix.
        if("EVDAS".equals(app)) app = "EV";

        return app;
    }
    
    public List getOrgRoleOwnerMembers(String roleName) throws GeneralException {
		Bundle bundle = context.getObjectByName(Bundle.class, roleName);
		List<String> ownerWrkgrpMembers = new ArrayList();
		if(bundle != null) {
			List<Bundle> ownerRoles = bundle.getInheritance();
			for(Bundle orgRole: Util.safeIterable(ownerRoles)) {
				if(orgRole != null && orgRole.getName().toLowerCase().startsWith("org")) {
					log.debug("Owner ORG Role found...");
					Identity orgRoleOwner = orgRole.getOwner();
					if(orgRoleOwner != null) {
						if(orgRoleOwner.isWorkgroup()) {
							log.debug("Role owner workgroup: [" + orgRoleOwner.getName() + "]");
							// get members of the workgroup
							Iterator wrkgrpMemberItr =  ObjectUtil.getWorkgroupMembers(context, orgRoleOwner, Util.csvToList("name"));
							while(wrkgrpMemberItr != null && wrkgrpMemberItr.hasNext()) {
								Object[] memberArray = (Object[])wrkgrpMemberItr.next();
								ownerWrkgrpMembers.add((String) memberArray[0]);
							}

						} else {
							log.debug("Role owner exists: [" + orgRoleOwner.getName() + "] but is NOT a workgroup");
						}
					} else {
						log.error("No owner for role: " + orgRole.getDisplayName());
					}
				}
			}	
		}
		
		return ownerWrkgrpMembers;
	}

    public String validatePlanEuj(ProvisioningPlan plan) throws GeneralException {
        Logger emaLog = Logger.getLogger("com.pwc.ema.rule.ManipulateProjectInherited");

        if(emaLog.isDebugEnabled()) emaLog.debug(plan.toXml());

        List <ProvisioningPlan.AccountRequest> iiqReqs = plan.getAccountRequests();
        List <String> roleNames = new ArrayList();
        List <String> roleNamesRemoved = new ArrayList();
        int evRoles = 0;
        int evBaseRoles = 0;
        int evSuppRoles = 0;
        int evAdminRoles = 0;
        int evRolesRemoved = 0;
        int evvetRoles = 0;
        int evvetBaseRoles = 0;
        int evvetAdminRoles = 0;
        int evvetSuppRoles = 0;
        int evvetRolesRemoved = 0;
        int ncaRoleAdded = 0;
        int nonNcaRoleAdded = 0;
        int contextRoles = 0;
        int templateRoles = 0;


        for(ProvisioningPlan.AccountRequest iiqReq : iiqReqs){
            if(emaLog.isDebugEnabled()) emaLog.debug("Got IIQ Account Request");
            List <ProvisioningPlan.AttributeRequest> assignedRolesRequests = iiqReq.getAttributeRequests("assignedRoles");
            if (assignedRolesRequests != null){
                for (ProvisioningPlan.AttributeRequest assignedRoles:assignedRolesRequests) {
                    if (ProvisioningPlan.Operation.Add.equals(assignedRoles.getOp())){
                        if(assignedRoles != null){
                            if(emaLog.isDebugEnabled()) emaLog.debug("Assigned Roles: "+assignedRoles.toXml());
                            Object values = assignedRoles.getValue();
                            if(values instanceof List){
                                List <String> valueList = (List) values;
                                for(String value : valueList){
                                    roleNames.add(value);
                                }
                            }
                            if(values instanceof String) roleNames.add((String) values);
                        }
                    }

                    if (ProvisioningPlan.Operation.Remove.equals(assignedRoles.getOp())){
                        if(assignedRoles != null){
                            if(emaLog.isDebugEnabled()) emaLog.debug("Assigned Roles: "+assignedRoles.toXml());
                            Object values = assignedRoles.getValue();
                            if(values instanceof List){
                                List <String> valueList = (List<String>) values;
                                for(String value : valueList){
                                    roleNamesRemoved.add(value);
                                }

                            }

                            if(values instanceof String) roleNamesRemoved.add((String) values);

                        }
                    }
                }


            }

        }
        if(roleNames.size() > 1){
            for(String value : roleNames){

                Bundle role = context.getObjectByName(Bundle.class, value);

                if(role != null){
                    if(role.getName().contains("NCA")){
                        ncaRoleAdded++;
                    }else{
                        nonNcaRoleAdded++;
                    }

                    if("EV".equals(getRoleApplicationFromName(role.getName()))){

                        if(emaLog.isDebugEnabled()) emaLog.debug(role.getName()+" is an EV role.");

                        if (isSupplementaryRole(role.getName())){
                            evSuppRoles++;
                        }else{
                            evBaseRoles++;
                        }

                        if (isExternalApprover(role)){
                            if(emaLog.isDebugEnabled()) emaLog.debug(role.getName()+" is an EV admin role.");
                            evAdminRoles++;
                        }

                        evRoles++;

                    }

                    if("EVVET".equals(getRoleApplicationFromName(role.getName()))){

                        if(emaLog.isDebugEnabled()) emaLog.debug(role.getName()+" is an EV VET role.");

                        if (isSupplementaryRole(role.getName())){
                            evvetSuppRoles++;
                        }else{
                            evvetBaseRoles++;
                        }
                        if (isExternalApprover(role)){
                            evvetAdminRoles++;
                            if(emaLog.isDebugEnabled()) emaLog.debug(role.getName()+" is an EV VET admin role.");
                        }

                        evvetRoles++;

                    }
                    if("MDM Template".equals(role.getType())) {templateRoles++; }
                    if("MDM Contextless".equals(role.getType())) {contextRoles++;}

                }
            }
        }

        if(roleNamesRemoved.size() > 1){
            for(String value : roleNamesRemoved){

                Bundle role = context.getObjectByName(Bundle.class, value);

                if(role != null){

                    if("EV".equals(getRoleApplicationFromName(role.getName()))){

                        if(emaLog.isDebugEnabled()) emaLog.debug(role.getName()+" is an EV role.");

                        evRolesRemoved++;

                    }

                    if("EVVET".equals(getRoleApplicationFromName(role.getName()))){

                        if(emaLog.isDebugEnabled()) emaLog.debug(role.getName()+" is an EV VET role.");

                        evvetRolesRemoved++;

                    }

                }
            }
        }

        if(evBaseRoles > 1 || evvetBaseRoles > 1){
            if(evBaseRoles > 2 || evvetBaseRoles > 2) {
                return "You cannot request multiple EV base roles in the same request";
            } else {
                if (evBaseRoles == 2 && evAdminRoles == 0) {
                    return "You cannot request multiple EV base roles in the same request";
                }
                if (evvetBaseRoles == 2 && evvetAdminRoles == 0) {
                    return "You cannot request multiple EV base roles in the same request";
                }

            }

        }

        if(evBaseRoles > 0 && evSuppRoles > 0){

            return "You can't request EV base roles and additional roles in the same request";

        }

        if(evvetBaseRoles > 0 && evvetSuppRoles > 0){

            return "You can't request EV base roles and additional roles in the same request";


        }

        if(evRoles > 0 && evRolesRemoved > 0){

            return "You cannot remove and add EV roles in the same request";


        }

        if(evvetRoles > 0 && evvetRolesRemoved > 0){

            return "You cannot remove and add EV roles in the same request";


        }

        if(ncaRoleAdded > 0 && nonNcaRoleAdded > 0){

            return "You cannot add Regulatory (NCA) and non Regulatory (Industry) roles in the same request";


        }
        if(templateRoles > 0 && contextRoles > 0){

            return "You cannot request a role in behalf of an organisation and an individual role in the same request. Please create a separate request for each role";


        }
        return null;

    }

    private boolean isExternalApprover(Bundle role) {
        boolean isExternalApprover = false;
        if(role.getAssignedScope() != null && !("Internal".equals(role.getAssignedScope().getName()))){
            List <String> mdmEntitlements = getRoleEntitlements(role, "MDMPermissionDB", "CONTEXT_PERMISSION");
            for(String ent : mdmEntitlements){
                if(ent.startsWith("IAM/") && ent.contains("_GRANT_")) return true;
            }
        }

        return isExternalApprover;
    }

    private boolean isExternalApproverTemplate(Bundle role) {
        boolean isExternalApprover = false;
        if(role.getAssignedScope() != null && !("Internal".equals(role.getAssignedScope().getName()))){
            List <String> mdmEntitlements = getRoleEntitlements(role, "MDMPermissionDB", "APPLICATION_PERMISSION");
            for(String ent : mdmEntitlements){
                if(ent.startsWith("IAM/") && ent.contains("_GRANT_")) return true;
            }
        }

        return isExternalApprover;
    }

    private List<String> getRoleEntitlements(Bundle role, String app, String attribute) {
        List <String> entitlements = new ArrayList();
        List <Profile> profiles = role.getProfiles();
        for(Profile profile : profiles) {
            if(app.equals(profile.getApplication().getName())) {
                List <Filter> filters = profile.getConstraints();
                for(Filter filter : filters) {
                    if(filter instanceof Filter.LeafFilter) {
                        Filter.LeafFilter leaf = (Filter.LeafFilter) filter;
                        if(attribute.equals(leaf.getProperty())) {
                            if(Filter.LogicalOperation.CONTAINS_ALL.equals(leaf.getOperation())) {
                                entitlements.addAll((Collection) leaf.getValue());
                            }
                            else if(Filter.LogicalOperation.EQ.equals(leaf.getOperation())) {
                                String ent = (String) leaf.getValue();
                                entitlements.add(ent);
                            }
                        }
                    }
                }
            }
        }
        return entitlements;
    }

    String getContextType(String entitlementName) throws GeneralException {

        ManagedAttribute entitlement = ManagedAttributer.get(context, context.getObjectByName(Application.class, "MDMPermissionDB"), "APPLICATION_PERMISSION", entitlementName);
        if(entitlement == null) {
            return null;
        }

        String contextType = (String) entitlement.getAttribute("context-type");
        if(contextType == null) {
            return null;
        }

        return contextType;

    }

    public Set getRoleContexts(Bundle role) throws GeneralException {
        Set contextTypes = new HashSet();
        List <String> entitlements = getRoleEntitlements(role, "MDMPermissionDB", "APPLICATION_PERMISSION");
        for(String entitlementName : entitlements) {
            String contextType = getContextType(entitlementName);
            if(contextType != null) {
                contextTypes.add(contextType);
            }
        }
        // for testing , to be commented
        // contextTypes.add("Lang");
        // contextTypes.add("Org");
        return contextTypes;
    }

    public Map getRequestedContexts(ProvisioningPlan mdmPlan){

        Map contextMap = new HashMap();

        // The context attributes will already have been compiled into an MDMPermissionDB account request
        List <ProvisioningPlan.AccountRequest> acctReqs = mdmPlan.getAccountRequests("MDMPermissionDB");

        for(ProvisioningPlan.AccountRequest acctReq : acctReqs) { // Only one request should really be present.

            // Get list of attribute requests for this account request. Any that are not
            // "CONTEXT_PERMISSION" are assumed to be Context Type:Value pairs.

            List attrReqs = acctReq.getAttributeRequests();

            Iterator it = attrReqs.iterator();
            while(it.hasNext()) {
                ProvisioningPlan.AttributeRequest attrReq = (ProvisioningPlan.AttributeRequest) it.next();

                if(!(attrReq.getName().equals("APPLICATION_PERMISSION") || attrReq.getName().equals("CONTEXT_PERMISSION"))){ // If not a ?_PERMISSION, assume this is a new contextType
                    if (attrReq.getValue() instanceof String ) {
                        contextMap.put(attrReq.getName(), (String) attrReq.getValue()); // store it in the context map
                    } else if (attrReq.getValue() instanceof List ) {
                        contextMap.put(attrReq.getName(), (List) attrReq.getValue()); // store it in the context map
                    }
                }
            }
        }

        return contextMap;
    }

    public void replaceAssignedRoles(ProvisioningProject project, ProvisioningPlan masterPlan, Map contextMap) throws GeneralException, CloneNotSupportedException {

        List processedRoles = new ArrayList();

        List <String> orgs = Util.otol(contextMap.get("Org"));
        List <Bundle> shadowRoles = new ArrayList();
        if(masterPlan != null) { // There should always be a master plan

            // Loop through the IIQ account requests looking for any assignedRoles attributes requests.
            List <ProvisioningPlan.AccountRequest> iiqAcctReqs = masterPlan.getAccountRequests("IIQ");
            for(ProvisioningPlan.AccountRequest acctReq : iiqAcctReqs) {

                // track any AttributeRequests to remove (as it's tricky to remove them while iterating)
                List <ProvisioningPlan.AttributeRequest> toRemove = new ArrayList();


                List <ProvisioningPlan.AttributeRequest> attrReqs = acctReq.getAttributeRequests("assignedRoles");
                for(ProvisioningPlan.AttributeRequest attrReq : attrReqs) {
                    if(attrReq.getOperation().equals(ProvisioningPlan.Operation.Add)) { // only process Add assignedRoles
                        // find the role being assigned
                        Object value = attrReq.getValue();
                        if(value instanceof String){
                            Bundle role = context.getObjectByName(Bundle.class, (String) attrReq.getValue());
                            if("MDM Template".equals(role.getType())) { // If MDM role requested directly
                                // Remove role from the request
                                toRemove.add(attrReq);
                                // Add to list of shadow roles
                                for (String org:orgs) {
                                    Map singleMap = contextMap;
                                    singleMap.put("Org",org);
                                    shadowRoles.add(createShadowRole(role, singleMap));
                                }

                            }else{
                                // This role may require an MDM role which will not be in the request but
                                // we need to identify this in order to create an appropriate shadow role
                                Collection <Bundle> requiredRoles = role.getFlattenedRequirements();

                                for(Bundle reqrole : requiredRoles) {

                                    if ("MDM Template".equals(reqrole.getType())) {

                                        for (String org:orgs) {
                                            Map singleMap = contextMap;
                                            singleMap.put("Org",org);
                                            shadowRoles.add(createShadowRole(reqrole, singleMap));
                                        }
                                    }

                                }
                            }
                        }else if (value instanceof List){
                            List <String> valueList = (List) value;
                            for(String item : valueList){
                                Bundle role = context.getObjectByName(Bundle.class, item);
                                if("MDM Template".equals(role.getType())) { // If MDM role requested directly
                                    // Remove role from the request
                                    toRemove.add(attrReq);
                                    // Add to list of shadow roles
                                    for (String org:orgs) {
                                        Map singleMap = contextMap;
                                        singleMap.put("Org",org);
                                        shadowRoles.add(createShadowRole(role, singleMap));
                                    }

                                }else{
                                    // This role may require an MDM role which will not be in the request but
                                    // we need to identify this in order to create an appropriate shadow role
                                    Collection <Bundle> requiredRoles = role.getFlattenedRequirements();

                                    for(Bundle reqrole : requiredRoles) {

                                        if ("MDM Template".equals(reqrole.getType())) {
                                            for (String org:orgs) {
                                                Map singleMap = contextMap;
                                                singleMap.put("Org",org);
                                                shadowRoles.add(createShadowRole(reqrole, singleMap));
                                            }
                                        }

                                    }
                                }
                            }
                        }

                    }
                }

                // now remove any processed attribute requests
                for(ProvisioningPlan.AttributeRequest remove : toRemove) {
                    acctReq.remove(remove);

                }

                // and re-add requests for the shadowRoles
                for(Bundle shadowRole : shadowRoles) {
                    if (shadowRole!=null){
                        ProvisioningPlan.AttributeRequest assignRole = new ProvisioningPlan.AttributeRequest("assignedRoles", ProvisioningPlan.Operation.Add, shadowRole.getName());
                        acctReq.add(assignRole);
                    }
                }
            }

        }
        // Replace also in target plan
        if (!shadowRoles.isEmpty()) {
            List<ProvisioningPlan.AccountRequest> newRequests = new ArrayList<>();
            ProvisioningPlan.AccountRequest accountRequest = new ProvisioningPlan.AccountRequest();
            accountRequest.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
            accountRequest.setApplication(ProvisioningPlan.APP_IIQ);
            accountRequest.setNativeIdentity(project.getIdentity());
            for (Bundle shadowRole:shadowRoles) {
                accountRequest.add(new ProvisioningPlan.AttributeRequest("assignedRoles", ProvisioningPlan.Operation.Add, shadowRole.getName()));
            }
            newRequests.add(accountRequest);
            ProvisioningPlan iiqPlan = project.getPlan("IIQ");
            iiqPlan.setAccountRequests(newRequests);

        }
    }

    public Bundle createShadowRole(Bundle role, Map contextMap) throws GeneralException, CloneNotSupportedException {
        Logger LOG = Logger.getLogger("ema.shadowrole");
        Application mdm = context.getObjectByName(Application.class, "MDMPermissionDB");

        Set <String> roleContexts = getRoleContexts(role);
        String shadowRoleDisplayName = role.getDisplayableName();
        String shadowRoleName = role.getName();
        String approvalWorkgroupName = role.getName();
        Bundle orgRole = null;
        for (String roleContext : roleContexts){
            if(roleContext != null){
                if(roleContext.equals("Org")) {
                    orgRole = context.getObjectByName(Bundle.class, (String) contextMap.get(roleContext));
                    if (orgRole != null){
                        shadowRoleDisplayName = shadowRoleDisplayName + " (" +orgRole.getDisplayableName()+")";
                        shadowRoleName = shadowRoleName + "_"+roleContext+"/"+contextMap.get(roleContext);
                        approvalWorkgroupName = approvalWorkgroupName + " (" +orgRole.getName()+")";
                    }else{
                        shadowRoleDisplayName = shadowRoleDisplayName + " ("+contextMap.get(roleContext)+")";
                        shadowRoleName = shadowRoleName + "_"+roleContext+"/"+contextMap.get(roleContext);
                        approvalWorkgroupName = approvalWorkgroupName + " (" +contextMap.get(roleContext)+")";
                    }
                }
                else{
                    shadowRoleDisplayName = shadowRoleDisplayName + " ("+contextMap.get(roleContext)+")";
                    shadowRoleName = shadowRoleName + "_"+roleContext+"/"+contextMap.get(roleContext);
                    approvalWorkgroupName = approvalWorkgroupName + " (" +contextMap.get(roleContext)+")";
                }
            }
        }
        if (shadowRoleName.toLowerCase().contains("_org/null") || shadowRoleName.toLowerCase().contains("_org/na")) return null;
        Bundle shadowRole = null;
        shadowRole = context.getObjectByName(Bundle.class, shadowRoleName);
        if(LOG.isDebugEnabled())
            LOG.debug("Checking for Shadow Role: "+shadowRoleDisplayName+" ("+shadowRoleName+")");
        if(shadowRole == null) {

            if(LOG.isDebugEnabled())
                LOG.debug("Role doesn't exist, creating role...");

            List mdmEntitlements = addEntitlementContext(getRoleEntitlements(role, "MDMPermissionDB", "APPLICATION_PERMISSION"), contextMap);

            Filter.LeafFilter mdmFilter = new Filter.LeafFilter();
            mdmFilter.setOperation(Filter.LogicalOperation.CONTAINS_ALL);
            mdmFilter.setProperty("CONTEXT_PERMISSION");
            mdmFilter.setValue(mdmEntitlements);
            if(LOG.isDebugEnabled())
                LOG.debug("MDM Filter: "+mdmFilter.getExpression());

            Profile mdmProfile = new Profile();
            mdmProfile.setApplication(mdm);
            mdmProfile.addConstraint(mdmFilter);

            shadowRole = new Bundle();
            shadowRole.setName(shadowRoleName);
            shadowRole.setDisplayName(shadowRoleDisplayName.substring(0,Math.min(128, shadowRoleDisplayName.length())));
            shadowRole.setType("MDM Context");
            shadowRole.add(mdmProfile);
            shadowRole.setAssignedScope(role.getAssignedScope());
            shadowRole.setAttribute("Approval_Required",true);
            shadowRole.setAttribute("classification",role.getAttribute("classification"));
            shadowRole.setAccountSelectorRules(role.getAccountSelectorRules());

            ArrayList inheritedRoles = new ArrayList(1);
            inheritedRoles.add(role);
            if(orgRole != null) inheritedRoles.add(orgRole);
            shadowRole.setInheritance(inheritedRoles);

            // Create a new workgroup to own this role and populate it appropriately
            Identity workgroup = context.getObjectByName(Identity.class, approvalWorkgroupName + " Approvers");

            if(workgroup == null){
                workgroup = new Identity();
                workgroup.setName(approvalWorkgroupName + " Approvers");
                workgroup.setWorkgroup(true);
                context.startTransaction();
                context.saveObject(workgroup);
                context.commitTransaction();
            }

            // Get the application and grant class of the template role to determine
            // what permission is required to approve this role

            String app = getRoleApplicationFromName(role.getName());
            String grantClass = (String) role.getAttribute("Grant Class");
            String grantPermission = null;

            if(app != null && grantClass != null) {
                shadowRole.setAttribute("Grant Class", grantClass);
                grantPermission = "cn="+app+"_grant_"+grantClass+",dc=oraclesso,dc=apps,dc=ecd,dc=emea,dc=eu,dc=int";
                if (orgRole != null){
                    grantPermission = "IAM/"+app +"_GRANT_"+grantClass+"/Org/"+orgRole.getName();
                }
            }
            else {
                grantPermission = null;
            }

            // Change the above code to always set the workgorup as the owner and rely on new ApprovalAssignment rule to handle
            // scenarios where the workgroup is empty.
            if(grantPermission != null){
                int members = refreshApprovalWorkgroup(workgroup, null, orgRole, grantPermission);
            }
            shadowRole.setOwner(workgroup);


            commitRole(shadowRole);
        }
        else {
            if(LOG.isDebugEnabled())
                LOG.debug("Role already exists.");
        }

        return shadowRole;
    }
    public void commitRole(Bundle role) throws GeneralException {
        if(role.getId() == null){
            context.startTransaction();
            context.saveObject(role);
            context.commitTransaction();
        }
    }
    public List addEntitlementContext(List entitlements, Map contextMap) throws GeneralException {
        Logger LOG = Logger.getLogger("ema.addEntitlementContext");
        if(LOG.isDebugEnabled())
            LOG.debug("addEntitlementContext");

        List returnList = new ArrayList();

        for(int i=0; i < entitlements.size(); i++) {

            // Context Permissions are a combination of App and Permission
            if(LOG.isDebugEnabled())
                LOG.debug("Adding context info to " + entitlements.get(i));

            String contextType = getContextType((String) entitlements.get(i));

            // construct the new context specific entitlement name using the context type
            // and (hopefully) a value for that type stored in the contextType map
            if (contextType != null && !contextType.equals("Simple")){
                List <String> contextValues = Util.otol(contextMap.get(contextType));
                if (contextValues != null) {
                    for (String contextValue : contextValues) {
                        String permissionContext = "/" + contextType + "/" + contextValue;
                        returnList.add(entitlements.get(i) + permissionContext);
                        if (LOG.isDebugEnabled())
                            LOG.debug("Set value to " + entitlements.get(i) + permissionContext);

                    }
                }
            }

        }


        return returnList;
    }

    int refreshApprovalWorkgroup(Identity workgroup, Bundle role, Bundle orgRole, String requiredPermission) throws GeneralException, CloneNotSupportedException {
        Logger mdmliblog = Logger.getLogger("ema.refreshApprovalWorkgroup");
        int noOfMembers = 0;

        /*
         * Find identities who are currently in the WorkGroup for
         * approving this role.
         */

        List currentWorkgroupMembers = new ArrayList();

        if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Searching");
        Iterator memberNames = ObjectUtil.getWorkgroupMembers(context, workgroup, Arrays.asList(new String[] { "name" }));
        if(mdmliblog.isDebugEnabled()) mdmliblog.debug("hasNext: "+memberNames.hasNext());

        while(memberNames.hasNext()){

            Object[] objectArray = (Object[]) memberNames.next();
            String name = (String) objectArray[0];
            Identity id = context.getObjectByName(Identity.class, name);
            if(mdmliblog.isDebugEnabled()) mdmliblog.debug(id.getName()+" is in workgroup "+workgroup.getName());
            currentWorkgroupMembers.add(id);
            noOfMembers++;
        }


        /*
         * Find identities who should be in the WorkGroup for
         * approving this role.
         */

        List validWorkgroupMembers = new ArrayList();


        // Find Identities who hold the Grant Class permission and are in the organisation context.

        String searchApp = "EMA Account";
        String searchAttribute = "groups";
        boolean checkInheritance = true;
        if (!requiredPermission.startsWith("cn=")) {
            checkInheritance = false;
            searchApp = "MDMPermissionDB";
            searchAttribute = "CONTEXT_PERMISSION";
        }
        QueryOptions qo = new QueryOptions();
        ArrayList andFilters = new ArrayList();
        andFilters.add(Filter.eq("application.name",searchApp));
        andFilters.add(Filter.eq("name",searchAttribute));
        andFilters.add(Filter.ignoreCase(Filter.eq("value",requiredPermission)));
        andFilters.add(Filter.eq("aggregationState", IdentityEntitlement.AggregationState.Connected));
        Filter f = Filter.and(andFilters);

        qo.addFilter(f);
        Iterator members = context.search(IdentityEntitlement.class, qo);
        if(mdmliblog.isDebugEnabled()) mdmliblog.debug("hasNext: "+members.hasNext());

        if(mdmliblog.isDebugEnabled() && orgRole != null) mdmliblog.debug("orgRole: "+orgRole.getDisplayName());

        while(members.hasNext()){

            IdentityEntitlement member = (IdentityEntitlement) members.next();
            Identity id = member.getIdentity();


            if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Identity: "+id.getName());
            if(mdmliblog.isDebugEnabled() && orgRole != null) mdmliblog.debug("hasOrgRole: "+id.hasRole(orgRole, true));

            // Add identity to workgroup if identity is in the same organisation, in case of MDMPermissionDB the permission is already context aware
            if (checkInheritance){
                if(orgRole == null || holdsPermissionForOrg(id, orgRole, requiredPermission)){
                    validWorkgroupMembers.add(id);
                    if(mdmliblog.isDebugEnabled()) mdmliblog.debug(id.getName()+" should be in workgroup "+workgroup.getName());
                }
            }else{
                validWorkgroupMembers.add(id);
            }
        }



        ArrayList <Identity> membersToRemove = (ArrayList<Identity>) ((ArrayList<?>) currentWorkgroupMembers).clone();
        membersToRemove.removeAll(validWorkgroupMembers);
        ArrayList <Identity> membersToAdd = (ArrayList) ((ArrayList<?>) validWorkgroupMembers).clone();
        membersToAdd.removeAll(currentWorkgroupMembers);

        noOfMembers = noOfMembers+membersToAdd.size()-membersToRemove.size();

        for(Identity id : membersToRemove){

            id.remove(workgroup);
            context.saveObject(id);
            if(mdmliblog.isDebugEnabled()) mdmliblog.debug(id.getName()+" removed from workgroup "+workgroup.getName());

        }

        for(Identity id : membersToAdd){

            id.add(workgroup);
            context.saveObject(id);
            if(mdmliblog.isDebugEnabled()) mdmliblog.debug(id.getName()+" added to workgroup "+workgroup.getName());

        }
        context.saveObject(workgroup);
        context.commitTransaction();

        if(mdmliblog.isDebugEnabled()) mdmliblog.debug("members: "+noOfMembers);

        return noOfMembers;
    }

    boolean holdsPermissionForOrg(Identity id, Bundle org, String permission) throws GeneralException {

        Logger mdmliblog = Logger.getLogger("ema.holdsPermissionForOrg");
        if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Starting holdsPermissionFor");

        boolean holdsPermission = false;

        // Get all the identity's roles

        List <Bundle> roles = id.getAssignedRoles();

        for (Bundle role : roles){

            if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Role: "+role.getName());

            // Now get the OID groups granted by this role
            List <String> groups = null;
            if(!"MDM Context".equals(role.getType())){

                // Provided it's not a context role take the role's Profile
                groups = getRoleEntitlements(role, "EMA Account", "groups");

            }else{
                if(mdmliblog.isDebugEnabled()) mdmliblog.debug("MDM Context");

                // If this is an MDM Context role, find the MDM Template parent role to get the Profile (SSO groups are not present on MDM Context roles)
                String[] roleTokens = role.getName().split("_");
                String parentRoleName = null;
                if(roleTokens.length > 1){
                    parentRoleName = roleTokens[0];
                }

                if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Parent Role Name: "+parentRoleName);

                Bundle parent = context.getObjectByName(Bundle.class, parentRoleName);

                if(parent == null){

                    if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Invalid Context Role - No Parent Role Found!");
                    // If parent can't be found, then can't find the profile so return false;
                    return false;

                }

                if("MDM Template".equals(parent.getType())){

                    if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Parent is MDM Template");
                    groups = getRoleEntitlements(parent, "EMA Account", "groups");
                }

            }

            // Now iterate through the groups looking for a match with the supplied permission
            for(String group : groups){
                if(group.equalsIgnoreCase(permission)){

                    // This role grants the required permission, so we need to check if this role also inherits the specified organisation role
                    if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Role granting permission:"+role.getName());

                    // Check each EMA Organisation parent role and see if it matches the specified org
                    String orgId = getOrgFromRoleName(role.getName());

                    if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Org of Role:"+orgId);

                    //if(org.getName().equals(orgId) || role.getName().contains("EMA Admin")){
                    if(org.getName().equals(orgId)){
                        if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Parent Matches Org!!");

                        // The permission is granted for this specific organisation

                        holdsPermission=true;
                        break;
                    }
                }
            }
        }

        return holdsPermission;
    }

    public String getOrgFromRoleName(String roleName) {
        String orgName = roleName.replaceAll(".*_Org\\/([^_|^$]+).*", "$1");
        if(roleName.equals(orgName)) {
            return null;
        }
        return orgName;
    }

    public Map getEVRoleOperations(ProvisioningPlan plan, ProvisioningPlan.Operation op) throws GeneralException {
        Logger LOG = Logger.getLogger("ema.getEVRoleOperations");
        if(LOG.isDebugEnabled()) LOG.debug("getEVRoleOperations: ");

        Map orgToRole = new HashMap();

        List <ProvisioningPlan.AccountRequest> iiqAccountRequests = plan.getAccountRequests("IIQ");

        for(ProvisioningPlan.AccountRequest req : iiqAccountRequests){

            if(LOG.isDebugEnabled()) LOG.debug("IIQ AccountRequest: "+req.toXml());

            List <ProvisioningPlan.AttributeRequest> assignedRolesRequests = req.getAttributeRequests("assignedRoles");

            for(ProvisioningPlan.AttributeRequest attrReq : assignedRolesRequests){

                if(LOG.isDebugEnabled()) LOG.debug("assignedRoles AttributeRequest: "+attrReq.toXml());

                if(attrReq.getOp() == op){

                    if(LOG.isDebugEnabled()) LOG.debug(op);

                    Object values = attrReq.getValue();

                    if(values instanceof java.util.List){

                        if(LOG.isDebugEnabled()) LOG.debug("Multivalue");
                        List <String> valueList = (List) values;
                        for(String value : valueList){

                            if(LOG.isDebugEnabled()) LOG.debug("Role: "+value);

                            Bundle role = context.getObjectByName(Bundle.class, value);
                            if(role != null && "EV".equals(getRoleApplicationFromName(role.getName()))){

                                if(LOG.isDebugEnabled()) LOG.debug("EV Role");

                                String org = getOrgFromRoleName(value);

                                if(LOG.isDebugEnabled()) LOG.debug("Org: "+org);

                                List roles = (List) orgToRole.get(org);
                                if(roles == null){
                                    roles = new ArrayList();
                                    orgToRole.put(org, roles);
                                }

                                roles.add(value);

                            }

                        }

                    }else if (values instanceof java.lang.String){

                        if(LOG.isDebugEnabled()) LOG.debug("Single");

                        if(LOG.isDebugEnabled()) LOG.debug("Role: "+values);

                        Bundle role = context.getObjectByName(Bundle.class, (String)values);
                        if(role != null && "EV".equals(getRoleApplicationFromName(role.getName()))){

                            if(LOG.isDebugEnabled()) LOG.debug("EV Role");

                            String org = getOrgFromRoleName((String) values);

                            if(LOG.isDebugEnabled()) LOG.debug("Org: "+org);

                            List roles = (List) orgToRole.get(org);
                            if(roles == null){
                                roles = new ArrayList();
                                orgToRole.put(org, roles);
                            }

                            roles.add(values);

                        }

                    }

                }

            }
        }

        return orgToRole;
    }

    public Map getEVVETRoleOperations(ProvisioningPlan plan, ProvisioningPlan.Operation op) throws GeneralException {
        Logger LOG = Logger.getLogger("ema.getEVVETRoleOperations");
        if(LOG.isDebugEnabled()) LOG.debug("getEVVETRoleOperations: ");

        Map orgToRole = new HashMap();

        List <ProvisioningPlan.AccountRequest> iiqAccountRequests = plan.getAccountRequests("IIQ");

        for(ProvisioningPlan.AccountRequest req : iiqAccountRequests){

            if(LOG.isDebugEnabled()) LOG.debug("IIQ AccountRequest: "+req.toXml());

            List <ProvisioningPlan.AttributeRequest> assignedRolesRequests = req.getAttributeRequests("assignedRoles");

            for(ProvisioningPlan.AttributeRequest attrReq : assignedRolesRequests){

                if(LOG.isDebugEnabled()) LOG.debug("assignedRoles AttributeRequest: "+attrReq.toXml());

                if(attrReq.getOp() == op){

                    if(LOG.isDebugEnabled()) LOG.debug(op);

                    Object values = attrReq.getValue();

                    if(values instanceof java.util.List){
                        List <String> valueList = (List) values;
                        if(LOG.isDebugEnabled()) LOG.debug("Multivalue");

                        for(String value : valueList){

                            if(LOG.isDebugEnabled()) LOG.debug("Role: "+value);

                            Bundle role = context.getObjectByName(Bundle.class, value);
                            if(role != null && "EVVET".equals(getRoleApplicationFromName(role.getName()))){

                                if(LOG.isDebugEnabled()) LOG.debug("EV VET Role");

                                String org = getOrgFromRoleName(value);

                                if(LOG.isDebugEnabled()) LOG.debug("Org: "+org);

                                List roles = (List) orgToRole.get(org);
                                if(roles == null){
                                    roles = new ArrayList();
                                    orgToRole.put(org, roles);
                                }

                                roles.add(value);

                            }

                        }

                    }else if (values instanceof java.lang.String){

                        if(LOG.isDebugEnabled()) LOG.debug("Single");

                        if(LOG.isDebugEnabled()) LOG.debug("Role: "+values);

                        Bundle role = context.getObjectByName(Bundle.class, (String) values);
                        if(role != null && "EVVET".equals(getRoleApplicationFromName(role.getName()))){

                            if(LOG.isDebugEnabled()) LOG.debug("EV VET Role");

                            String org = getOrgFromRoleName((String) values);

                            if(LOG.isDebugEnabled()) LOG.debug("Org: "+org);

                            List roles = (List) orgToRole.get(org);
                            if(roles == null){
                                roles = new ArrayList();
                                orgToRole.put(org, roles);
                            }

                            roles.add(values);

                        }

                    }

                }

            }
        }

        return orgToRole;
    }

    public List getEVAssignedRoles(Identity id, String org){


        List evRoleNames = new ArrayList();
        List <Bundle> assignedRoles = id.getAssignedRoles();

        for(Bundle role : assignedRoles){
            if("EV".equals(getRoleApplicationFromName(role.getName())) && (org == null || org.equals(getOrgFromRoleName(role.getName())))){
                evRoleNames.add(role.getName());
            }

        }

        return evRoleNames;

    }

    public  List getEVVETAssignedRoles(Identity id, String org){


        List evRoleNames = new ArrayList();
        List <Bundle> assignedRoles = id.getAssignedRoles();

        for(Bundle role : assignedRoles){
            if("EVVET".equals(getRoleApplicationFromName(role.getName())) && (org == null || org.equals(getOrgFromRoleName(role.getName())))){
                evRoleNames.add(role.getName());
            }

        }

        return evRoleNames;

    }

    public void getApprovalWorkgroupRequirements(Identity workgroup) throws GeneralException, CloneNotSupportedException {

        Logger mdmliblog = Logger.getLogger("ema.getApprovalWorkgroupRequirements");
        // Find all roles this workgroup is the owner of

        QueryOptions qo = new QueryOptions();
        qo.add(Filter.and(Filter.eq("owner",workgroup),Filter.ne("type","MDM Application"),Filter.ne("type","EMA Organisation")));

        if(context.countObjects(Bundle.class, qo) != 1){
            if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Multiple or no Roles Approved By This Workgroup");
        }else{

            /*
             * For workgroups that map to a single role, the application the role belongs to
             * and it's Grant Class can be used to determine what permission approvers must hold.
             *
             */

            Bundle role = context.getUniqueObject(Bundle.class,Filter.and(Filter.eq("owner",workgroup),Filter.ne("type","MDM Application"),Filter.ne("type","EMA Organisation")));
            String roleName = role.getName();

            if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Role Found");
            if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Role Approved By This Workgroup: "+roleName);

            String app = getRoleApplicationFromName(roleName);

            if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Application: "+app);

            // Get Org ID from Role Name (cheaper than inheritance).
            String orgId = getOrgFromRoleName(roleName);

            Bundle orgRole = context.getObjectByName(Bundle.class, orgId);

            if(mdmliblog.isDebugEnabled() && orgRole != null) mdmliblog.debug("Organisation: "+orgRole.getName());

            String grantClass = (String) role.getAttribute("Grant Class");

            if(mdmliblog.isDebugEnabled() && grantClass != null) mdmliblog.debug("Grant Class: "+grantClass);

            String requiredPermission = null;

            if(app != null && grantClass != null){

                //if the role is context aware the permission is checked in the context permission DB otherwise in ECD
                if (orgRole == null){
                    requiredPermission = "cn="+app+"_grant_"+grantClass+",dc=oraclesso,dc=apps,dc=ecd,dc=emea,dc=eu,dc=int";
                }else{
                    requiredPermission = "IAM/"+app +"_GRANT_"+grantClass.toUpperCase()+"/Org/"+orgId;
                }
                //requiredPermission = "cn="+app+"_grant_"+grantClass+",dc=oraclesso,dc=apps,dc=ecd,dc=emea,dc=eu,dc=int";
                if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Permission: "+requiredPermission);
                int memberCount;
                memberCount = refreshApprovalWorkgroup(workgroup, role, orgRole, requiredPermission);
                if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Member Count:"+memberCount);

            }else{

                if(mdmliblog.isDebugEnabled()) mdmliblog.debug("Permission Not Required");

            }

        }

    }

    public Map<String,List> checkAttachmentsNeeded(ProvisioningProject project) throws GeneralException, CloneNotSupportedException {
        Map returnMap = new HashMap();

        ProvisioningPlan plan = project.getMasterPlan();
        ProvisioningPlan.AccountRequest iiqRequest = plan.getIIQAccountRequest();
        if (iiqRequest != null) {
            List <ProvisioningPlan.AttributeRequest> attributeRequests = iiqRequest.getAttributeRequests();
            if (attributeRequests != null && !attributeRequests.isEmpty()) {
                for (ProvisioningPlan.AttributeRequest attributeRequest:attributeRequests) {
                    // Look for addition of roles
                    if ("assignedRoles".equals(attributeRequest.getName()) || "detectedRoles".equals(attributeRequest.getName())) {
                        if(ProvisioningPlan.Operation.Add.equals(attributeRequest.getOperation())){
                            Bundle role = context.getObjectByName(Bundle.class, (String) attributeRequest.getValue());
                            if (role != null) {
                                // Check EV or EVVET
                                String roleApp = getRoleApplicationFromName(role.getName());
								//change here to avoid attachments?
				//Check if org owner has members
				List orgOwners = getOrgRoleOwnerMembers(role.getName());
                                if(!"EV".equals(roleApp) && !"EVVET".equals(roleApp) && (orgOwners == null || orgOwners.isEmpty())){
                                    boolean isSuperAdmin = isExternalApprover(role);
                                    log.error("checking role "+role.getName()+" - isExternalApprover: "+isSuperAdmin);
                                    // If super admin; check owner workgroup
                                    if (isSuperAdmin) {
                                        Identity owner = role.getOwner();
                                        if (owner != null) {
                                            String ownerName = owner.getName();
                                            if (owner.isWorkgroup()) {
                                                // Refresh workgroup
                                                getApprovalWorkgroupRequirements(owner);
                                                Identity refreshedOwner = context.getObjectByName(Identity.class,ownerName);
                                                if (refreshedOwner != null) {
                                                    List props = new ArrayList();
                                                    props.add("name");
                                                    Iterator iterator = ObjectUtil.getWorkgroupMembers(context,refreshedOwner,props);
                                                    if (iterator == null || !iterator.hasNext()) {
                                                        log.debug("empty owner workgroup: "+ownerName);
                                                        log.debug("attachment required");
                                                        returnMap.put(role.getName(),role.getDisplayableName());
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }
        }

        return returnMap;
    }

    public boolean checkTicketNeeded(String roleName) throws GeneralException, CloneNotSupportedException {
        boolean needed = false;
        boolean isEvOn = PluginBaseHelper.getSettingBool("emarfo","isEvOn");
        //boolean isUPDOn = PluginBaseHelper.getSettingBool("emarfo","isUPDOn");
		String snowExclusionString = PluginBaseHelper.getSettingString("emarfo","snowExclusion");
		List snowExclusion = Util.csvToList(snowExclusionString);
		boolean snowExclusionCheck = false;
		
        Bundle role = context.getObjectByName(Bundle.class,roleName);
        if (role != null) {


            // Check EV or EVVET 
            String roleApp = getRoleApplicationFromName(roleName);
            boolean isEv = "EV".equals(roleApp);
            boolean isEvVet = "EVVET".equals(roleApp);
            //boolean isUPD = "UPD".equals(roleApp);
			//check if the role should be excluded
			if (!Util.isEmpty(snowExclusion)) 	snowExclusionCheck = snowExclusion.contains(roleApp);

            if (isEv || isEvVet) {
                if (isEvOn) {
                    if ("RESPONSIBLE".equals(role.getAttribute("Grant Class"))) {
                        // Always create ticket for these
                        log.debug("EV/EVVET: " + roleName + " ... creating ticket");
                        return true;
                    }
                } else {
                    return false;
                }
            }

            boolean isSuperAdmin = isExternalApprover(role);
            log.debug("checking role "+role.getName()+" - isExternalApprover: "+isSuperAdmin);
            // If super admin; check owner workgroup
            //if (isSuperAdmin && (isUPDOn || !isUPD)) {
			if (isSuperAdmin && !snowExclusionCheck) {
                Identity owner = role.getOwner();
                if (owner != null) {
                    String ownerName = owner.getName();
                    if (owner.isWorkgroup()) {
                        // Refresh workgroup
                        getApprovalWorkgroupRequirements(owner);
                        Identity refreshedOwner = context.getObjectByName(Identity.class,ownerName);
                        if (refreshedOwner != null) {
                            List props = new ArrayList();
                            props.add("name");
                            Iterator iterator = ObjectUtil.getWorkgroupMembers(context,refreshedOwner,props);
                            if (iterator == null || !iterator.hasNext()) {
                                log.debug("empty owner workgroup: "+ownerName);
                                log.debug("attachment required");
                                needed = true;
                            }
                        }

                    }
                }
            }
			//request for IRIS individual role should trigger SD ticket
			if("IRIS Individual User".equals(role.getName())) needed = true;

        }

        return needed;
    }

    public void createTicketIfNeeded(WorkItem item) throws JSONException, GeneralException, CloneNotSupportedException, IOException {
        Logger log = Logger.getLogger("ema.createsnowticket");
        log.debug("Entering create snow ticket");
        log.debug("Work item: "+item.toXml());
		Identity itemOwner = item.getOwner();
        Configuration config = context.getConfiguration();
        String serverRoot = (String) config.get("serverRootPath");
        // Check if we need to create a ticket
        ApprovalSet approvalSet = item.getApprovalSet();
        if (approvalSet != null) {
            List <ApprovalItem> approvalItems = approvalSet.getItems();
            if (approvalItems != null && !approvalItems.isEmpty()) {
                for(ApprovalItem approvalItem:approvalItems) {
                    // For adding roles
                    if("Add".equals(approvalItem.getOperation()) && "assignedRoles".equals(approvalItem.getName()) ){
                        Object value = approvalItem.getValue();
                        List<String> valueList = new ArrayList<>();
                        if (value instanceof List) {
                            valueList = (List<String>) value;
                        } else {
                            valueList.add((String) value);
                        }
                        if (!valueList.isEmpty()) {
                            for (String roleName:valueList){

								//added check, if teh item is assigned to the Org Admin no ticket is needed

                                if (checkTicketNeeded(roleName) && itemOwner != null && (itemOwner.getName().equalsIgnoreCase("ORGADMIN EMA Organisation Administrators Approvers") ||  !(itemOwner.getName().startsWith("ORGADMIN")))) {

                                    IdentityRequest identityRequest = context.getObjectByName(IdentityRequest.class,item.getIdentityRequestId());



                                    // Data validation
                                    String identityName = item.getTargetName();
                                    String email = null;
                                    if (identityName != null) {
                                        Identity identity = context.getObjectByName(Identity.class,identityName);
                                        if (identity != null) {
                                            email = identity.getEmail();
                                        }
                                    }


                                    if (email != null) {

                                        // Check EV or EVVET
                                        String roleApp = getRoleApplicationFromName(roleName);
                                        boolean isEv = "EV".equals(roleApp);
                                        boolean isEvVet = "EVVET".equals(roleApp);
                                        boolean addCount = false;
                                        int countMembers = 0;

                                        if (isEv || isEvVet) {
                                            // Get role grant class
                                            Bundle role = context.getObjectByName(Bundle.class,roleName);
                                            if (role != null) {
                                                if ("RESPONSIBLE".equals(role.getAttribute("Grant Class"))) {
                                                    addCount = true;
                                                    log.debug("This is a QPPV/Responsible Role, checking if it's already assigned...");
                                                    QueryOptions qo = new QueryOptions();
                                                    qo.setDistinct(true);
                                                    if (isEv) {
                                                        List <Filter> resp_filters = new ArrayList<>();
                                                        resp_filters.add(Filter.eq("assignedRoles.name","EV MAH EU QPPV_Org/"+getOrgFromRoleName(role.getName())));
                                                        resp_filters.add(Filter.eq("assignedRoles.name","EV NCA Responsible_Org/"+getOrgFromRoleName(role.getName())));
                                                        resp_filters.add(Filter.eq("assignedRoles.name","EV CS NCS Responsible_Org/"+getOrgFromRoleName(role.getName())));
                                                        resp_filters.add(Filter.eq("assignedRoles.name","EV XCOMP Vendor Responsible person_Org/"+getOrgFromRoleName(role.getName())));
                                                        qo.addFilter(Filter.or(resp_filters));
                                                    }
                                                    if (isEvVet) {
                                                        List <Filter> resp_filters = new ArrayList<>();
                                                        resp_filters.add(Filter.eq("assignedRoles.name","EVVET MAH Responsible_Org/"+getOrgFromRoleName(role.getName())));
                                                        resp_filters.add(Filter.eq("assignedRoles.name","EVVET NCA Responsible_Org/"+getOrgFromRoleName(role.getName())));
                                                        resp_filters.add(Filter.eq("assignedRoles.name","EVVET XCOMP Vendor Responsible person_Org/"+getOrgFromRoleName(role.getName())));
                                                        qo.addFilter(Filter.or(resp_filters));
                                                    }
                                                    countMembers = context.countObjects(Identity.class, qo);
                                                    log.debug("Already assigned to "+countMembers+" identities");

                                                }
                                            }
                                        }

                                        ApacheHttpClient httpClient = new ApacheHttpClient();
                                        Map<String,String> args = new HashMap<>();
                                        // URL
                                        String url = config.getString("emaSnowEndpoint");
                                        // Auth

                                        String user = config.getString("emaSnowUser");
                                        String pw = config.getString("emaSnowPassword");
                                        // Other headers
                                        Map<String,String> headers = new HashMap<>();
                                        // Information can be fetched from requestEndpoint and updated in the header and body
                                        headers.put("Content-Type","application/json");

                                        // Compose JSON
                                        JSONObject mainObject = new JSONObject();
                                        // Variables
                                        JSONObject variables = new JSONObject();
                                        variables.put("requested_for",email);

                                        // Description
                                        String description = item.getDescription();
                                        if (addCount) {
                                            if (countMembers > 0) {
                                                description = "Change Responsible: "+description;
                                            } else {
                                                description = "New Responsible: "+description;
                                            }
                                            item.setDescription(description);
                                        }

                                        //Save item so it gets an id
                                        context.saveObject(item);
                                        log.debug("Item after saving"+item.toXml());

                                        variables.put("url",serverRoot+"/workitem/commonWorkItem.jsf#/commonWorkItem/"+item.getId());
                                        variables.put("description",description);
                                        variables.put("service",getRoleApplicationFromName(roleName));

                                        mainObject.put("variables",variables);

                                        // Attachments
                                        List<AttachmentDTO> attachments = (List<AttachmentDTO>) approvalItem.getAttribute("attachments");
                                        if(attachments != null && !attachments.isEmpty()) {
                                            JSONArray documents = new JSONArray();
                                            for (AttachmentDTO attachmentDTO:attachments) {
                                                Attachment attachment = context.getObjectById(Attachment.class,attachmentDTO.getId());
                                                if (attachment != null) {
                                                    byte[] content = attachment.getContent();
                                                    String contentString = new String(content);
                                                    String decryptedBase64 = context.decrypt(contentString);

                                                    java.nio.file.Path path = new File(attachment.getName()).toPath();
                                                    String mimeType = Files.probeContentType(path);


                                                    log.debug("base64: "+decryptedBase64);
                                                    JSONObject document = new JSONObject();
                                                    document.put("file_name",attachment.getName());
                                                    document.put("base64",decryptedBase64);
                                                    document.put("mime_type",mimeType);
                                                    documents.put(document);
                                                }

                                            }

                                            mainObject.put("documents",documents);
                                        }

                                        try {
                                            // Set up client with basic auth ant timeout 15
                                            httpClient.setup(false,443,user,pw,"15",args);
                                            // Execute POST call
                                            log.debug("Executing API call to "+url);
                                            log.debug("Body: "+mainObject.toString());

                                            int statusCode = httpClient.post(url,mainObject.toString(),headers);
                                            log.debug("Result: "+statusCode);
                                            String responseBody = httpClient.getBody();
                                            log.debug("Response body: "+responseBody);
                                            JSONObject responseJson = new JSONObject(responseBody);
                                            log.debug("Response JSON: "+responseJson);

                                            if (200 == statusCode) {
                                                JSONObject resultJson = responseJson.getJSONObject("result");
                                                if (resultJson != null) {
                                                    String ticketNumber = resultJson.getString("ticket_number");
                                                    log.debug("Ticket Number: "+ticketNumber);
                                                    if (identityRequest != null) {
                                                        Message message = new Message();
                                                        message.setType(Message.Type.Info);
                                                        message.setKey("EMA: "+roleName+ ": Ticket Number: "+ticketNumber+"- Created on: "+Util.dateToString(new Date(),"dd/MM/yyyy HH:mm"));
                                                        identityRequest.addMessage(message);
                                                        context.saveObject(identityRequest);
                                                        context.commitTransaction();
                                                    }

                                                }

                                            } else {
                                                JSONObject errorJson = responseJson.getJSONObject("error");
                                                if (errorJson != null) {
                                                    String errorMessage = errorJson.getString("message");
                                                    log.debug("Message: "+errorMessage);
                                                    if (identityRequest != null) {
                                                        Message message = new Message();
                                                        message.setType(Message.Type.Error);
                                                        message.setKey("EMA: "+roleName+ ": Ticket could not be created: "+errorMessage+" - Date: "+Util.dateToString(new Date(),"dd/MM/yyyy HH:mm"));
                                                        identityRequest.addMessage(message);
                                                        context.saveObject(identityRequest);
                                                        context.commitTransaction();
                                                    }

                                                }
                                            }


                                        } catch (Exception e) {
                                            log.error(e.getMessage());
                                            if (identityRequest != null) {
                                                Message message = new Message();
                                                message.setType(Message.Type.Error);
                                                message.setKey("EMA: "+roleName+ ": Ticket could not be created: "+e.getMessage()+" - Date: "+Util.dateToString(new Date(),"dd/MM/yyyy HH:mm"));
                                                identityRequest.addMessage(message);
                                                context.saveObject(identityRequest);
                                                context.commitTransaction();
                                            }
                                        }

                                    } else {
                                        log.error("No email found for item "+item.toXml()+" - not creating ticket " );
                                        if (identityRequest != null) {
                                            Message message = new Message();
                                            message.setType(Message.Type.Error);
                                            message.setKey("EMA: "+roleName+ ": Ticket could not be created: No email found - Date: "+Util.dateToString(new Date(),"dd/MM/yyyy HH:mm"));
                                            identityRequest.addMessage(message);
                                            context.saveObject(identityRequest);
                                            context.commitTransaction();
                                        }
                                    }

                                }
                            }
                        }
                    }

                }
            }
        }

        log.debug("Exiting create snow ticket");
    }

    public static String ordinal(int i) {
        String[] suffixes = new String[] { "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th" };
        switch (i % 100) {
            case 11:
            case 12:
            case 13:
                return i + "th";
            default:
                return i + suffixes[i % 10];

        }
    }
}
