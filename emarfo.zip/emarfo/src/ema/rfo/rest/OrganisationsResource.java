package ema.rfo.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.integration.ListResult;
import sailpoint.object.*;
import sailpoint.plugin.PluginBaseHelper;
import sailpoint.rest.plugin.AllowAll;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;

@Path("emarfo")
public class OrganisationsResource extends EmaRfoBaseResource {
    private Logger log = Logger.getLogger("ema.rfo.OrganisationsResource");
    private final SailPointContext context;

    public OrganisationsResource() throws GeneralException {
        this.context = SailPointFactory.getCurrentContext();
    }

    @AllowAll
    @GET
    @Path("organisations/email")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserEmail() throws GeneralException {
        Identity identity = context.getObjectByName(Identity.class,context.getUserName());
        String email = "";
        if (identity != null) {
            email = identity.getEmail();
        }
        Map<String,String> responseMap = new HashMap<>();
        responseMap.put("email",email);
        return Response
                .status(Response.Status.OK)
                .entity(responseMap)
                .build();
    }

    @AllowAll
    @POST
    @Path("organisations/create")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createOrgRequest(Map<String, Object>  parameters) throws GeneralException {

        Map<String,Object> responseMap = parameters;
        Identity requesterIdentity = context.getObjectByName(Identity.class,context.getUserName());
        if (requesterIdentity == null) {
            responseMap.put("message","requester unknown");
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity(responseMap)
                    .build();
        }


        // Data validations
        String gs1Id = (String) parameters.get("gs1Id");
        String reason = (String) parameters.get("reason");
        String country = (String) parameters.get("country");
        String contactEmail = (String) parameters.get("contactEmail");
        String acronym = (String) parameters.get("acronym");
        String city = (String) parameters.get("city");
        String postalCode = (String) parameters.get("postalCode");
        String county = (String) parameters.get("county");
        String locationPhone = (String) parameters.get("locationPhone");
        String organisationType = (String) parameters.get("organisationType");
        String organisationName = (String) parameters.get("organisationName");
        String dunsId = (String) parameters.get("dunsId");
        String street1 = (String) parameters.get("street1");
        String street2 = (String) parameters.get("street2");
        String justification = (String) parameters.get("justification");
        String contactPhone = (String) parameters.get("contactPhone");
        String locationEmail = (String) parameters.get("locationEmail");
        Map documents = (HashMap) parameters.get("documents");
        // Required fields
        if (Util.isNullOrEmpty(reason) || Util.isNullOrEmpty(contactEmail) || Util.isNullOrEmpty(organisationType) ||
        Util.isNullOrEmpty(organisationName) || Util.isNullOrEmpty(street1) || Util.isNullOrEmpty(country)) {
            responseMap.put("message","missing data");
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity(responseMap)
                    .build();
        }

        // todo check email?

        try {
            JSONObject mainObject = new JSONObject();

            JSONObject changeRequest = new JSONObject();
            // name and type
            changeRequest.put("name",requesterIdentity.getName());
            changeRequest.put("type","ADD-ORGANISATION");
            // request-reason
            JSONObject reasonObject = new JSONObject();
            reasonObject.put("code",reason);
            if ("200000000099".equals(reason)) {
                reasonObject.put("display-name", "Create a new organisation - split from existing organisation");
            } else {
                reasonObject.put("display-name", "Create a new organisation - as new legal entity");
            }
            changeRequest.put("request-reason",reasonObject);

            // Attachments

            if (documents != null && !documents.isEmpty()) {
                changeRequest.put("documents",documents);
            }

            // email, phone, justification
            changeRequest.put("requestor-email",contactEmail);
            changeRequest.put("requestor-phone",contactPhone);
            changeRequest.put("justification",justification);
            changeRequest.put("status","SAVED");
            changeRequest.put("requestor-user-id","-1");
            changeRequest.put("address-language","-1");

            // draft organisation
            JSONObject organisationObject = new JSONObject();
            organisationObject.put("name",organisationName);
            organisationObject.put("acronym",acronym);
            // category of organisation
            JSONObject categoryClassifications = new JSONObject();
            JSONObject categoryClassification = new JSONObject();
            JSONObject category = new JSONObject();
            category.put("code",organisationType);
            switch (organisationType) {
                case "200000000075": category.put("display-name","Educational Institution");
                    break;
                case "200000000076": category.put("display-name","Health care");
                    break;
                case "200000000084": category.put("display-name","Regulatory Authority");
                    break;
                case "200000000080": category.put("display-name","Industry");
                    break;
            }
            categoryClassification.put("category",category);
            JSONObject categoryType = new JSONObject();
            categoryType.put("code","200000000073");
            categoryType.put("display-name","-1");
            categoryClassification.put("category-type",categoryType);
            categoryClassifications.put("category-classification",categoryClassification);
            organisationObject.put("category-classifications",categoryClassifications);
            changeRequest.put("draft-organisation",organisationObject);

            // draft location
            JSONObject locationObject = new JSONObject();
            // Address of location
            JSONObject address = new JSONObject();
            JSONObject addressDetails = new JSONObject();
            JSONObject addressDetail = new JSONObject();
            addressDetail.put("lang","en");
            addressDetail.put("address-line-1",street1);
            addressDetail.put("address-line-2",street2);
            addressDetail.put("city",city);
            addressDetail.put("county",county);
            addressDetails.put("address-detail",addressDetail);
            address.put("address-details",addressDetails);
            address.put("postal-code",postalCode);
            JSONObject countryObject = new JSONObject();
            countryObject.put("code",country);
            Locale locale = new Locale("",country);
            countryObject.put("display-name", locale.getDisplayCountry());
            address.put("country",countryObject);
            locationObject.put("address",address);

            // Communication details of location
            JSONObject communicationDetails = new JSONObject();
            JSONObject communicationDetail = new JSONObject();
            JSONObject locationEmailObject = new JSONObject();
            locationEmailObject.put("email-address",locationEmail);
            communicationDetail.put("email-addresses",locationEmailObject);
            if (!Util.isNullOrEmpty(locationPhone)) {
                JSONObject phoneNumbersObject = new JSONObject();
                // todo prefix
                JSONObject phoneNumberObject = new JSONObject();
                phoneNumberObject.put("country-prefix","+32");
                phoneNumberObject.put("number",locationPhone);
                phoneNumbersObject.put("phone-number",phoneNumberObject);
                communicationDetail.put("phone-numbers",phoneNumbersObject);
            }

            communicationDetails.put("communication-detail",communicationDetail);
            locationObject.put("communication-details",communicationDetails);

            if (!Util.isNullOrEmpty(dunsId) || !Util.isNullOrEmpty(gs1Id)) {
                JSONObject mappings = new JSONObject();
                List mapping = new ArrayList();
                if (!Util.isNullOrEmpty(dunsId)) {
                    JSONObject dunsMapping = new JSONObject();
                    dunsMapping.put("code-system","100000167449" );
                    dunsMapping.put("code-system-name","-1");
                    dunsMapping.put("code",dunsId);
                    mapping.add(dunsMapping);
                }
                if (!Util.isNullOrEmpty(gs1Id)) {
                    JSONObject gs1Mapping = new JSONObject();
                    gs1Mapping.put("code-system","100000167435" );
                    gs1Mapping.put("code-system-name","-1");
                    gs1Mapping.put("code",gs1Id);
                    mapping.add(gs1Mapping);
                }
                mappings.put("mapping",mapping);
                locationObject.put("mappings",mappings);
            }

            changeRequest.put("draft-location",locationObject);

            mainObject.put("change-request-oms",changeRequest);
            log.debug("JSON object for change request: "+mainObject);

            // Call OMS API
            Configuration config = context.getConfiguration();

            CredentialsProvider provider = new BasicCredentialsProvider();
            UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(config.getString("emaOrgRoleSyncUsername"),config.getString("emaOrgRoleSyncPassword"));
            provider.setCredentials(AuthScope.ANY,credentials);
            String url = config.getString("emaOrgRoleSyncRESTEndpoint");
            if (url != null) {
                url = url.replace("organisations","change-requests-oms");
            }
            log.debug("Url: "+url);
            int timeout = 120;

            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(timeout * 1000)
                    .setConnectionRequestTimeout(timeout * 1000)
                    .setSocketTimeout(timeout * 1000).build();
            HttpClient httpClient = HttpClientBuilder.create()
                    .setDefaultCredentialsProvider(provider)
                    .setDefaultRequestConfig(requestConfig)
                    .setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build())
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .build();



            HttpPost httpPost = new HttpPost(url);
            String json = mainObject.toString();
            StringEntity entity = new StringEntity(json,"UTF-8");
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            log.debug("Executing api: "+ httpPost);
            HttpResponse httpResponse = httpClient.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            log.debug("Status code: "+statusCode);
            log.debug("Response: "+httpResponse.getEntity().toString());

            if (200 == statusCode) {
                // Insert into custom object so we can track every 15 minutes if it's executed
                Custom custom = context.getObjectByName(Custom.class,"EMA Pending Organization Change Requests");
                if (custom == null) {
                    custom = new Custom();
                    custom.setName("EMA Pending Organization Change Requests");
                }
                String responseBody = EntityUtils.toString(httpResponse.getEntity(), StandardCharsets.UTF_8);
                log.debug("Response body: "+ responseBody);
                JSONObject responseJson = new JSONObject(responseBody);
                log.debug("Response json: "+responseJson);
                JSONObject changeRequestJson = (JSONObject) responseJson.get("change-request-oms");
                JSONObject requestIdJson = (JSONObject) changeRequestJson.get("request-id");
                JSONObject requestLinkJson = (JSONObject) requestIdJson.get("link");
                String requestLink = (String) requestLinkJson.get("href");
                String requestId = (String) requestIdJson.get("id");
                log.debug("Request Link: "+requestLink);

                // Send email
                EmailTemplate template = context.getObjectByName(EmailTemplate.class,"EMA - Organisation Create Request Submitted");
                String email = requesterIdentity.getEmail();
                if (email != null && template != null) {
                    EmailOptions emailOptions = new EmailOptions();
                    emailOptions.setTo(email);
                    emailOptions.setVariable("username", requesterIdentity.getDisplayableName());
                    emailOptions.setVariable("firstname", requesterIdentity.getFirstname());
                    emailOptions.setVariable("country",country);
                    emailOptions.setVariable("requestId",requestId);
                    Configuration configuration = context.getConfiguration();
                    String serverRootPath = configuration.getString("serverRootPath");
                    String link = serverRootPath + "/plugins/pluginPage.jsf?pn=emaccr";
                    emailOptions.setVariable("link",link);
                    context.sendEmailNotification(template,emailOptions);
                }


                Map<String,String> cr = new HashMap<>();
                cr.put("requester",requesterIdentity.getName());
                cr.put("country",country);
                cr.put("requestId",requestId);
                custom.put(requestLink,cr);
                context.saveObject(custom);
                context.commitTransaction();
                return Response
                        .status(Response.Status.OK)
                        .entity(requestId)
                        .build();
            } else {
                log.debug("Reason phrase: "+httpResponse.getStatusLine().getReasonPhrase());
                responseMap.put("message","OMS service is unavailable at the moment, please try again in few minutes, if the problem persist please open a ticket in EMA service desk");
                return Response
                        .status(statusCode)
                        .entity(responseMap)
                        .build();
            }

        } catch (Exception e) {
            responseMap.put("message",e.getMessage());
            log.error(e.getMessage());
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity(responseMap)
                    .build();
        }

    }

    @AllowAll
    @POST
    @Path("organisations")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ListResult getOrganisations(Map<String, Object>  parameters) throws GeneralException {
        log.trace("entering getOrganisations");
        ListResult listResult;
        Set returnSet = new HashSet();

        int maxOrgs = PluginBaseHelper.getSettingInt("emarfo","maxOrgs");
        int max = maxOrgs;
        int count = 0;
        List<String> country = (List<String>) parameters.get("country");
        boolean includeHistorical = (boolean) parameters.get("includeHistorical");
        if (country!= null && !country.isEmpty()) {
            log.debug("Country: "+country);
            for(String countryCode:country) {
                log.debug("CountryCode: "+countryCode);
                QueryOptions qo = new QueryOptions();
                qo.addFilter(Filter.like("name","LOCATIONS-"+countryCode, Filter.MatchMode.START));
                List <Custom> customObjects = context.getObjects(Custom.class,qo);
                if (customObjects != null && !customObjects.isEmpty()) {
                    for (Custom custom:customObjects) {
                        Attributes<String, Object> locations = custom.getAttributes();
                        if (locations != null && !locations.isEmpty()) {
                            for (Map.Entry entry : locations.entrySet()) {
                                // entry.getKey() = LOC-100002675
                                Attributes <String,Object> locationDetails = (Attributes) entry.getValue();
                                if (locationDetails != null) {
                                    Map <String,Object> addresses = (Map) locationDetails.get("addresses");
                                    if (addresses != null) {
                                        for (Map.Entry addressEntry : addresses.entrySet()) {
                                            String language = (String) parameters.get("language");
                                            if(language.equalsIgnoreCase((String) addressEntry.getKey())) {
                                                Map addressDetails = (Map) addressEntry.getValue();
                                                if (addressDetails != null && !addressDetails.isEmpty()) {
                                                    boolean prevOk = true;
                                                    // Check City
                                                    String city = (String) parameters.get("city");
                                                    if ( city != null &&!"".equals(city)) {
                                                        prevOk = false;
                                                        String cityLower = city.toLowerCase();
                                                        String locationCity = (String) addressDetails.get("city");
                                                        if (locationCity != null ) {
                                                            String locationCityLower = locationCity.toLowerCase();
                                                            if (locationCityLower.contains(cityLower)) {
                                                                prevOk = true;
                                                                log.debug("City: "+prevOk);
                                                            }
                                                        }

                                                    }

                                                    // Check Postal Code
                                                    String postalCode = (String) parameters.get("postalCode");
                                                    if (prevOk && postalCode != null && !"".equals(postalCode)) {
                                                        log.debug("Checking postal code");
                                                        prevOk = false;
                                                        String postalLower = postalCode.toLowerCase();
                                                        String locationPostal = (String) locationDetails.get("postalCode");
                                                        if (locationPostal != null) {
                                                            String locationPostalLower = locationPostal.toLowerCase();
                                                            if (locationPostalLower.contains(postalLower)) {
                                                                prevOk = true;
                                                                log.debug("Postal Code: "+prevOk);
                                                            }
                                                        }

                                                    }

                                                    // Check Full Address
                                                    String fullAddress = (String) parameters.get("fullAddress");
                                                    if (prevOk && fullAddress != null && !"".equals(fullAddress)) {
                                                        prevOk = false;
                                                        String fullAddressLower = fullAddress.toLowerCase();
                                                        String locationFullAddress = composeFullAddress(addressDetails,locationDetails);
                                                        if (locationFullAddress != null) {
                                                            String locationFullAddressLower = locationFullAddress.toLowerCase();
                                                            if (locationFullAddressLower.contains(fullAddressLower)) {
                                                                prevOk = true;
                                                                log.debug("full address: "+prevOk);
                                                            }
                                                        }

                                                    }

                                                    // Check LocationId
                                                    String locationId = (String) parameters.get("locationId");
                                                    if (prevOk && locationId != null && !"".equals(locationId)) {
                                                        prevOk = false;
                                                        String locationIdLower = locationId.toLowerCase();
                                                        String currentLocationId = (String) entry.getKey();
                                                        String currentLocationLower = currentLocationId.toLowerCase();
                                                        if (currentLocationLower.contains(locationIdLower)) {
                                                            prevOk = true;
                                                            log.debug("locationid: "+prevOk);
                                                        }

                                                    }


                                                    String orgName = "";
                                                    String acrName = "";
                                                    String identifiers = "";
                                                    boolean available = true;
                                                    String classification = "";
                                                    Identity owner = null;


                                                    if (prevOk) {
                                                        // Get Organisation Name
                                                        prevOk = false;
                                                        Bundle orgRole = context.getObjectByName(Bundle.class,(String)locationDetails.get("organisation"));
                                                        if (orgRole != null) {
                                                            prevOk = true;
                                                            orgName = orgRole.getDisplayName();
                                                            acrName = (String) orgRole.getAttribute("acronym");
                                                            if (acrName == null) {
                                                                acrName = "";
                                                            }
                                                            identifiers = (String) orgRole.getAttribute("identifiers");
                                                            if (identifiers == null) {
                                                                identifiers = "";
                                                            }
                                                            if (orgRole.isDisabled()) {
                                                            	available = false;
                                                            }
                                                            classification = (String) orgRole.getAttribute("classification");
                                                            if (classification == null) {
                                                                classification = "";
                                                            }

                                                            owner = orgRole.getOwner();

                                                        }
                                                    }

                                                    // Check OrgansiationId
                                                    String organisationId = (String) parameters.get("organisationId");
                                                    if (prevOk && organisationId != null && !"".equals(organisationId)) {
                                                        prevOk = false;
                                                        String organisationIdLower = organisationId.toLowerCase();
                                                        String locationOrganisation = (String) locationDetails.get("organisation");
                                                        if (locationOrganisation != null) {
                                                            String locationOrganisationLower = locationOrganisation.toLowerCase();
                                                            if (locationOrganisationLower.contains(organisationIdLower)) {
                                                                prevOk = true;
                                                                log.debug("org id: "+prevOk);
                                                            }
                                                        }
                                                        // Check if orgRole has org id as identifier

                                                        if (identifiers.toLowerCase().contains(organisationIdLower)) {
                                                            prevOk = true;
                                                            log.debug("org id: "+prevOk);
                                                        }

                                                    }

                                                    // Check OrganisationName
                                                    String organisationName = (String) parameters.get("organisationName");
                                                    if (prevOk && organisationName != null && !"".equals(organisationName)) {
                                                        prevOk = false;
                                                        // normalize IAM-746
                                                        organisationName = Normalizer.normalize(organisationName,Normalizer.Form.NFD);
                                                        organisationName = organisationName.replaceAll("\\p{M}", "");
                                                        String normalizedOrgName = Normalizer.normalize(orgName,Normalizer.Form.NFD);
                                                        normalizedOrgName = normalizedOrgName.replaceAll("\\p{M}", "");
                                                        String normalizedAcrName = Normalizer.normalize(acrName,Normalizer.Form.NFD);
                                                        normalizedAcrName = normalizedAcrName.replaceAll("\\p{M}", "");
                                                        if (normalizedOrgName.toLowerCase().contains(organisationName.toLowerCase()) || (normalizedAcrName != null && normalizedAcrName.toLowerCase().contains(organisationName.toLowerCase())) ) {
                                                            prevOk = true;
                                                            log.debug("orgnme: "+prevOk);
                                                        }
                                                    }
                                                 // Check Location Status
                                                    if("INACTIVE".equals(locationDetails.get("status"))) {
                                                    	available = false;           
                                                    }
                                                    if (prevOk) {
                                                        count++;
                                                        Map record = new HashMap();
                                                        record.put("location",entry.getKey());
                                                        record.put("orgName",orgName.replace(locationDetails.get("organisation")+" - ",""));
                                                        record.put("city",addressDetails.get("city"));
                                                        record.put("organisation",locationDetails.get("organisation"));
                                                        record.put("countryDisplayName",locationDetails.get("countryDisplayName"));
                                                        record.put("postalCode",locationDetails.get("postalCode"));
                                                        record.put("fullAddress",composeFullAddress(addressDetails,locationDetails));
                                                        record.put("language",addressEntry.getKey());
                                                        record.put("acronym", acrName);
                                                        record.put("identifiers", identifiers);
                                                        record.put("available", available);
                                                        record.put("includeHistorical", includeHistorical);
                                                        log.debug(record);
                                                        returnSet.add(record);
                                                        // Also add identifiers as records
                                                        if ( !"".equals(identifiers) && includeHistorical) {
                                                            List <String> ids = Util.csvToList(identifiers);
                                                            for (String id:ids) {
                                                                Bundle idRole = context.getObjectByName(Bundle.class,id);
                                                                if (idRole == null) {
                                                                    // Create Org Role on the fly
                                                                    idRole = new Bundle();
                                                                    idRole.setType("EMA Organisation");
                                                                    idRole.setAttribute("classification",classification);
                                                                    idRole.setName(id);
                                                                    idRole.setDisplayName(id + " - " + orgName.replace(locationDetails.get("organisation")+" - ",""));
                                                                    if (owner != null) {
                                                                        idRole.setOwner(owner);
                                                                    }
                                                                    Bundle parentRole = context.getObjectByName(Bundle.class,"EMA Organisations");
                                                                    List<Bundle> parents = new ArrayList<>();
                                                                    if (parentRole != null) {
                                                                        parents.add(parentRole);
                                                                        idRole.setInheritance(parents);
                                                                    }
                                                                    context.saveObject(idRole);
                                                                    context.commitTransaction();
                                                                }
                                                                Map newRecord = new HashMap();
                                                                String idName = idRole.getDisplayableName();
                                                                newRecord.put("location",id + " Merged into "+locationDetails.get("organisation"));
                                                                newRecord.put("orgName",idName.replace(id+" - ",""));
                                                                newRecord.put("city","");
                                                                newRecord.put("organisation",id);
                                                                newRecord.put("countryDisplayName",locationDetails.get("countryDisplayName"));
                                                                newRecord.put("postalCode","-");
                                                                newRecord.put("language",addressEntry.getKey());
                                                                newRecord.put("acronym", "");
                                                                newRecord.put("identifiers", "");
                                                                newRecord.put("fullAddress","-");
                                                                newRecord.put("available", available);
                                                                newRecord.put("includeHistorical", includeHistorical);
                                                                returnSet.add(newRecord);
                                                                
                                                                if (count >= max) {
                                                                    break;
                                                                }

                                                            }
                                                        }

                                                    }
                                                    if (count >= max) {
                                                        break;
                                                    }

                                                }
                                            }

                                        }


                                    }
                                }
                                if (count >= max) {
                                    break;
                                }
                            }


                        }
                        if (count >= max) {
                            break;
                        }
                    }


                }
                if (count >= max) {
                    break;
                }
            }
        }

        List returnList = new ArrayList(returnSet);

        // Sort by org id
        Collections.sort(returnList, mapComparator);

        listResult = new ListResult(returnList,returnList.size());
        log.trace("exiting getOrganisations");
        return listResult;
    }

    public String composeFullAddress(Map addressDetail, Attributes locationDetails) {

        String addressOne = (String) addressDetail.get("addressLine1");
        String addressTwo = (String) addressDetail.get("addressLine2");
        String finaladdress = "";
        if (Util.isNotNullOrEmpty(addressOne)) {
            finaladdress = finaladdress + addressOne;
        }
        if (Util.isNotNullOrEmpty(addressTwo)) {
            finaladdress = finaladdress + "," + addressTwo;
        }
        if(locationDetails.get("postalCode") != null) {
            finaladdress = finaladdress + "," + locationDetails.get("postalCode");
        }
        if(addressDetail.get("city") != null) {
            finaladdress = finaladdress + "," + addressDetail.get("city");
        }
        if (locationDetails.get("countryDisplayName") != null) {
            finaladdress = finaladdress + "," + locationDetails.get("countryDisplayName");
        }
        return finaladdress;
    };

    public Comparator mapComparator = new Comparator() {

        @Override
        public int compare(Object o1, Object o2) {
            if (o1 instanceof Map && o2 instanceof Map) {
                Map m1 = (Map) o1;
                Map m2 = (Map) o2;
                String org1 = (String) m1.get("organisation");
                String org2 = (String) m2.get("organisation");
                return org1.compareTo(org2);
            }

            return 0;
        }


    };
}
