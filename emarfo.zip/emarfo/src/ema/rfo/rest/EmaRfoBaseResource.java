package ema.rfo.rest;

import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.plugin.PluginBaseHelper;
import sailpoint.plugin.PluginContext;
import sailpoint.rest.BaseListResource;
import sailpoint.tools.GeneralException;

import java.sql.Connection;

public class EmaRfoBaseResource extends BaseListResource implements PluginContext {
    private SailPointContext context;
    private Logger log = Logger.getLogger("ema.fro.EmaRfoBaseResource");
    public EmaRfoBaseResource() throws GeneralException {
        this.context = SailPointFactory.getCurrentContext();
    }
    @Override
    public String getPluginName() {
        return "emarfo";
    }

    @Override
    public Connection getConnection() throws GeneralException {
        return PluginBaseHelper.getConnection();
    }


}
