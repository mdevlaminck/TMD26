var orgs = [];
var roles = [];
var selectedOrgsMap = {};
// { [orgId]: { id: "...", display: "..." } }
var selectedRolesMap = {};
// { [roleName]: { id: "...", display: "..." } }
var attachmentIds = [];
var password='';
var pwNeeded = false;
var attNeeded = false;
var currentStep = 1;
var attTempl = document.getElementById("attRowTemplate");
var attTableBody = document.getElementById("attTableBody");
var attDiv = document.getElementById("attDiv");
var fileUploadInput = document.getElementById("file-upload");
var attDrop = document.getElementById("attDrop");
var FILES = {};

// --- paging state ---
var roleTableData = [];
var roleCurrentPage = 1;
var rolePageSize = 10; // change as needed

// --- org paging state ---
var orgTableData = [];
var orgCurrentPage = 1;
var orgPageSize = 10; // change as needed

// --- org sorting state ---
var orgSortKey = 'orgName';
var orgSortDirection = 'asc';

// --- role sorting state ---
var roleSortKey = 'roleDisplayName';
var roleSortDirection = 'asc';

// Select for Country
var countrySelect = new SlimSelect({
    select: '#country'
})

var orgCountrySelect = new SlimSelect({
    select: '#orgCountry'
})

var searchParams = new URLSearchParams(parent.window.location.search);
var prefilledOrg = false;
if (searchParams.has('org')) {
    prefilledOrg = true;
    var preselectedOrg = searchParams.get('org');
    var preselectedCountry = searchParams.get('country');
    countrySelect.set(preselectedCountry);
    document.getElementById('country').value = preselectedCountry ;
    document.getElementById('organisationId').value = preselectedOrg;

    var dummyEvent = new Object();
    validateStep1(dummyEvent);




}

function getBase64Async(file) {
  return new Promise((resolve, reject) => {
    let reader = new FileReader();

    reader.onload = () => {
        let encoded = reader.result.toString().replace(/^data:(.*,)?/, '');
        if ((encoded.length % 4) > 0) {
          encoded += '='.repeat(4 - (encoded.length % 4));
        }
        resolve(encoded);
    };

    reader.onerror = reject;

    reader.readAsDataURL(file);
  })
}



fileUploadInput.onchange = (e) => {
  for (const file of e.target.files) {
    addFile(attTableBody, file);
  }

};

// Create org - add files/attachments
function addFile(target, file) {
    var objectURL = URL.createObjectURL(file);
    var clone = attTempl.content.cloneNode(true);

  clone.querySelector(".filename").textContent = file.name;
  clone.querySelector("tr").id = objectURL;
  clone.querySelector(".filedelete").dataset.target = objectURL;
  clone.querySelector(".filetype").textContent = file.type;
  clone.querySelector(".filesize").textContent =
    file.size > 1024
      ? file.size > 1048576
        ? Math.round(file.size / 1048576) + "mb"
        : Math.round(file.size / 1024) + "kb"
      : file.size + "b";


  attDiv.style.display = "block";
  target.innerHTML='';
  target.append(clone);

    let reader = new FileReader();
      reader.readAsDataURL(file);
      FILES = {};
      reader.onload = () => {
          let encoded = reader.result.toString().replace(/^data:(.*,)?/, '');
          if ((encoded.length % 4) > 0) {
            encoded += '='.repeat(4 - (encoded.length % 4));
          }
          var fileToAdd = {
                  "file": file,
                  "base64": encoded
          };
          FILES[objectURL] = fileToAdd;
      };


}

function deleteFile(event) {
    event.preventDefault();
    console.log(event);
    var ou = event.target.dataset.target;
    document.getElementById(ou).remove(ou);
    delete FILES[ou];
    if (Object.getOwnPropertyNames(FILES).length == 0) {
        attDiv.style.display = "none";
    }

    document.getElementById('file-upload').value='';
}

// use to check if a file is being dragged
const hasFiles = ({ dataTransfer: { types = [] } }) =>
  types.indexOf("Files") > -1;

// use to drag dragenter and dragleave events.
// this is to know if the outermost parent is dragged over
// without issues due to drag events on its children
let counter = 0;

function dropHandler(ev) {
  ev.preventDefault();
  for (const file of ev.dataTransfer.files) {
    addFile(attTableBody, file);
    attDrop.classList.remove("bg-gray-100");
    counter = 0;
  }
}

// only react to actual files being dragged
function dragEnterHandler(e) {
  e.preventDefault();
  if (!hasFiles(e)) {
    return;
  }
  ++counter && attDrop.classList.add("bg-gray-100");
}

function dragLeaveHandler(e) {
  1 > --counter && attDrop.classList.remove("bg-gray-100");
}

function dragOverHandler(e) {
  if (hasFiles(e)) {
    e.preventDefault();
  }
}



//XSRF Token
var SailPoint = {
    XSRF_TOKEN: parent.PluginHelper.getCsrfToken()
}

// Upload init
const uppy = new Uppy.Core({
    debug: false,
    autoProceed: false,
    restrictions: {
        maxFileSize: 5000000,
        maxNumberOfFiles: 1,
        allowedFileTypes: ['.csv','.xls','.xlsx','.doc','.docx','.pdf','.zip','.png','.jpeg','.jpg','.gif'],
    },

 });
uppy.use(Uppy.DragDrop, {
  target: '#addAttachment',
})

var restUrlAttachment = parent.PluginHelper.getPluginRestUrl("emarfo/attachment");
var csrfToken = parent.PluginHelper.getCsrfToken();

uppy.use(Uppy.XHRUpload, {
  endpoint: restUrlAttachment,
  formData: true,
  fieldName: 'file',
  bundle: false,
  headers: {
    'X-XSRF-TOKEN': csrfToken,
    'CSRF-TOKEN': csrfToken
  }
})

// Equivalent to validate step 4
uppy.on('complete', (result) => {

    clearAttachmentIds();
    if (result.successful.length > 0 && result.failed.length ===0) {
        // Iterate array
        for (var i = 0; i < result.successful.length; i++) {
            addAttachmentId(result.successful[i].response.body.id);
        }
        document.getElementById('Step4').style.display="none";
        var dummyEvent = new Object();
        document.getElementById('loader').style.display="block";
        validateStep3(dummyEvent);
    } else {
        if(result.failed.length > 0 ) {
            document.getElementById('uppy-error').innerHTML = "Not all attachments could be uploaded - request could not be submitted";
            document.getElementById('uppy-error').style.display="block";
            setTimeout(function(){document.getElementById('uppy-error').style.display="none"}, 3000);
        } else {
            document.getElementById('uppy-error').innerHTML = "Attachment is required - request could not be submitted";
            document.getElementById('uppy-error').style.display="block";
            setTimeout(function(){document.getElementById('uppy-error').style.display="none"}, 3000);
        }
    }
})
uppy.on('restriction-failed', (file, error) => {
  hideErrorMessages();
  document.getElementById('uppy-error').innerHTML = error;
  document.getElementById('uppy-error').style.display="block";
  setTimeout(function(){document.getElementById('uppy-error').style.display="none"}, 3000);


})
uppy.on('error', (error) => {
  console.log(error.stack)
})
uppy.on('upload-error', (file, error, response) => {
  console.log('error with file:', file.id)
  console.log('error message:', error)
})

uppy.on('file-added', (file) => {
    var attachmentList = document.getElementById('attachmentList');
    var sizeInKb = file.size / 1024;

    var str = `<li class="pl-3 pr-4 py-3 flex items-center justify-between text-sm"><div class="w-0 flex-1 flex items-center"><svg class="flex-shrink-0 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fill-rule="evenodd" d="M8 4a3 3 0 00-3 3v4a5 5 0 0010 0V7a1 1 0 112 0v4a7 7 0 11-14 0V7a5 5 0 0110 0v4a3 3 0 11-6 0V7a1 1 0 012 0v4a1 1 0 102 0V7a3 3 0 00-3-3z" clip-rule="evenodd" />
             </svg><span class="ml-2 flex-1 w-0 truncate"> ${file.name} (${sizeInKb}kb)  </span></div><div class="ml-4 flex-shrink-0"><a href="#" onclick=removeAttachment(event,this,'${file.id}') class="font-medium text-emaBlue-600 hover:text-emaBlue-500"> Remove </a>
               </div></li>`;
    attachmentList.innerHTML = attachmentList.innerHTML + str;

})
// reduce height of default drag and drop
var dragndrop = document.querySelectorAll('.uppy-Root .uppy-DragDrop-container');
for (var dropzone of dragndrop) {
    dropzone.style.height = '40%';
}

const validation = new JustValidate('#createOrgForm', {
          errorFieldCssClass: 'is-invalid',
    });
validation
    .addField('#reason', [
        {
          rule: 'required',
          errorMessage: 'Field is required',
        }
    ])
    .addField('#street-address1', [
            {
              rule: 'required',
              errorMessage: 'Field is required',
            }
    ])
    .addField('#orgCountry', [
            {
              rule: 'required',
              errorMessage: 'Field is required',
            }
    ])
    .addField('#orgName', [
            {
              rule: 'required',
              errorMessage: 'Field is required',
            }
    ])
    .addField('#orgType', [
            {
              rule: 'required',
              errorMessage: 'Field is required',
            }
    ])
    .addField('#orgCity', [
            {
              rule: 'required',
              errorMessage: 'Field is required',
            }
    ])
    .addField('#email-address', [
        {
          rule: 'required',
          errorMessage: 'Field is required',
        },
        {
          rule: 'email',
          errorMessage: 'Email is invalid',
        },
    ])
    .addField('#locationEmail', [
            {
              rule: 'customRegexp',
              value: '(^$|^[a-zA-Z0-9_+&*-]+(?:.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+.)+[a-zA-Z]{2,15}$)',
              errorMessage: 'Email is invalid',
            },
    ])
    .addField('#disclaimer', [
                {
                  rule: 'required',
                  errorMessage: 'Field is required',
                }
    ])
    .addField('#file-upload', [
      {
        rule: 'files',
        value: {
          files: {
            extensions: ['jpeg','jpg','png','pdf','txt','doc','docx','xls','xlsx','gif','zip'],
            maxSize: 50000000,
          },
        },
      },
      {
          rule: 'minFilesCount',
          value: 1,
          errorMessage: 'File count should be 1',
        },
        {
          rule: 'maxFilesCount',
          value: 1,
          errorMessage: 'File count should be 1',
        },
    ],
    {
         errorsContainer: '.file-error',
    })
    .onFail( (fields) => {
        console.log(fields);
    })
    .onSuccess((event) => {
        console.log('Validation passes and form submitted', event);
        hideErrorMessages();
         window.document.getElementById('CreateOrg').style.display="none";
         window.document.getElementById('loader').style.display="block";

        // Call backend for api CR creation
        var jsonData = {
            "reason": window.document.getElementById('reason').value,
            "justification": window.document.getElementById('justification').value,
            "contactEmail": window.document.getElementById('email-address').value,
            "contactPhone": window.document.getElementById('phone').value,
            "organisationName": window.document.getElementById('orgName').value,
            "acronym": window.document.getElementById('acronym').value,
            "organisationType": window.document.getElementById('orgType').value,
            "street1": window.document.getElementById('street-address1').value,
            "street2": window.document.getElementById('street-address2').value,
            "city": window.document.getElementById('orgCity').value,
            "county": window.document.getElementById('county').value,
            "postalCode": window.document.getElementById('postal-code').value,
            "country": window.document.getElementById('orgCountry').value,
            "locationEmail": window.document.getElementById('locationEmail').value,
            "locationPhone": window.document.getElementById('locationPhone').value,
            "dunsId": window.document.getElementById('dunsId').value,
            "gs1Id": window.document.getElementById('gs1Id').value,
        };

        // Attachments
        if (Object.getOwnPropertyNames(FILES).length != 0) {
            var documents = [];
            for(var base64File in FILES) {
                const base64 = FILES[base64File]['base64'];
                const file = FILES[base64File]['file'];
                var document = {
                  "file-name": file.name,
                  "document-id": {
                      "id": "-1",
                      "link": {
                          "href": "http://"
                      }
                  },
                  "description": "uploaded attachment",
                  "type": "REQUEST",
                  "name": file.name,
                  "mime-type": file.type,
                  "file-base64": base64,
                  "application-domain": "OMS"
              };

              documents.push(document);
            }
            var jsonDocument = {
              "document": documents
            }
            jsonData.documents = jsonDocument;
        }
        console.log("jsonData: "+JSON.stringify(jsonData));
        var restUrl = parent.PluginHelper.getPluginRestUrl("emarfo/organisations/create");
        const csrfToken = parent.PluginHelper.getCsrfToken();
        const headers = new Headers({
                'Content-Type': 'application/json',
                'X-XSRF-TOKEN': csrfToken,
                'CSRF-TOKEN': csrfToken
         });
        axios({
            method: 'post',
            url: restUrl,
            data: jsonData,
            headers: {
                    'Content-Type': 'application/json',
                    'X-XSRF-TOKEN': csrfToken,
                    'CSRF-TOKEN': csrfToken
                },
            xsrfCookieName: 'CSRF-TOKEN',
            xsrfHeaderName: 'X-XSRF-TOKEN'
        }).then((data) => {
            console.log(data);
            window.document.getElementById('loader').style.display="none";
            window.document.getElementById('createOrgSubmitted').style.display="block";
            window.document.getElementById('changeRequestId').innerHTML=data.data;

        }, (error) => {
            console.log(error);
            window.document.getElementById('loader').style.display="none";
            window.document.getElementById('changeRequestError').style.display="block";
            window.document.getElementById('changeRequestError').innerHTML=error.response.data.message;
            window.document.getElementById('CreateOrg').style.display="block";
        });


     });
// End Upload Init

// Functions
function removeAttachment(event, clickedElement, fileId) {
    event.preventDefault();
    // remove file
    uppy.removeFile(fileId);
    // modify attachment list
    clickedElement.closest('li').remove();
}



function updateOrgs(newOrgs) {
    orgs = newOrgs;
}
function updateRoles(newRoles) {
    roles = newRoles;
}

function addAttachmentId(id){
    attachmentIds.push(id);
}

function clearAttachmentIds(){
    attachmentIds = [];
}

function updateOrgResultMessage(count){
    var resultString = `${count} results`;
    document.getElementById('orgResultsMessage').innerHTML = resultString;
}
function updateRoleResultMessage(count){
        var resultString = `${count} results`;
        document.getElementById('roleResultsMessage').innerHTML = resultString;
    }
 function getOrgDisplayKey(org) {
     return org.organisation + " - " + org.orgName;
 }

function syncSelectedOrgsWithAvailableOrgs(allOrgs) {
    var displayMap = {};

    allOrgs.forEach(function(org) {
        displayMap[org.organisation] = getOrgDisplayKey(org);
    });

    Object.keys(selectedOrgsMap).forEach(function(orgId) {
        if (displayMap[orgId]) {
            selectedOrgsMap[orgId].display = displayMap[orgId];
        }
    });
}

function refreshSelectedOrgsList() {
    var list = document.getElementById('step3SelectedOrgs');
    var list2 = document.getElementById('step2SelectedOrgs');

    var str = '';
    var count = 0;

    Object.values(selectedOrgsMap).forEach(function(org) {
        count++;
        var bg = count % 2 === 0 ? 'white' : 'bg-gray-50';

        str += `
            <div class="${bg} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="sm:col-span-2 text-sm font-medium text-gray-500">${org.display}</dt>
                <button class="delete-org-btn sm:col-span-1" data-id="${org.id}">
                    <i class="fas fa-trash-alt" style="color: red;"></i>
                </button>
            </div>`;
    });

    if (list) list.innerHTML = str;
    if (list2) list2.innerHTML = str;

    document.querySelectorAll('.delete-org-btn').forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            deleteSelectedOrg(this.getAttribute('data-id'));
        });
    });
}

function deleteSelectedOrg(orgId) {
    delete selectedOrgsMap[orgId];

    var checkboxes = document.querySelectorAll('.emaOrg');
    checkboxes.forEach(function(checkbox) {
        if (checkbox.dataset.id === orgId) {
            checkbox.checked = false;
        }
    });

    refreshSelectedOrgsList();

    if (Object.keys(selectedOrgsMap).length > 0) {
        refreshRolesForSelectedOrgs();
    } else {
        roles = [];
        selectedRolesMap = {};
        roleTableData = [];

        renderRoleTablePage();
        refreshSelectedRolesList();

        document.getElementById("searchRoles").value = "";
        document.getElementById("applicationName").value = "";
        document.getElementById("roleType").value = "";

        document.getElementById('Step3').style.display = "none";
        document.getElementById('Step2').style.display = "block";
    }
}

function updateSelectedOrgsFromVisibleResults() {
    var checkboxes = document.querySelectorAll(".emaOrg");

    checkboxes.forEach(function(checkbox) {
        if (!checkbox.checked) return;

        var orgId = checkbox.dataset.id;
        var orgDisplay = checkbox.dataset.display;

        selectedOrgsMap[orgId] = {
            id: orgId,
            display: orgDisplay
        };
    });
}

 function refreshOrgFilters() {
     updateSelectedOrgsFromVisibleResults();

     var searchOrgsValue = document.getElementById("searchOrgs").value;
     var searchResults = getResultsFromQuery(searchOrgsValue, orgs);

     iterateOrgTable(searchResults);
     updateOrgResultMessage(searchResults.length);
     refreshSelectedOrgsList();
 }

function syncSelectedRolesWithAvailableRoles(allRoles) {
    var displayMap = {};

    allRoles.forEach(function(role) {
        displayMap[role.roleName] = role.roleDisplayName || role.roleName;
    });

    Object.keys(selectedRolesMap).forEach(function(roleId) {
        if (displayMap[roleId]) {
            selectedRolesMap[roleId].display = displayMap[roleId];
        }
    });
}

function refreshSelectedRolesList() {
    var list = document.getElementById('step3SelectedRoles');
    if (!list) {
        return;
    }

    var str = '';
    var count = 0;

    Object.values(selectedRolesMap).forEach(function(role) {
        count++;
        var bg = count % 2 === 0 ? 'white' : 'bg-gray-50';

        str += `
            <div class="${bg} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="sm:col-span-2 text-sm font-medium text-gray-500">${role.display}</dt>
                <button class="delete-role-btn sm:col-span-1" data-id="${role.id}">
                    <i class="fas fa-trash-alt" style="color: red;"></i>
                </button>
            </div>`;
    });

    list.innerHTML = str;

    document.querySelectorAll('.delete-role-btn').forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            deleteSelectedRole(this.getAttribute('data-id'));
        });
    });
}

function deleteSelectedRole(roleId) {
    delete selectedRolesMap[roleId];

    var checkboxes = document.querySelectorAll('input[type="checkbox"].emaRole');
    checkboxes.forEach(function(checkbox) {
        if (checkbox.dataset.id === roleId) {
            checkbox.checked = false;
        }
    });

    refreshSelectedRolesList();
}

function updateSelectedRolesFromVisibleResults() {
    var checkboxes = document.querySelectorAll(".emaRole");

    checkboxes.forEach(function(checkbox) {
        if (!checkbox.checked) {
            return;
        }

        var roleId = checkbox.dataset.id;
        var roleDisplay = checkbox.dataset.display || roleId;

        selectedRolesMap[roleId] = {
            id: roleId,
            display: roleDisplay
        };
    });
}

function refreshRoleFilters() {
    updateSelectedRolesFromVisibleResults();

    var searchApp = document.getElementById("applicationName");
    var searchType = document.getElementById("roleType");
    var searchRoles = document.getElementById("searchRoles");

    var searchResults = getResultsFromFilters(
        searchRoles.value,
        searchApp.value,
        searchType.value,
        roles
    );

    iterateRoleTable(searchResults);
    updateRoleResultMessage(searchResults.length);
    refreshSelectedRolesList();
}
function getResultsFromQuery(query, copy) {
    var trimmed = (query || '').trim();
    if (trimmed === '') {
        return copy.slice();
    }

    var results = [];
    var searchItems = trimmed.split(/\s+/);

    for (var i = 0; i < copy.length; i++) {
        var include = true;

        for (var j = 0; j < searchItems.length; j++) {
            var searchItem = searchItems[j];
            var searchItemFound = false;

            for (var key in copy[i]) {
                if (
                    copy[i].hasOwnProperty(key) &&
                    copy[i][key] &&
                    typeof copy[i][key] === 'string'
                ) {
                    if (copy[i][key].toLowerCase().indexOf(searchItem.toLowerCase()) !== -1) {
                        searchItemFound = true;
                        break;
                    }
                }
            }

            if (!searchItemFound) {
                include = false;
                break;
            }
        }

        if (include && results.indexOf(copy[i]) === -1) {
            results.push(copy[i]);
        }
    }

    return results;
}

function getResultsFromFilters(searchRoles, applicationName, roleType, copy) {
    var results = [];
    var searchItems = searchRoles ? searchRoles.trim().split(/\s+/) : [];

    for (var i = 0; i < copy.length; i++) {
        var record = copy[i];
        var include = true;

        // 1. searchRoles logic = existing search behavior
        if (searchRoles !== "") {
            for (var j = 0; j < searchItems.length; j++) {
                var searchItem = searchItems[j];
                var searchItemFound = false;

                for (var key in record) {
                    if (
                        record.hasOwnProperty(key) &&
                        record[key] &&
                        typeof record[key] === "string"
                    ) {
                        if (record[key].toLowerCase().indexOf(searchItem.toLowerCase()) !== -1) {
                            searchItemFound = true;
                            break;
                        }
                    }
                }

                if (!searchItemFound) {
                    include = false;
                    break;
                }
            }
        }

        // 2. applicationName filter
        if (include && applicationName !== "") {
            if (!record.app || record.app !== applicationName) {
                include = false;
            }
        }

        // 3. roleType filter
        if (include && roleType !== "") {
            if (roleType === "User" && record.isAdmin !== false) {
                include = false;
            } else if (roleType === "Admin" && record.isAdmin !== true) {
                include = false;
            }
        }

        if (include) {
            if (results.indexOf(record) === -1) {
                results.push(record);
            }
        }
    }

    return results;
}
function iterateOrgTable(arr) {
    orgTableData = Array.isArray(arr) ? arr : [];
    orgCurrentPage = 1;
    renderOrgTablePage();
}

function refreshOrgList() {
    refreshSelectedOrgsList();
}


function rolesWithAttachment(attachmentsNeeded){
    var el = document.getElementById('rolesWithAttachment');
    var str = ``;
    var count = 0;
    for (var role in attachmentsNeeded) {
        count++;
        var bg = 'bg-gray-50';
        if(count % 2 == 0 ) {
            bg = 'white';
        }
        str = str + `<div class="${bg} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6"><dt class="sm:col-span-3 text-sm font-medium text-gray-500">${attachmentsNeeded[role]}</dt></div>`;
    }
    // Add info
    str = str + `<div class="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                         <dt class="text-sm font-medium text-gray-500">About</dt>
                         <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">You have selected one or more user administrators roles. The first user administrator of an organisation is validated by the EMA based on provided documentation, please compile and attach the related <a class="text-blue-600 visited:text-purple-600" target="_blank"  href="../../../../help/affiliation template.docx" >affiliation template</a>, more information about user administrator roles can be found <a class="text-blue-600 visited:text-purple-600" target="_blank"  href="../../../../help/useradmin.html" >here</a>. The affiliation template should be signed by a different person from the one submitting the request.</dd>
                       </div>`;
    str = str + `<div class="${bg} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6"><dt class="sm:col-span-3 text-sm font-medium text-gray-500">Need more help? Have a look at the <a class="text-blue-600 visited:text-purple-600" target="_blank" href="../../../../help/requestaccess.html">step by step documentation</a>.</dt></div>`;
    el.innerHTML = str;
}

function rolesWithLanguage(langNeeded){
    var el = document.getElementById('rolesWithLanguage');
    var str = ``;
    var count = 0;
    for (var role in langNeeded) {
        count++;
        var bg = 'bg-gray-50';
        if(count % 2 == 0 ) {
            bg = 'white';
        }
        str = str + `<div class="${bg} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6"><dt class="sm:col-span-3 text-sm font-medium text-gray-500">${langNeeded[role]}</dt></div>`;
    }
  el.innerHTML = str;
}

function appsWithPassword(passwordNeeded) {
    var el = document.getElementById('appsWithPassword');
        var str = ``;
        var count = 0;
        for (var app in passwordNeeded) {
            count++;
            var bg = 'bg-gray-50';
            if(count % 2 == 0 ) {
                bg = 'white';
            }
            str = str + `<div class="${bg} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6"><dt class="sm:col-span-3 text-sm font-medium text-gray-500">${passwordNeeded[app]}</dt></div>`;
        }
        el.innerHTML = str;
}

function iterateRoleTable(arr) {
    roleTableData = Array.isArray(arr) ? arr : [];
    roleCurrentPage = 1;
    renderRoleTablePage();
}

function hideErrorMessages(){
    var errorMessages = document.getElementsByClassName('error-message');
    for (var i = 0; i < errorMessages.length; ++i) {
        var item = errorMessages[i];
        item.style.display="none";
    }
}

function hideSteps(){
    var steps = document.getElementsByClassName('steps');
        for (var i = 0; i < steps.length; ++i) {
            var item = steps[i];
            item.style.display="none";
        }
}

function validateStep4(event) {
    if (event && event.preventDefault) {
        event.preventDefault();
    }

    hideErrorMessages();
    if (attNeeded) {
        uppy.upload();
    } else {
        var dummyEvent = new Object();
        validateStep3(dummyEvent);
    }
}

function validateStep3(event) {
    if (event.preventDefault) {
        event.preventDefault();
    }

    hideErrorMessages();
    pwNeeded = false;
    attNeeded = false;
    // Selected Lang
    var lang = document.getElementById('lang').value;
    var enteredPassword = document.getElementById('password').value;
    // Selected Roles
        updateSelectedRolesFromVisibleResults();

        if (Object.keys(selectedRolesMap).length === 0) {
            document.getElementById('role-error').style.display = "inline";
            document.getElementById('role-error-top').style.display = "block";
        } else {


            // Validate selected roles and orgs
            var jsonData = {
                            "selectedOrgs": getSelectedOrgIds(),
                            "selectedRoles": getSelectedRoleIds(),
                            "attachmentIds": attachmentIds,
                            "password": enteredPassword
                        };
            if (lang.trim().length != 0) {
                jsonData.language = lang;
            }
            var restUrl = parent.PluginHelper.getPluginRestUrl("emarfo/roles/validate");
            document.getElementById('Step3').style.display="none";
            document.getElementById('Step4').style.display="none";
            document.getElementById('attachmentInfo').style.display="none";
            document.getElementById('attachmentDiv').style.display="none";
            document.getElementById('languageDiv').style.display="none";
            document.getElementById('languageInfo').style.display="none";
            document.getElementById('passwordInfo').style.display="none";
            document.getElementById('passwordDiv').style.display="none";
            document.getElementById('loader').style.display="block";
            const csrfToken = parent.PluginHelper.getCsrfToken();
            const headers = new Headers({
                    'Content-Type': 'application/json',
                    'X-XSRF-TOKEN': csrfToken,
                    'CSRF-TOKEN': csrfToken
             });
            axios({
                method: 'post',
                url: restUrl,
                data: jsonData,
                headers: {
                        'Content-Type': 'application/json',
                        'X-XSRF-TOKEN': csrfToken,
                        'CSRF-TOKEN': csrfToken
                    },
                xsrfCookieName: 'CSRF-TOKEN',
                xsrfHeaderName: 'X-XSRF-TOKEN'
            }).then((response) => {

                var message = response.data.status;
                if (!("OK" === message)) {
                    if (message.includes("LangMissing") || message.includes("AttachmentNeeded") || message.includes("PasswordNeeded") ) {
                        // go to step 4
                        if (message.includes("LangMissing")) {
                              document.getElementById('lang-error').style.display="block";
                              document.getElementById('languageInfo').style.display="block";
                              document.getElementById('languageDiv').style.display="block";
                              var langNeeded = response.data.langNeeded;
                              rolesWithLanguage(langNeeded);
                        }
                        if (message.includes("AttachmentNeeded")) {
                            attNeeded = true;
                            document.getElementById('attachmentInfo').style.display="block";
                            document.getElementById('attachmentDiv').style.display="block";
                            var attachmentsNeeded = response.data.attachmentsNeeded;
                            rolesWithAttachment(attachmentsNeeded);
                        }
                        if (message.includes("PasswordNeeded")) {
                            pwNeeded = true;
                            document.getElementById('passwordInfo').style.display="block";
                            document.getElementById('passwordDiv').style.display="block";
                            var passwordNeeded  = response.data.passwordNeeded;
                            appsWithPassword(passwordNeeded);
                            document.getElementById('password-error').style.display="block";
                            document.getElementById('password-error').innerHTML = response.data.passwordError;
                        }
                        document.getElementById('loader').style.display="none";
                        document.getElementById('Step4').style.display="block";

                    } else {
                        // go to step 3
                        document.getElementById('other-role-error').style.display="inline";
                        document.getElementById('other-role-error-top').style.display="block";
                        document.getElementById('other-role-error').innerHTML=message;
                        document.getElementById('other-role-error-top').innerHTML=message;
                        document.getElementById('loader').style.display="none";
                        document.getElementById('Step3').style.display="block";
                    }

                } else {
                    // go to step 5
                    document.getElementById('loader').style.display="none";
                    document.getElementById('Step4').style.display="none";
                    document.getElementById('Step5').style.display="block";
                    if(response.data.identityRequestId) {
                        document.getElementById('requestId').innerHTML="Request ID: "+response.data.identityRequestId;
                    } else {
                        document.getElementById('requestId').innerHTML="Your Request ID could not yet be retrieved. Please check your access requests via the button below."
                    }
                }

              }, (error) => {
                console.log(error);
              });

    }

}
function refreshRolesForSelectedOrgs(onDone) {
    var jsonData = {
        "selectedOrgs": getSelectedOrgIds()
    };

    var restUrl = parent.PluginHelper.getPluginRestUrl("emarfo/roles");
    const csrfToken = parent.PluginHelper.getCsrfToken();

    axios({
        method: 'post',
        url: restUrl,
        data: jsonData,
        headers: {
            'Content-Type': 'application/json',
            'X-XSRF-TOKEN': csrfToken,
            'CSRF-TOKEN': csrfToken
        },
        xsrfCookieName: 'CSRF-TOKEN',
        xsrfHeaderName: 'X-XSRF-TOKEN'
    }).then((response) => {
        roles = response.data.objects;
        updateRoles(roles);

        syncSelectedRolesWithAvailableRoles(roles);

        var count = response.data.count;
        updateRoleResultMessage(count);
        iterateRoleTable(roles);
        populateAppSelect(roles);
        refreshSelectedOrgsList();
        refreshSelectedRolesList();

        if (typeof onDone === "function") {
            onDone();
        }
    }, (error) => {
        console.log(error);
    });
}

function validateStep2(event) {
    if (event.preventDefault) {
        event.preventDefault();
    }

    hideErrorMessages();
    updateSelectedOrgsFromVisibleResults();

    if (Object.keys(selectedOrgsMap).length === 0) {
        document.getElementById('organisation-error').style.display = "inline";
        document.getElementById('organisation-error-top').style.display = "block";
    } else {
        document.getElementById('Step2').style.display="none";
        document.getElementById('loader').style.display="block";

        refreshRolesForSelectedOrgs(function() {
            document.getElementById("searchRoles").value = "";
            document.getElementById("applicationName").value = "";
            document.getElementById("roleType").value = "";
            document.getElementById('loader').style.display = "none";
            document.getElementById('Step3').style.display = "block";
        });
    }

}
function getUniqueApps(data) {
    const apps = data
        .map(item => item.app)
        .filter(Boolean);

    return [...new Set(apps)].sort((a, b) => a.localeCompare(b));
}

function populateAppSelect(data) {
    const uniqueApps = getUniqueApps(data);
    const select = document.getElementById("applicationName");

    // Clear existing options
    select.innerHTML = "";

    // Optional: add default option
    const defaultOption = document.createElement("option");
    defaultOption.value = "";
    defaultOption.textContent = "-- Select Application --";
    select.appendChild(defaultOption);

    // Add apps
    uniqueApps.forEach(app => {
        const option = document.createElement("option");
        option.value = app;
        option.textContent = app;
        select.appendChild(option);
    });
}



function createOrg(){
    hideSteps();
    document.getElementById('loader').style.display="block";
    //Retrieve user email
    var restUrl = parent.PluginHelper.getPluginRestUrl("emarfo/organisations/email");
    const csrfToken = parent.PluginHelper.getCsrfToken();
    const headers = new Headers({
            'Content-Type': 'application/json',
            'X-XSRF-TOKEN': csrfToken,
            'CSRF-TOKEN': csrfToken
     });
    axios({
        method: 'get',
        url: restUrl,
        headers: {
                'Content-Type': 'application/json',
                'X-XSRF-TOKEN': csrfToken,
                'CSRF-TOKEN': csrfToken
            },
        xsrfCookieName: 'CSRF-TOKEN',
        xsrfHeaderName: 'X-XSRF-TOKEN'
    }).then((response) => {
        document.getElementById('loader').style.display="none";
        document.getElementById('email-address').value = response.data.email;
        document.getElementById('CreateOrg').style.display="block";

    }, (error) => {
        document.getElementById('loader').style.display="none";
        document.getElementById('CreateOrg').style.display="block";
        console.log(error);
    });

}




function validateStep1(event){

    if (event.preventDefault) {
            event.preventDefault();
    }

    hideErrorMessages();

    var hasError = false;

    var country = document.getElementById('country').value;
    var organisationId = document.getElementById('organisationId').value;
    var organisationName = document.getElementById('organisationName').value;
    var locationId = document.getElementById('locationId').value;
    var postalCode = document.getElementById('postalCode').value;
    var city = document.getElementById('city').value;
    var fullAddress = document.getElementById('fullAddress').value;
    var language = document.getElementById('language').value;
    
 	var includeHistorical = document.getElementById('includeHistorical').checked;
    if (country.trim().length === 0 ) {
        document.getElementById('country-error').style.display="block";
        hasError = true;
    }

    if (language.trim().length === 0 && organisationId.trim().length === 0 ) {
        document.getElementById('language-error').style.display="block";
        hasError = true;
    }

    if (organisationId.trim().length === 0 && organisationName.trim().length === 0
        && locationId.trim().length === 0 && postalCode.trim().length === 0
        && city.trim().length === 0 && fullAddress.trim().length === 0) {
        document.getElementById('other-error').style.display="block";
        hasError = true;
    }


    if (!hasError) {
        // Fetch organisations
        var jsonData = {
            "country": countrySelect.selected(),
            "city": city,
            "postalCode": postalCode,
            "language": language,
            "fullAddress": fullAddress,
            "organisationId": organisationId,
            "organisationName":organisationName,
            "locationId": locationId,
            "includeHistorical": includeHistorical
        };
	

        var restUrl = parent.PluginHelper.getPluginRestUrl("emarfo/organisations");
        document.getElementById('Step1').style.display="none";
        document.getElementById('loader').style.display="block";
        const csrfToken = parent.PluginHelper.getCsrfToken();
        const headers = new Headers({
                'Content-Type': 'application/json',
                'X-XSRF-TOKEN': csrfToken,
                'CSRF-TOKEN': csrfToken

         });
        axios({
            method: 'post',
            url: restUrl,
            data: jsonData,
            headers: {
                    'Content-Type': 'application/json',
                    'X-XSRF-TOKEN': csrfToken,
                    'CSRF-TOKEN': csrfToken
                },
            xsrfCookieName: 'CSRF-TOKEN',
            xsrfHeaderName: 'X-XSRF-TOKEN'

        }).then((response) => {
            orgs = response.data.objects;
            updateOrgs(orgs);
            syncSelectedOrgsWithAvailableOrgs(orgs);
            var count = response.data.count;
            updateOrgResultMessage(count);
            iterateOrgTable(orgs);
            document.getElementById("searchOrgs").value = "";
            document.getElementById('loader').style.display = "none";
            currentStep = 2;

            refreshSelectedOrgsList();

            applyDateDisable(
                            "createOrgBtn",
                            "2026-04-09T00:00:00",
                            "2026-04-12T23:59:59",
                            "Disabled from 09/04/2026 until 12/04/2026"
                          );

            if (!prefilledOrg) {
                document.getElementById('Step2').style.display = "block";
            } else {
                var matchedOrg = orgs.find(function(org) {
                    return org.organisation === preselectedOrg;
                });

                if (matchedOrg) {
                    var displayValue = getOrgDisplayKey(matchedOrg);

                    selectedOrgsMap[preselectedOrg] = {
                        id: preselectedOrg,
                        display: displayValue
                    };

                    renderOrgTablePage();
                    refreshSelectedOrgsList();

                    var dummyEvent = new Object();
                    validateStep2(dummyEvent);
                }

                prefilledOrg = false;
            }
          }, (error) => {
            console.log(error);
          });

    }

}

var searchOrgs = document.getElementById("searchOrgs");
searchOrgs.addEventListener("keyup", function() {
    refreshOrgFilters();
});
var searchApp = document.getElementById("applicationName");
var searchType = document.getElementById("roleType");
var searchRoles = document.getElementById("searchRoles");
searchApp.addEventListener("change", function() {
    refreshRoleFilters();
});

searchType.addEventListener("change", function() {
    refreshRoleFilters();
});

searchRoles.addEventListener("keyup", function() {
    refreshRoleFilters();
});

function closeInfoStep2(){
    document.getElementById('infoStep2').style.display="none";
}

function openInfoStep2(){
        document.getElementById('infoStep2').style.display="block";
}

function closeInfoStep3(){
    document.getElementById('infoStep3').style.display="none";
}

function openInfoStep3(){
        document.getElementById('infoStep3').style.display="block";
}



function goBackToStep1(event){
    event.preventDefault();
    currentStep = 1;
    document.getElementById('Step1').style.display="block";
    document.getElementById('Step2').style.display="none";
    document.getElementById('Step3').style.display="none";
    document.getElementById('Step4').style.display="none";
    document.getElementById('Step5').style.display="none";
    document.getElementById('CreateOrg').style.display="none";
}
function goBackToStep2(event){
    event.preventDefault();
    currentStep = 2;
    document.getElementById("searchOrgs").value = "";
    iterateOrgTable(orgs);
    updateOrgResultMessage(orgs.length);
    refreshSelectedOrgsList();
    document.getElementById('Step1').style.display = "none";
    document.getElementById('Step2').style.display = "block";
    document.getElementById('Step3').style.display = "none";
    document.getElementById('Step4').style.display = "none";
    document.getElementById('Step5').style.display = "none";
    document.getElementById('CreateOrg').style.display = "none";
}

function goBackFromCreate(event){
        event.preventDefault();
        if (currentStep == 2) {
            goBackToStep2(event);
        } else {
            goBackToStep1(event);
        }

}
function goBackToStep3(event){
    event.preventDefault();
    document.getElementById("searchRoles").value = "";
    document.getElementById("applicationName").value = "";
    document.getElementById("roleType").value = "";
    iterateRoleTable(roles);
    updateRoleResultMessage(roles.length);
    refreshSelectedRolesList();

    document.getElementById('Step1').style.display = "none";
    document.getElementById('Step2').style.display = "none";
    document.getElementById('Step3').style.display = "block";
    document.getElementById('Step4').style.display = "none";
    document.getElementById('Step5').style.display = "none";
}

function resetForm(){
    document.getElementById("searchOrganisations").reset();
    countrySelect.set([]);
}

function goToRequests(event) {
    event.preventDefault();
    var url = parent.window.location.href.substring(0,parent.window.location.href.indexOf('plugins'));
    parent.window.location = url+"identityRequest/identityRequest.jsf#/requests";
}

function newRequest(event) {
    event.preventDefault();
    var url = parent.window.location.href.substring(0,parent.window.location.href.indexOf('plugins'));
    parent.window.location = url+"plugins/pluginPage.jsf?pn=emarfo";
}

function attachCheckboxListeners() {
    var checkboxes = document.querySelectorAll(".emaRole");

    checkboxes.forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            var roleId = this.dataset.id;
            var roleDisplay = this.dataset.display || roleId;

            if (this.checked) {
                selectedRolesMap[roleId] = {
                    id: roleId,
                    display: roleDisplay
                };
            } else {
                delete selectedRolesMap[roleId];
            }

            refreshSelectedRolesList();
        });
    });
}
function attachOrgCheckboxListeners() {
    var checkboxes = document.querySelectorAll(".emaOrg");

    checkboxes.forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            var orgId = this.dataset.id;
            var orgDisplay = this.dataset.display;

            if (this.checked) {
                selectedOrgsMap[orgId] = {
                    id: orgId,
                    display: orgDisplay
                };
            } else {
                delete selectedOrgsMap[orgId];
            }

            refreshSelectedOrgsList();
        });
    });
}

function renderOrgTablePage() {
    var tbody = document.getElementById('orgTableBody');
    var pagination = document.getElementById('orgPaginationControls');

    if (!tbody) return;
    renderOrgHeader();
    tbody.innerHTML = '';

    sortOrgTableData();

    var totalItems = orgTableData.length;
    var totalPages = Math.max(1, Math.ceil(totalItems / orgPageSize));

    if (orgCurrentPage > totalPages) {
        orgCurrentPage = totalPages;
    }

    var start = (orgCurrentPage - 1) * orgPageSize;
    var end = start + orgPageSize;
    var pageItems = orgTableData.slice(start, end);

    pageItems.forEach(function(i) {
        var z = document.createElement('tr');
        var orgDisplay = i.organisation || '';
        if (i.location && i.location.toLowerCase().includes('merged')) {
            z.classList.add("bg-gray-100");
            orgDisplay = orgDisplay + ' (Historical)';
        }

        var acronym = i.acronym || '';
        var city = i.city || '';
        var countryDisplayName = i.countryDisplayName || '';
        var identifiers = i.identifiers || '';
        var location = i.location || '';
        var orgName = i.orgName || '';
        var organisation = i.organisation || '';
        var postalCode = i.postalCode || '';
        var address = i.fullAddress || '';
        var available = i.available;
        var includeHistorical = i.includeHistorical;
        var orgDisplayKey = getOrgDisplayKey(i);
        var isChecked = !!selectedOrgsMap[organisation];

        if (!available) {
            z.style.backgroundColor = 'rgb(241 245 249)';
        }

        var str = `
        <td class="relative w-12 px-6 sm:w-16 sm:px-8">
            <input
                ${!available && !includeHistorical ? 'disabled="true"' : ''}
                type="checkbox"
                class="emaOrg absolute left-4 top-1/2 -mt-2 h-4 w-4 rounded border-gray-300 text-emaBlue-600 focus:ring-emaBlue-500 sm:left-6"
                data-id="${organisation}"
                data-org="${orgName}"
                data-display="${orgDisplayKey}"
                ${isChecked ? "checked" : ""}>
        </td>
        <td class="whitespace-nowrap py-4 pr-3 text-xs text-gray-500">${orgDisplay}</td>
        <td class="whitespace-normal px-3 py-4 text-xs font-medium text-gray-900">${orgName}</td>
        <td class="whitespace-nowrap px-3 py-4 text-xs text-gray-500">${countryDisplayName}</td>
        <td class="whitespace-nowrap px-3 py-4 text-xs text-gray-500">${location}</td>
        <td class="whitespace-nowrap px-3 py-4 text-xs text-gray-500">${city}</td>
        <td class="whitespace-nowrap px-3 py-4 text-xs text-gray-500">${postalCode}</td>
        <td class="whitespace-normal px-3 py-4 text-xs text-gray-500">${address}</td>
        <td class="whitespace-normal px-3 py-4 text-xs text-gray-500">${identifiers}</td>
        <td class="whitespace-nowrap px-3 py-4 text-xs text-gray-500">${acronym}</td>
        `;

        z.innerHTML = str;
        tbody.appendChild(z);
    });

    attachOrgCheckboxListeners();
    renderOrgPagination(totalItems, totalPages, pagination);
}

function renderOrgPagination(totalItems, totalPages, container) {
    if (!container) return;

    var startItem = totalItems === 0 ? 0 : (orgCurrentPage - 1) * orgPageSize + 1;
    var endItem = Math.min(orgCurrentPage * orgPageSize, totalItems);

    container.innerHTML = `
        <div class="flex flex-col gap-3 border-gray-200 bg-white px-4 py-3 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div class="text-sm text-gray-700">
                Showing <span class="font-medium">${startItem}</span>
                to <span class="font-medium">${endItem}</span>
                of <span class="font-medium">${totalItems}</span> results
            </div>

            <div class="flex items-center justify-between gap-2 sm:justify-end">
                <button
                    id="orgPrevPage"
                    class="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
                    ${orgCurrentPage === 1 ? 'disabled' : ''}>
                    Previous
                </button>

                <div class="flex items-center gap-1" id="orgPageNumbers"></div>

                <button
                    id="orgNextPage"
                    class="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
                    ${orgCurrentPage === totalPages || totalItems === 0 ? 'disabled' : ''}>
                    Next
                </button>
            </div>
        </div>
    `;

    var pageNumbers = container.querySelector('#orgPageNumbers');
    pageNumbers.innerHTML = buildOrgPageButtons(totalPages);

    var prevBtn = container.querySelector('#orgPrevPage');
    var nextBtn = container.querySelector('#orgNextPage');

    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            if (orgCurrentPage > 1) {
                orgCurrentPage--;
                renderOrgTablePage();
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            if (orgCurrentPage < totalPages) {
                orgCurrentPage++;
                renderOrgTablePage();
            }
        });
    }

    container.querySelectorAll('.org-page-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            orgCurrentPage = parseInt(this.dataset.page, 10);
            renderOrgTablePage();
        });
    });
}

function buildOrgPageButtons(totalPages) {
    if (totalPages <= 1) return '';

    var html = '';
    var maxVisible = 5;
    var startPage = Math.max(1, orgCurrentPage - 2);
    var endPage = Math.min(totalPages, startPage + maxVisible - 1);

    if ((endPage - startPage + 1) < maxVisible) {
        startPage = Math.max(1, endPage - maxVisible + 1);
    }

    if (startPage > 1) {
        html += orgPageBtnHtml(1);
        if (startPage > 2) {
            html += `<span class="px-2 text-sm text-gray-500">...</span>`;
        }
    }

    for (var p = startPage; p <= endPage; p++) {
        html += orgPageBtnHtml(p, p === orgCurrentPage);
    }

    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            html += `<span class="px-2 text-sm text-gray-500">...</span>`;
        }
        html += orgPageBtnHtml(totalPages);
    }

    return html;
}

function orgPageBtnHtml(page, active) {
    return `
        <button
            type="button"
            style="margin-right:5px;"
            data-page="${page}"
            class="org-page-btn inline-flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                active
                    ? 'bg-emaBlue-600 text-white shadow-sm'
                    : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
            }">
            ${page}
        </button>
    `;
}
function renderRoleTablePage() {
    var tbody = document.getElementById('roleTableBody');
    var pagination = document.getElementById('rolePaginationControls');

    if (!tbody) return;
    renderRoleHeader();
    tbody.innerHTML = '';
    sortRoleTableData();
    var totalItems = roleTableData.length;
    var totalPages = Math.max(1, Math.ceil(totalItems / rolePageSize));

    if (roleCurrentPage > totalPages) {
        roleCurrentPage = totalPages;
    }

    var start = (roleCurrentPage - 1) * rolePageSize;
    var end = start + rolePageSize;
    var pageItems = roleTableData.slice(start, end);

    pageItems.forEach(function(i) {
        var z = document.createElement('tr');
        var roleName = i.roleName;
        var roleDisplayName = i.roleDisplayName;
        var roleDescription = i.roleDescription;
        var isChecked = !!selectedRolesMap[roleName];
        var isAdmin = i.isAdmin;

        var str = `
        <td class="relative w-12 px-6 sm:w-16 sm:px-8">
        <input type="checkbox"
               class="emaRole absolute left-4 top-1/2 -mt-2 h-4 w-4 rounded border-gray-300 text-emaBlue-600 focus:ring-emaBlue-500 sm:left-6"
               data-id="${roleName}"
               data-display="${roleDisplayName || roleName}"
               ${isChecked ? "checked" : ""}>
        </td>
        <td class="whitespace-normal px-3 py-4 text-xs font-medium text-gray-900">${roleDisplayName || ''}</td>
        <td class="whitespace-normal px-3 py-4 text-xs text-gray-500">${roleDescription || ''}</td>
        `;

        if (isAdmin) {
            str += `<td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500"><span class="inline-flex rounded-full bg-red-100 px-2 text-xs font-semibold leading-5 text-red-800">Yes</span></td>`;
        } else {
            str += `<td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500"><span class="inline-flex rounded-full bg-green-100 px-2 text-xs font-semibold leading-5 text-green-800">No</span></td>`;
        }

        z.innerHTML = str;
        tbody.appendChild(z);
    });

    attachCheckboxListeners();
    renderRolePagination(totalItems, totalPages, pagination);
}

function renderRolePagination(totalItems, totalPages, container) {
    if (!container) return;

    var startItem = totalItems === 0 ? 0 : (roleCurrentPage - 1) * rolePageSize + 1;
    var endItem = Math.min(roleCurrentPage * rolePageSize, totalItems);

    container.innerHTML = `
        <div class="flex flex-col gap-3 border-gray-200 bg-white px-4 py-3 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div class="text-sm text-gray-700">
                Showing <span class="font-medium">${startItem}</span>
                to <span class="font-medium">${endItem}</span>
                of <span class="font-medium">${totalItems}</span> results
            </div>

            <div class="flex items-center justify-between gap-2 sm:justify-end">
                <button
                    id="rolePrevPage"
                    class="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
                    ${roleCurrentPage === 1 ? 'disabled' : ''}>
                    Previous
                </button>

                <div class="flex items-center gap-1" id="rolePageNumbers"></div>

                <button
                    id="roleNextPage"
                    class="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
                    ${roleCurrentPage === totalPages || totalItems === 0 ? 'disabled' : ''}>
                    Next
                </button>
            </div>
        </div>
    `;

    var pageNumbers = container.querySelector('#rolePageNumbers');
    pageNumbers.innerHTML = buildRolePageButtons(totalPages);

    var prevBtn = container.querySelector('#rolePrevPage');
    var nextBtn = container.querySelector('#roleNextPage');

    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            if (roleCurrentPage > 1) {
                roleCurrentPage--;
                renderRoleTablePage();
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            if (roleCurrentPage < totalPages) {
                roleCurrentPage++;
                renderRoleTablePage();
            }
        });
    }

    container.querySelectorAll('.role-page-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            roleCurrentPage = parseInt(this.dataset.page, 10);
            renderRoleTablePage();
        });
    });
}

function buildRolePageButtons(totalPages) {
    if (totalPages <= 1) return '';

    var html = '';
    var maxVisible = 5;
    var startPage = Math.max(1, roleCurrentPage - 2);
    var endPage = Math.min(totalPages, startPage + maxVisible - 1);

    if ((endPage - startPage + 1) < maxVisible) {
        startPage = Math.max(1, endPage - maxVisible + 1);
    }

    if (startPage > 1) {
        html += pageBtnHtml(1);
        if (startPage > 2) {
            html += `<span class="px-2 text-sm text-gray-500">...</span>`;
        }
    }

    for (var p = startPage; p <= endPage; p++) {
        html += pageBtnHtml(p, p === roleCurrentPage);
    }

    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            html += `<span class="px-2 text-sm text-gray-500">...</span>`;
        }
        html += pageBtnHtml(totalPages);
    }

    return html;
}

function pageBtnHtml(page, active) {
    return `
        <button
            type="button"
            style="margin-right:5px;"
            data-page="${page}"
            class="role-page-btn inline-flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                active
                    ? 'bg-emaBlue-600 text-white shadow-sm'
                    : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
            }">
            ${page}
        </button>
    `;
}

function changeOrgPageSize(size) {
    orgPageSize = parseInt(size, 10);
    orgCurrentPage = 1;
    renderOrgTablePage();
}

function changeRolePageSize(size) {
    rolePageSize = parseInt(size, 10);
    roleCurrentPage = 1;
    renderRoleTablePage();
}

function normalizeSortValue(value) {
    if (value === null || value === undefined) {
        return '';
    }

    if (typeof value === 'boolean') {
        return value ? 1 : 0;
    }

    return String(value).toLowerCase().trim();
}

function compareValues(a, b, direction) {
    var av = normalizeSortValue(a);
    var bv = normalizeSortValue(b);

    if (av < bv) {
        return direction === 'asc' ? -1 : 1;
    }
    if (av > bv) {
        return direction === 'asc' ? 1 : -1;
    }
    return 0;
}

function sortOrgTableData() {
    if (!orgSortKey) {
        return;
    }

    orgTableData.sort(function(a, b) {
        return compareValues(a[orgSortKey], b[orgSortKey], orgSortDirection);
    });
}

function sortRoleTableData() {
    if (!roleSortKey) {
        return;
    }

    roleTableData.sort(function(a, b) {
        return compareValues(a[roleSortKey], b[roleSortKey], roleSortDirection);
    });
}
function setOrgSort(key) {
    if (orgSortKey === key) {
        orgSortDirection = orgSortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        orgSortKey = key;
        orgSortDirection = 'asc';
    }

    orgCurrentPage = 1;
    renderOrgTablePage();
}

function setRoleSort(key) {
    if (roleSortKey === key) {
        roleSortDirection = roleSortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        roleSortKey = key;
        roleSortDirection = 'asc';
    }

    roleCurrentPage = 1;
    renderRoleTablePage();
}

function getSortIndicator(activeKey, currentKey, direction) {
    if (activeKey !== currentKey) {
        return ' <span style="font-size:10px;color:#9ca3af;">⇅</span>';
    }
    return direction === 'asc'
        ? ' <span style="font-size:10px;color:#6b7280;">▲</span>'
        : ' <span style="font-size:10px;color:#6b7280;">▼</span>';
}

function renderOrgHeader() {
    var theadRow = document.querySelector('#orgTable thead tr');

    if (!theadRow) return;

    theadRow.innerHTML = `
        <th scope="col" class="relative w-12 px-6 sm:w-16 sm:px-8"></th>
        <th scope="col" onclick="setOrgSort('organisation')" class="py-3.5 pr-3 text-left text-xs font-semibold text-gray-900 cursor-pointer">Id${getSortIndicator(orgSortKey, 'organisation', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('orgName')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Name${getSortIndicator(orgSortKey, 'orgName', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('countryDisplayName')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Country${getSortIndicator(orgSortKey, 'countryDisplayName', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('location')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Location${getSortIndicator(orgSortKey, 'location', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('city')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">City${getSortIndicator(orgSortKey, 'city', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('postalCode')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Postal Code${getSortIndicator(orgSortKey, 'postalCode', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('fullAddress')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Address${getSortIndicator(orgSortKey, 'fullAddress', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('identifiers')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Historical Records${getSortIndicator(orgSortKey, 'identifiers', orgSortDirection)}</th>
        <th scope="col" onclick="setOrgSort('acronym')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Acronym${getSortIndicator(orgSortKey, 'acronym', orgSortDirection)}</th>
    `;
}

function renderRoleHeader() {
    var theadRow = document.querySelector('#roleTable thead tr');
    if (!theadRow) return;

    theadRow.innerHTML = `
        <th scope="col" class="relative w-12 px-6 sm:w-16 sm:px-8"></th>
        <th scope="col" onclick="setRoleSort('roleDisplayName')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Name${getSortIndicator(roleSortKey, 'roleDisplayName', roleSortDirection)}</th>
        <th scope="col" onclick="setRoleSort('roleDescription')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">Description${getSortIndicator(roleSortKey, 'roleDescription', roleSortDirection)}</th>
        <th scope="col" onclick="setRoleSort('isAdmin')" class="px-3 py-3.5 text-left text-xs font-semibold text-gray-900 cursor-pointer">User Administrator?${getSortIndicator(roleSortKey, 'isAdmin', roleSortDirection)}</th>
    `;
}
function getSelectedOrgIds() {
    return Object.keys(selectedOrgsMap);
}
function getSelectedRoleIds() {
    return Object.keys(selectedRolesMap);
}

function applyDateDisable(buttonId, startStr, endStr, tooltipText) {
  const btn = document.getElementById(buttonId);
  if (!btn) return;

  // Store original text once
  if (!btn.dataset.originalText) {
    btn.dataset.originalText = btn.innerHTML;
  }

  const now   = new Date();
  const start = new Date(startStr);
  const end   = new Date(endStr);

  if (now >= start && now <= end) {
    // Disable
    btn.disabled = true;

    // Tooltip
    btn.title = tooltipText;

    // Update button text
    btn.innerHTML = `
      <span class="flex items-center gap-2">
        <span>🚫</span>
        <span>${tooltipText}</span>
      </span>
    `;

    // Grey-out styling
    btn.classList.add("opacity-50", "cursor-not-allowed");
    btn.classList.remove("hover:bg-emaBlue-200");

  } else {
    // Enable
    btn.disabled = false;

    // Remove tooltip
    btn.title = "";

    // Restore original text
    btn.innerHTML = btn.dataset.originalText;

    // Restore styling
    btn.classList.remove("opacity-50", "cursor-not-allowed");
    btn.classList.add("hover:bg-emaBlue-200");
  }
}